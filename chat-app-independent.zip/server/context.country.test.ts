import { describe, expect, it } from "vitest";
import { normalizeCountryCode } from "./_core/context";

describe("country code normalization", () => {
  it("normalizes common proxy header formats", () => {
    expect(normalizeCountryCode("jo, EG;q=0.8")).toBe("JO");
    expect(normalizeCountryCode(" gb / en")).toBe("GB");
    expect(normalizeCountryCode(["sa;region=riyadh"])).toBe("SA");
  });

  it("maps common aliases to ISO alpha-2 codes", () => {
    expect(normalizeCountryCode("uk")).toBe("GB");
    expect(normalizeCountryCode("EL")).toBe("GR");
  });

  it("rejects missing, malformed, and generic country values", () => {
    expect(normalizeCountryCode(undefined)).toBeNull();
    expect(normalizeCountryCode("unknown")).toBeNull();
    expect(normalizeCountryCode("XX")).toBeNull();
    expect(normalizeCountryCode("EU")).toBeNull();
  });
});

export {};
