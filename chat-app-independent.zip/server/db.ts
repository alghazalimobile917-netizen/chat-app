import { and, asc, count, desc, eq, gt, isNull, lt, or } from "drizzle-orm";
import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { drizzle } from "drizzle-orm/mysql2";
import {
  chatBlocks,
  chatMessages,
  memberAccounts,
  memberFriendships,
  memberSessions,
  chatPinnedConversations,
  chatReports,
  chatRooms,
  chatSessions,
  nameDecorations,
  type ChatMessage,
  type ChatRoom,
  type ChatSession,
  type InsertChatSession,
  type InsertMemberAccount,
  type InsertNameDecoration,
  type InsertUser,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { cleanDisplayName, decorateDisplayName, decorateWithWrapper, type NameDecoration } from "../shared/nameDecoration";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId, lastSignedIn: new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: new Date() };
  (['name', 'email', 'loginMethod'] as const).forEach((field) => {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  });
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

/** الجلسة الدائمة لا تنتهي تلقائياً؛ تُحذف عند تسجيل الخروج الصريح فقط. */
const MEMBER_SESSION_DAYS: number | null = null;

function normalizeMemberEmail(email: string) {
  return email.trim().toLocaleLowerCase("en-US");
}

function hashMemberPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const digest = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${digest}`;
}

export function verifyMemberPassword(password: string, encoded: string) {
  const [salt, expectedHex] = encoded.split(":");
  if (!salt || !expectedHex) return false;
  const actual = scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHex, "hex");
  return expected.length === actual.length && timingSafeEqual(actual, expected);
}

export type PublicMemberAccount = {
  id: number;
  alias: string;
  age: number;
  gender: "male" | "female";
  avatarKey: string | null;
  avatarMimeType: string | null;
  acceptsPrivateMessages: boolean;
  privateMessagePolicy: "everyone" | "friends" | "nobody";
  showPresence: boolean;
  fontFamily: "cairo" | "tajawal" | "system";
  textColor: string;
  nameDecoration: string;
};

export type MemberAuthResult = {
  token: string;
  expiresAt: Date | null;
  account: PublicMemberAccount;
  profile: ChatSession;
};

function publicMemberAccount(account: typeof memberAccounts.$inferSelect): PublicMemberAccount {
  return {
    id: account.id,
    alias: account.alias,
    age: account.age,
    gender: account.gender,
    avatarKey: account.avatarKey,
    avatarMimeType: account.avatarMimeType,
    acceptsPrivateMessages: account.acceptsPrivateMessages,
    privateMessagePolicy: account.privateMessagePolicy,
    showPresence: account.showPresence,
    fontFamily: account.fontFamily as PublicMemberAccount["fontFamily"],
    textColor: account.textColor,
    nameDecoration: account.nameDecoration,
  };
}

export async function getMemberAccountByEmail(email: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(memberAccounts).where(eq(memberAccounts.email, normalizeMemberEmail(email))).limit(1);
  return rows[0];
}

export async function getMemberAccountByAlias(alias: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(memberAccounts).where(eq(memberAccounts.alias, alias.trim())).limit(1);
  return rows[0];
}

export async function getMemberAccountById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(memberAccounts).where(eq(memberAccounts.id, id)).limit(1);
  return rows[0];
}

export async function createMemberAccount(input: { email: string; password: string; alias: string; age: number; gender: "male" | "female"; nameDecoration?: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const email = normalizeMemberEmail(input.email);
  const alias = cleanDisplayName(input.alias);
  const existingEmail = await getMemberAccountByEmail(email);
  if (existingEmail) throw new Error("هذا البريد مسجل مسبقاً.");
  const existingAlias = await getMemberAccountByAlias(alias);
  if (existingAlias) throw new Error("هذا الاسم المستعار مستخدم مسبقاً.");
  const values: InsertMemberAccount = {
    email,
    passwordHash: hashMemberPassword(input.password),
    alias,
    age: input.age,
    gender: input.gender,
    nameDecoration: input.nameDecoration ?? "none",
    chatSessionId: `member-${randomBytes(24).toString("hex")}`,
  };
  const result = await db.insert(memberAccounts).values(values);
  const account = await getMemberAccountById(Number(result[0].insertId));
  if (!account) throw new Error("تعذر إنشاء الحساب.");
  return account;
}

export async function authenticateMember(email: string, password: string, options: { countryCode?: string | null } = {}): Promise<MemberAuthResult> {
  const account = await getMemberAccountByEmail(email);
  if (!account || !verifyMemberPassword(password, account.passwordHash)) throw new Error("البريد أو كلمة السر غير صحيحة.");
  return startMemberSession(account, options);
}

export async function startMemberSession(account: typeof memberAccounts.$inferSelect, options: { countryCode?: string | null } = {}): Promise<MemberAuthResult> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const token = randomBytes(48).toString("base64url");
  const expiresAt = MEMBER_SESSION_DAYS === null ? null : new Date(Date.now() + MEMBER_SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(memberSessions).values({ token, accountId: account.id, chatSessionId: account.chatSessionId, expiresAt });
  await db.update(memberAccounts).set({ lastSignedIn: new Date() }).where(eq(memberAccounts.id, account.id));
  const profile = await createOrRefreshChatSession({
    sessionId: account.chatSessionId,
    displayName: await getDecoratedAccountAlias(account),
    age: account.age,
    gender: account.gender,
    role: "member",
    accountId: account.id,
    avatarKey: account.avatarKey,
    avatarMimeType: account.avatarMimeType,
    acceptsPrivateMessages: account.acceptsPrivateMessages,
    privateMessagePolicy: account.privateMessagePolicy,
    showPresence: account.showPresence,
    countryCode: options.countryCode ?? null,
  });
  return { token, expiresAt, account: publicMemberAccount(account), profile };
}

async function getDecoratedAccountAlias(account: typeof memberAccounts.$inferSelect) {
  const available = await listNameDecorations();
  const decoration = available.find((item) => item.key === account.nameDecoration) ?? available.find((item) => item.key === "none");
  if (!decoration || decoration.key === "none") return cleanDisplayName(account.alias);
  if (decoration.key in { none: true, stars: true, hearts: true, diamonds: true }) return decorateDisplayName(account.alias, decoration.key as NameDecoration);
  return decorateWithWrapper(account.alias, decoration.prefix, decoration.suffix);
}

export async function getMemberSessionByToken(token: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(memberSessions).where(and(eq(memberSessions.token, token), or(isNull(memberSessions.expiresAt), gt(memberSessions.expiresAt, new Date())))).limit(1);
  const session = rows[0];
  if (!session) return undefined;
  const account = await getMemberAccountById(session.accountId);
  if (!account) return undefined;
  return { session, account };
}

export async function touchMemberSession(token: string) {
  const member = await getMemberSessionByToken(token);
  if (!member) throw new Error("انتهت جلسة العضو. سجّل الدخول من جديد.");
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.update(memberSessions).set({ lastSeenAt: new Date() }).where(eq(memberSessions.token, token));
  const profile = await touchChatSession(member.account.chatSessionId);
  return { ...member, profile };
}

export async function logoutMemberSession(token: string) {
  const db = await getDb();
  if (!db) return;
  const member = await getMemberSessionByToken(token);
  await db.delete(memberSessions).where(eq(memberSessions.token, token));
  if (member) await db.update(chatSessions).set({ lastSeenAt: new Date(0) }).where(eq(chatSessions.sessionId, member.account.chatSessionId));
}

export async function getMemberContext(token: string) {
  return touchMemberSession(token);
}

const DEFAULT_NAME_DECORATIONS: InsertNameDecoration[] = [
  { key: "none", label: "بدون زخرفة", prefix: "", suffix: "", enabled: true, sortOrder: 0 },
  { key: "stars", label: "نجوم", prefix: "✦ ", suffix: " ✦", enabled: true, sortOrder: 1 },
  { key: "hearts", label: "قلوب", prefix: "♡ ", suffix: " ♡", enabled: true, sortOrder: 2 },
  { key: "diamonds", label: "ألماس", prefix: "◆ ", suffix: " ◆", enabled: true, sortOrder: 3 },
];

export async function listNameDecorations(includeDisabled = false) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  let rows = await db.select().from(nameDecorations).orderBy(asc(nameDecorations.sortOrder), asc(nameDecorations.id));
  if (!rows.length) {
    await db.insert(nameDecorations).values(DEFAULT_NAME_DECORATIONS);
    rows = await db.select().from(nameDecorations).orderBy(asc(nameDecorations.sortOrder), asc(nameDecorations.id));
  }
  return includeDisabled ? rows : rows.filter((row) => row.enabled);
}

export async function createNameDecoration(input: InsertNameDecoration) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.insert(nameDecorations).values(input);
  const rows = await db.select().from(nameDecorations).where(eq(nameDecorations.key, input.key)).limit(1);
  return rows[0];
}

export async function updateNameDecoration(id: number, input: Partial<InsertNameDecoration>) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.update(nameDecorations).set(input).where(eq(nameDecorations.id, id));
  const rows = await db.select().from(nameDecorations).where(eq(nameDecorations.id, id)).limit(1);
  return rows[0];
}

export async function deleteNameDecoration(id: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(nameDecorations).where(eq(nameDecorations.id, id)).limit(1);
  if (rows[0]?.key === "none") throw new Error("لا يمكن حذف الخيار الافتراضي.");
  await db.delete(nameDecorations).where(eq(nameDecorations.id, id));
}

export async function listPinnedConversations(token: string) {
  const actor = await getMemberContext(token);
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select({ peerSessionId: chatPinnedConversations.peerSessionId }).from(chatPinnedConversations).where(eq(chatPinnedConversations.accountId, actor.account.id)).orderBy(asc(chatPinnedConversations.createdAt));
  return rows.map((row) => row.peerSessionId);
}

export async function setPinnedConversation(token: string, peerSessionId: string, pinned: boolean) {
  const actor = await getMemberContext(token);
  if (!peerSessionId || peerSessionId === actor.account.chatSessionId) throw new Error("المحادثة المحددة غير صالحة.");
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const existing = await db.select({ id: chatPinnedConversations.id }).from(chatPinnedConversations).where(and(eq(chatPinnedConversations.accountId, actor.account.id), eq(chatPinnedConversations.peerSessionId, peerSessionId))).limit(1);
  if (pinned && !existing[0]) await db.insert(chatPinnedConversations).values({ accountId: actor.account.id, peerSessionId });
  if (!pinned && existing[0]) await db.delete(chatPinnedConversations).where(eq(chatPinnedConversations.id, existing[0].id));
  return { pinned, peerSessionId };
}

export async function requestMemberFriend(token: string, targetSessionId: string) {
  const actor = await getMemberContext(token);
  const target = await getChatSession(targetSessionId);
  if (!target?.accountId) throw new Error("يمكن إضافة الأعضاء المسجلين فقط إلى الأصدقاء.");
  if (target.accountId === actor.account.id) throw new Error("لا يمكنك إضافة نفسك.");
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const existing = await db.select().from(memberFriendships).where(or(
    and(eq(memberFriendships.requesterAccountId, actor.account.id), eq(memberFriendships.addresseeAccountId, target.accountId)),
    and(eq(memberFriendships.requesterAccountId, target.accountId), eq(memberFriendships.addresseeAccountId, actor.account.id)),
  )).limit(1);
  if (existing[0]?.status === "accepted") throw new Error("هذا العضو موجود في قائمة أصدقائك.");
  if (existing[0]?.status === "pending") {
    if (existing[0].addresseeAccountId === actor.account.id) {
      await db.update(memberFriendships).set({ status: "accepted", updatedAt: new Date() }).where(eq(memberFriendships.id, existing[0].id));
      return { status: "accepted" as const };
    }
    throw new Error("تم إرسال طلب الصداقة مسبقاً.");
  }
  await db.insert(memberFriendships).values({ requesterAccountId: actor.account.id, addresseeAccountId: target.accountId, status: "pending" });
  return { status: "pending" as const };
}

export async function respondToMemberFriend(token: string, friendshipId: number, status: "accepted" | "declined") {
  const actor = await getMemberContext(token);
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(memberFriendships).where(and(eq(memberFriendships.id, friendshipId), eq(memberFriendships.addresseeAccountId, actor.account.id))).limit(1);
  if (!rows[0]) throw new Error("طلب الصداقة غير موجود.");
  await db.update(memberFriendships).set({ status, updatedAt: new Date() }).where(eq(memberFriendships.id, friendshipId));
  return { status };
}

export async function areMemberAccountsFriends(firstSessionId: string, secondSessionId: string) {
  const first = await getChatSession(firstSessionId);
  const second = await getChatSession(secondSessionId);
  if (!first?.accountId || !second?.accountId) return false;
  const db = await getDb();
  if (!db) return false;
  const rows = await db.select({ id: memberFriendships.id }).from(memberFriendships).where(and(
    eq(memberFriendships.status, "accepted"),
    or(
      and(eq(memberFriendships.requesterAccountId, first.accountId), eq(memberFriendships.addresseeAccountId, second.accountId)),
      and(eq(memberFriendships.requesterAccountId, second.accountId), eq(memberFriendships.addresseeAccountId, first.accountId)),
    ),
  )).limit(1);
  return Boolean(rows[0]);
}

export async function listMemberFriends(token: string) {
  const actor = await getMemberContext(token);
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(memberFriendships).where(or(eq(memberFriendships.requesterAccountId, actor.account.id), eq(memberFriendships.addresseeAccountId, actor.account.id)));
  return Promise.all(rows.map(async (friendship) => {
    const otherId = friendship.requesterAccountId === actor.account.id ? friendship.addresseeAccountId : friendship.requesterAccountId;
    const account = await getMemberAccountById(otherId);
    if (!account) return null;
    return {
      id: friendship.id,
      status: friendship.status,
      direction: friendship.requesterAccountId === actor.account.id ? "outgoing" as const : "incoming" as const,
      profile: { sessionId: account.chatSessionId, displayName: account.alias, age: account.age, gender: account.gender, avatarKey: account.avatarKey, avatarMimeType: account.avatarMimeType },
    };
  })).then((friends) => friends.filter((friend): friend is NonNullable<typeof friend> => Boolean(friend)));
}

export type PublicRoom = Pick<ChatRoom, "id" | "name" | "isDefault" | "createdAt" | "backgroundKey" | "backgroundMimeType">;

export type PublicMember = Pick<
  ChatSession,
  "sessionId" | "displayName" | "age" | "gender" | "role" | "lastSeenAt" | "avatarKey" | "avatarMimeType" | "acceptsPrivateMessages" | "privateMessagePolicy" | "showPresence"
> & { isRegistered: boolean; isBlocked: boolean; hasBlockedViewer: boolean };

export type MessageWithSender = ChatMessage & {
  sender: Pick<ChatSession, "sessionId" | "displayName" | "gender"> | null;
  recipient: Pick<ChatSession, "sessionId" | "displayName" | "gender"> | null;
};

export const AI_FRIEND_SESSION_ID = "00000000-0000-0000-0000-aifriendbouh";
export const AI_SARAH_SESSION_ID = "00000000-0000-0000-0000-aisarahbouh";

export const AI_FRIEND_PROFILE = {
  sessionId: AI_FRIEND_SESSION_ID,
  displayName: "أحمد",
  age: 0,
  gender: "male" as const,
  role: "admin" as const,
  avatarKey: null,
  avatarMimeType: null,
  acceptsPrivateMessages: true,
  privateMessagePolicy: "everyone" as const,
  showPresence: true,
  isRegistered: false,
  lastSeenAt: new Date(),
  isBlocked: false,
  hasBlockedViewer: false,
};

export const AI_SARAH_PROFILE = {
  sessionId: AI_SARAH_SESSION_ID,
  displayName: "ساره",
  age: 0,
  gender: "female" as const,
  role: "admin" as const,
  avatarKey: null,
  avatarMimeType: null,
  acceptsPrivateMessages: true,
  privateMessagePolicy: "everyone" as const,
  showPresence: true,
  isRegistered: false,
  lastSeenAt: new Date(),
  isBlocked: false,
  hasBlockedViewer: false,
};

export const AI_ASSISTANTS = [AI_FRIEND_PROFILE, AI_SARAH_PROFILE] as const;

export function getAiAssistant(sessionId: string) {
  return AI_ASSISTANTS.find((assistant) => assistant.sessionId === sessionId);
}

const onlineCutoff = () => new Date(Date.now() - 45_000);

export async function getChatSession(sessionId: string): Promise<ChatSession | undefined> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(chatSessions).where(eq(chatSessions.sessionId, sessionId)).limit(1);
  return rows[0];
}

export async function createOrRefreshChatSession(
  input: Pick<InsertChatSession, "sessionId" | "displayName" | "age" | "gender"> & { role?: "member" | "admin"; accountId?: number | null; avatarKey?: string | null; avatarMimeType?: string | null; acceptsPrivateMessages?: boolean; privateMessagePolicy?: "everyone" | "friends" | "nobody"; showPresence?: boolean; networkFingerprint?: string | null; countryCode?: string | null }
): Promise<ChatSession> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");

  const current = await getChatSession(input.sessionId);
  if (current?.isBanned) throw new Error("تم تعطيل هذه الجلسة بواسطة الإدارة.");

  if (current) {
    await db
      .update(chatSessions)
      .set({
        displayName: input.displayName,
        age: input.age,
        gender: input.gender,
        role: input.role === "admin" ? "admin" : current.role,
        accountId: input.accountId ?? current.accountId ?? null,
        ...(input.avatarKey !== undefined ? { avatarKey: input.avatarKey } : {}),
        ...(input.avatarMimeType !== undefined ? { avatarMimeType: input.avatarMimeType } : {}),
        ...(input.acceptsPrivateMessages !== undefined ? { acceptsPrivateMessages: input.acceptsPrivateMessages } : {}),
        ...(input.privateMessagePolicy !== undefined ? { privateMessagePolicy: input.privateMessagePolicy } : {}),
        ...(input.showPresence !== undefined ? { showPresence: input.showPresence } : {}),
        networkFingerprint: input.networkFingerprint ?? current.networkFingerprint ?? null,
        countryCode: input.countryCode ?? current.countryCode ?? null,
        lastSeenAt: new Date(),
      })
      .where(eq(chatSessions.sessionId, input.sessionId));
  } else {
    await db.insert(chatSessions).values({
      sessionId: input.sessionId,
      displayName: input.displayName,
      age: input.age,
      gender: input.gender,
      role: input.role ?? "member",
      accountId: input.accountId ?? null,
      avatarKey: input.avatarKey ?? null,
      avatarMimeType: input.avatarMimeType ?? null,
      acceptsPrivateMessages: input.acceptsPrivateMessages ?? true,
      privateMessagePolicy: input.privateMessagePolicy ?? "everyone",
      showPresence: input.showPresence ?? true,
      networkFingerprint: input.networkFingerprint ?? null,
      countryCode: input.countryCode ?? null,
      lastSeenAt: new Date(),
    });
  }
  const session = await getChatSession(input.sessionId);
  if (!session) throw new Error("تعذر إنشاء جلسة الدردشة.");
  return session;
}

export async function requireActiveChatSession(sessionId: string): Promise<ChatSession> {
  const session = await getChatSession(sessionId);
  if (!session) throw new Error("انتهت الجلسة. سجّل الدخول من جديد.");
  if (session.isBanned) throw new Error("تم تعطيل هذه الجلسة بواسطة الإدارة.");
  return session;
}

export async function updateChatSessionPreferences(
  sessionId: string,
  input: { displayName?: string; acceptsPrivateMessages?: boolean; privateMessagePolicy?: "everyone" | "friends" | "nobody"; showPresence?: boolean; avatarKey?: string | null; avatarMimeType?: string | null; fontFamily?: string; textColor?: string; nameDecoration?: string }
): Promise<ChatSession> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const current = await requireActiveChatSession(sessionId);
  await db.update(chatSessions).set(input).where(eq(chatSessions.sessionId, sessionId));
  if (current.accountId) {
    const accountUpdate: Record<string, unknown> = {};
    if (input.displayName !== undefined) accountUpdate.alias = input.displayName;
    if (input.acceptsPrivateMessages !== undefined) accountUpdate.acceptsPrivateMessages = input.acceptsPrivateMessages;
    if (input.privateMessagePolicy !== undefined) accountUpdate.privateMessagePolicy = input.privateMessagePolicy;
    if (input.showPresence !== undefined) accountUpdate.showPresence = input.showPresence;
    if (input.avatarKey !== undefined) accountUpdate.avatarKey = input.avatarKey;
    if (input.avatarMimeType !== undefined) accountUpdate.avatarMimeType = input.avatarMimeType;
    if (input.fontFamily !== undefined) accountUpdate.fontFamily = input.fontFamily;
    if (input.textColor !== undefined) accountUpdate.textColor = input.textColor;
    if (input.nameDecoration !== undefined) accountUpdate.nameDecoration = input.nameDecoration;
    if (Object.keys(accountUpdate).length) await db.update(memberAccounts).set(accountUpdate).where(eq(memberAccounts.id, current.accountId));
  }
  const updated = await getChatSession(sessionId);
  if (!updated) throw new Error("انتهت الجلسة. سجّل الدخول من جديد.");
  return updated;
}

export async function setChatBlock(blockerSessionId: string, blockedSessionId: string, blocked: boolean) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await requireActiveChatSession(blockerSessionId);
  await requireActiveChatSession(blockedSessionId);
  if (blockerSessionId === blockedSessionId) throw new Error("لا يمكنك حظر نفسك.");
  if (blocked) {
    const existing = await db.select().from(chatBlocks).where(and(eq(chatBlocks.blockerSessionId, blockerSessionId), eq(chatBlocks.blockedSessionId, blockedSessionId))).limit(1);
    if (!existing[0]) await db.insert(chatBlocks).values({ blockerSessionId, blockedSessionId });
  } else {
    await db.delete(chatBlocks).where(and(eq(chatBlocks.blockerSessionId, blockerSessionId), eq(chatBlocks.blockedSessionId, blockedSessionId)));
  }
}

export async function areChatSessionsBlocked(firstSessionId: string, secondSessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select().from(chatBlocks).where(or(
    and(eq(chatBlocks.blockerSessionId, firstSessionId), eq(chatBlocks.blockedSessionId, secondSessionId)),
    and(eq(chatBlocks.blockerSessionId, secondSessionId), eq(chatBlocks.blockedSessionId, firstSessionId)),
  )).limit(1);
  return Boolean(rows[0]);
}

export async function getChatBlockStatus(viewerSessionId: string, targetSessionId: string) {
  const db = await getDb();
  if (!db) return { isBlocked: false, hasBlockedViewer: false };
  const rows = await db.select().from(chatBlocks).where(or(
    and(eq(chatBlocks.blockerSessionId, viewerSessionId), eq(chatBlocks.blockedSessionId, targetSessionId)),
    and(eq(chatBlocks.blockerSessionId, targetSessionId), eq(chatBlocks.blockedSessionId, viewerSessionId)),
  ));
  return {
    isBlocked: rows.some((row) => row.blockerSessionId === viewerSessionId),
    hasBlockedViewer: rows.some((row) => row.blockerSessionId === targetSessionId),
  };
}

export async function listChatBlockedMembers(blockerSessionId: string) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(chatBlocks).where(eq(chatBlocks.blockerSessionId, blockerSessionId));
  const members = await Promise.all(rows.map(async (row) => {
    const session = await getChatSession(row.blockedSessionId);
    if (!session) return null;
    return {
      sessionId: session.sessionId,
      displayName: session.displayName,
      gender: session.gender,
      avatarKey: session.avatarKey,
    };
  }));
  return members.filter((member): member is NonNullable<typeof member> => Boolean(member));
}

export async function touchChatSession(sessionId: string): Promise<ChatSession> {
  const session = await requireActiveChatSession(sessionId);
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.update(chatSessions).set({ lastSeenAt: new Date() }).where(eq(chatSessions.sessionId, sessionId));
  return { ...session, lastSeenAt: new Date() };
}

export async function getRooms(): Promise<PublicRoom[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: chatRooms.id, name: chatRooms.name, isDefault: chatRooms.isDefault, backgroundKey: chatRooms.backgroundKey, backgroundMimeType: chatRooms.backgroundMimeType, createdAt: chatRooms.createdAt }).from(chatRooms).orderBy(desc(chatRooms.isDefault), asc(chatRooms.name));
}

export async function getRoom(roomId: number): Promise<PublicRoom | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select({ id: chatRooms.id, name: chatRooms.name, isDefault: chatRooms.isDefault, backgroundKey: chatRooms.backgroundKey, backgroundMimeType: chatRooms.backgroundMimeType, createdAt: chatRooms.createdAt }).from(chatRooms).where(eq(chatRooms.id, roomId)).limit(1);
  return rows[0];
}

export async function createRoom(name: string, createdBySessionId: string): Promise<PublicRoom> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const result = await db.insert(chatRooms).values({ name, createdBySessionId });
  const room = await getRoom(Number(result[0].insertId));
  if (!room) throw new Error("تعذر إنشاء الغرفة.");
  return room;
}

export async function renameRoom(roomId: number, name: string): Promise<PublicRoom> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const room = await getRoom(roomId);
  if (!room) throw new Error("الغرفة غير موجودة.");
  if (room.isDefault) throw new Error("لا يمكن إعادة تسمية الغرفة العامة الافتراضية.");
  const duplicate = await db.select({ id: chatRooms.id }).from(chatRooms).where(eq(chatRooms.name, name)).limit(1);
  if (duplicate[0] && duplicate[0].id !== roomId) throw new Error("يوجد غرفة أخرى بهذا الاسم.");
  await db.update(chatRooms).set({ name }).where(eq(chatRooms.id, roomId));
  const updated = await getRoom(roomId);
  if (!updated) throw new Error("تعذر تحديث الغرفة.");
  return updated;
}

export async function updateRoomBackground(roomId: number, background: { backgroundKey: string | null; backgroundMimeType: string | null }): Promise<PublicRoom> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const room = await getRoom(roomId);
  if (!room) throw new Error("الغرفة غير موجودة.");
  await db.update(chatRooms).set(background).where(eq(chatRooms.id, roomId));
  const updated = await getRoom(roomId);
  if (!updated) throw new Error("تعذر تحديث خلفية الغرفة.");
  return updated;
}

export async function deleteRoom(roomId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const room = await getRoom(roomId);
  if (!room) throw new Error("الغرفة غير موجودة.");
  if (room.isDefault) throw new Error("لا يمكن حذف الغرفة العامة الافتراضية.");
  await db.update(chatSessions).set({ currentRoomId: 1 }).where(eq(chatSessions.currentRoomId, roomId));
  await db.delete(chatMessages).where(eq(chatMessages.roomId, roomId));
  await db.delete(chatRooms).where(eq(chatRooms.id, roomId));
}

export async function moveSessionToRoom(sessionId: string, roomId: number): Promise<ChatSession> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  if (!(await getRoom(roomId))) throw new Error("الغرفة غير موجودة.");
  await db.update(chatSessions).set({ currentRoomId: roomId, lastSeenAt: new Date() }).where(eq(chatSessions.sessionId, sessionId));
  const session = await getChatSession(sessionId);
  if (!session) throw new Error("انتهت الجلسة. سجّل الدخول من جديد.");
  return session;
}

/**
 * جلسات الدردشة لا تنتهي تلقائياً. نحتفظ بالدالة للتوافق مع الإصدارات
 * القديمة، لكن الحذف لا يحدث إلا عبر logout أو حذف الإدارة الصريح.
 */
export async function purgeExpiredChatSessions() {
  return 0;
}

export async function getOnlineMembers(roomId = 1, viewerSessionId?: string): Promise<PublicMember[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      sessionId: chatSessions.sessionId,
      accountId: chatSessions.accountId,
      displayName: chatSessions.displayName,
      age: chatSessions.age,
      gender: chatSessions.gender,
      role: chatSessions.role,
      avatarKey: chatSessions.avatarKey,
      avatarMimeType: chatSessions.avatarMimeType,
      acceptsPrivateMessages: chatSessions.acceptsPrivateMessages,
      privateMessagePolicy: chatSessions.privateMessagePolicy,
      showPresence: chatSessions.showPresence,
      countryCode: chatSessions.countryCode,
      lastSeenAt: chatSessions.lastSeenAt,
    })
    .from(chatSessions)
    .where(and(eq(chatSessions.isBanned, false), eq(chatSessions.currentRoomId, roomId)))
    .orderBy(asc(chatSessions.displayName))
    .then(async (members) => [
      ...AI_ASSISTANTS,
      ...(await Promise.all(members.map(async (member) => ({
        ...member,
        isRegistered: Boolean(member.accountId),
        ...(viewerSessionId ? await getChatBlockStatus(viewerSessionId, member.sessionId) : { isBlocked: false, hasBlockedViewer: false }),
      })))),
    ]);
}

async function enrichMessages(messages: ChatMessage[]): Promise<MessageWithSender[]> {
  const db = await getDb();
  if (!db || messages.length === 0) return messages.map((message) => ({ ...message, sender: null, recipient: null }));
  const ids = Array.from(
    new Set(messages.flatMap((message) => [message.senderSessionId, message.recipientSessionId]).filter(Boolean))
  ) as string[];
  const profiles = await Promise.all(ids.map((sessionId) => getChatSession(sessionId)));
  const profileMap = new Map(profiles.filter(Boolean).map((profile) => [profile!.sessionId, profile!]));
  return messages.map((message) => {
          const sender = profileMap.get(message.senderSessionId);
      const recipient = message.recipientSessionId ? profileMap.get(message.recipientSessionId) : undefined;
      const aiSender = getAiAssistant(message.senderSessionId) ?? null;
      const aiRecipient = message.recipientSessionId ? getAiAssistant(message.recipientSessionId) ?? null : null;

    return {
      ...message,
      body: message.deletedAt ? null : message.body,
      imageKey: message.deletedAt ? null : message.imageKey,
      imageMimeType: message.deletedAt ? null : message.imageMimeType,
      sender: sender ? { sessionId: sender.sessionId, displayName: sender.displayName, gender: sender.gender } : aiSender ? { sessionId: aiSender.sessionId, displayName: aiSender.displayName, gender: aiSender.gender } : null,
      recipient: recipient ? { sessionId: recipient.sessionId, displayName: recipient.displayName, gender: recipient.gender } : aiRecipient ? { sessionId: aiRecipient.sessionId, displayName: aiRecipient.displayName, gender: aiRecipient.gender } : null,
    };
  });
}

export async function getPublicMessages(roomId = 1, limit = 100): Promise<MessageWithSender[]> {
  const db = await getDb();
  if (!db) return [];
  const messages = await db
    .select()
    .from(chatMessages)
      .where(and(eq(chatMessages.channel, "public"), eq(chatMessages.roomId, roomId)))
    .orderBy(desc(chatMessages.createdAt), desc(chatMessages.id))
    .limit(limit);
  return enrichMessages(messages.reverse());
}

export async function getPrivateMessages(
  oneSessionId: string,
  otherSessionId: string,
  roomId = 1,
  limit = 100
): Promise<MessageWithSender[]> {
  const db = await getDb();
  if (!db) return [];
  const messages = await db
    .select()
    .from(chatMessages)
    .where(
      and(
        eq(chatMessages.channel, "private"),
        eq(chatMessages.roomId, roomId),
        or(
          and(eq(chatMessages.senderSessionId, oneSessionId), eq(chatMessages.recipientSessionId, otherSessionId)),
          and(eq(chatMessages.senderSessionId, otherSessionId), eq(chatMessages.recipientSessionId, oneSessionId))
        )
      )
    )
    .orderBy(desc(chatMessages.createdAt), desc(chatMessages.id))
    .limit(limit);
  return enrichMessages(messages.reverse());
}

export async function getUnreadPrivateMessageCounts(recipientSessionId: string): Promise<Record<string, number>> {
  const db = await getDb();
  if (!db) return {};
  const rows = await db
    .select({ senderSessionId: chatMessages.senderSessionId, unreadCount: count(chatMessages.id) })
    .from(chatMessages)
    .where(
      and(
        eq(chatMessages.channel, "private"),
        eq(chatMessages.recipientSessionId, recipientSessionId),
        isNull(chatMessages.readAt),
        isNull(chatMessages.deletedAt)
      )
    )
    .groupBy(chatMessages.senderSessionId);

  return Object.fromEntries(rows.map((row) => [row.senderSessionId, Number(row.unreadCount)]));
}

export async function getIncomingPrivateMessageSenderIds(recipientSessionId: string): Promise<string[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({ senderSessionId: chatMessages.senderSessionId })
    .from(chatMessages)
    .where(
      and(
        eq(chatMessages.channel, "private"),
        eq(chatMessages.recipientSessionId, recipientSessionId),
        isNull(chatMessages.deletedAt)
      )
    )
    .groupBy(chatMessages.senderSessionId);
  return rows.map((row) => row.senderSessionId);
}

export async function markPrivateMessagesAsRead(recipientSessionId: string, senderSessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db
    .update(chatMessages)
    .set({ readAt: new Date() })
    .where(
      and(
        eq(chatMessages.channel, "private"),
        eq(chatMessages.recipientSessionId, recipientSessionId),
        eq(chatMessages.senderSessionId, senderSessionId),
        isNull(chatMessages.readAt),
        isNull(chatMessages.deletedAt)
      )
    );
}

export async function addChatMessage(input: {
  channel: "public" | "private";
  roomId: number;
  senderSessionId: string;
  recipientSessionId?: string;
  body?: string | null;
  imageKey?: string;
  imageMimeType?: string;
}): Promise<MessageWithSender> {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const result = await db.insert(chatMessages).values({
    ...input,
    body: input.body ?? null,
    imageKey: input.imageKey ?? null,
    imageMimeType: input.imageMimeType ?? null,
  });
  const id = Number(result[0].insertId);
  const message = (await db.select().from(chatMessages).where(eq(chatMessages.id, id)).limit(1))[0];
  if (!message) throw new Error("تعذر حفظ الرسالة.");
  return (await enrichMessages([message]))[0]!;
}

export async function createChatReport(input: { reporterSessionId: string; targetSessionId?: string; messageId?: number; roomId?: number; channel?: "public" | "private"; reason: string; details?: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  if (!input.targetSessionId && !input.messageId) throw new Error("حدد الرسالة أو المستخدم المُبلّغ عنه.");
  if (input.messageId) {
    const existing = await db.select({ id: chatReports.id }).from(chatReports).where(and(eq(chatReports.reporterSessionId, input.reporterSessionId), eq(chatReports.messageId, input.messageId))).limit(1);
    if (existing.length) throw new Error("سبق إرسال بلاغ لهذه الرسالة.");
  } else {
    const existing = await db.select({ id: chatReports.id }).from(chatReports).where(and(eq(chatReports.reporterSessionId, input.reporterSessionId), eq(chatReports.targetSessionId, input.targetSessionId!))).limit(1);
    if (existing.length) throw new Error("سبق إرسال بلاغ لهذا المستخدم.");
  }
  const [created] = await db.insert(chatReports).values({ ...input, channel: input.channel ?? "public", details: input.details?.trim() || null }).$returningId();
  return { id: created.id };
}
export async function listChatReports() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatReports).orderBy(desc(chatReports.createdAt), desc(chatReports.id)).limit(200);
}
export async function updateChatReportStatus(id: number, status: "reviewed" | "dismissed" | "actioned", reviewedBySessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.update(chatReports).set({ status, reviewedBySessionId, reviewedAt: new Date() }).where(eq(chatReports.id, id));
}
export async function listAdminSessions(): Promise<ChatSession[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatSessions).where(eq(chatSessions.isBanned, false)).orderBy(desc(chatSessions.lastSeenAt));
}

export async function listAdminMessages(filters?: { roomId?: number; channel?: "public" | "private" }): Promise<MessageWithSender[]> {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.roomId) conditions.push(eq(chatMessages.roomId, filters.roomId));
  if (filters?.channel) conditions.push(eq(chatMessages.channel, filters.channel));
  const messages = await db
    .select()
    .from(chatMessages)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(chatMessages.createdAt), desc(chatMessages.id))
    .limit(150);
  return enrichMessages(messages);
}

export async function softDeleteMessage(id: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.update(chatMessages).set({ deletedAt: new Date() }).where(eq(chatMessages.id, id));
}

export async function deleteAllChatMessages() {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.delete(chatMessages);
}

export async function deleteRoomChatMessages(roomId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  await db.delete(chatMessages).where(eq(chatMessages.roomId, roomId));
}

export async function deleteFilteredChatMessages(filters?: { roomId?: number; channel?: "public" | "private" }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const conditions = [];
  if (filters?.roomId) conditions.push(eq(chatMessages.roomId, filters.roomId));
  if (filters?.channel) conditions.push(eq(chatMessages.channel, filters.channel));
  await db.delete(chatMessages).where(conditions.length ? and(...conditions) : undefined);
}

export async function isNetworkFingerprintBanned(networkFingerprint: string | null | undefined) {
  if (!networkFingerprint) return false;
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const rows = await db.select({ sessionId: chatSessions.sessionId }).from(chatSessions).where(and(eq(chatSessions.networkFingerprint, networkFingerprint), eq(chatSessions.isBanned, true))).limit(1);
  return rows.length > 0;
}

export async function banChatSession(targetSessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const target = await getChatSession(targetSessionId);
  await db.update(chatSessions).set({ isBanned: true, lastSeenAt: new Date() }).where(eq(chatSessions.sessionId, targetSessionId));
  if (target?.networkFingerprint) {
    await db.update(chatSessions).set({ isBanned: true, lastSeenAt: new Date() }).where(eq(chatSessions.networkFingerprint, target.networkFingerprint));
  }
  await db
    .update(chatMessages)
    .set({ deletedAt: new Date() })
    .where(or(eq(chatMessages.senderSessionId, targetSessionId), eq(chatMessages.recipientSessionId, targetSessionId)));
}

export function isChatMessageSentBySession(message: Pick<ChatMessage, "senderSessionId">, targetSessionId: string) {
  return message.senderSessionId === targetSessionId;
}

export async function deleteChatSession(targetSessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حالياً.");
  const session = await getChatSession(targetSessionId);
  if (session?.accountId) {
    await db.update(chatSessions).set({ lastSeenAt: new Date(0) }).where(eq(chatSessions.sessionId, targetSessionId));
    return;
  }
  await db.delete(chatMessages).where(eq(chatMessages.senderSessionId, targetSessionId));
  await db.delete(chatBlocks).where(or(eq(chatBlocks.blockerSessionId, targetSessionId), eq(chatBlocks.blockedSessionId, targetSessionId)));
  await db.delete(chatSessions).where(eq(chatSessions.sessionId, targetSessionId));
}
