import { describe, expect, it, vi } from "vitest";

const storage = vi.hoisted(() => ({
  storagePut: vi.fn(),
}));

vi.mock("./storage", () => ({
  storagePut: storage.storagePut,
}));

import { storeChatImage, storeProfileImage, storeRoomBackgroundImage } from "./chatMedia";

describe("storeChatImage", () => {
  it("accepts a correctly signed PNG and stores it under the chat image prefix", async () => {
    storage.storagePut.mockResolvedValue({ key: "chat-images/member/check.png", url: "https://example.test/check.png" });

    const result = await storeChatImage("member-session", {
      mimeType: "image/png",
      dataUrl: "data:image/png;base64,iVBORw0KGgo=",
    });

    expect(result).toEqual({ imageKey: "chat-images/member/check.png", imageMimeType: "image/png" });
    expect(storage.storagePut).toHaveBeenCalledWith(expect.stringMatching(/^chat-images\/member-session\//), expect.any(Buffer), "image/png");
  });

  it("stores a room background under the room-specific prefix", async () => {
    storage.storagePut.mockResolvedValue({ key: "room-backgrounds/12/member-session-bg.png", url: "https://example.test/bg.png" });

    const result = await storeRoomBackgroundImage("member-session", 12, {
      mimeType: "image/png",
      dataUrl: "data:image/png;base64,iVBORw0KGgo=",
    });

    expect(result).toEqual({ backgroundKey: "room-backgrounds/12/member-session-bg.png", backgroundMimeType: "image/png" });
    expect(storage.storagePut).toHaveBeenCalledWith(expect.stringMatching(/^room-backgrounds\/12\/member-session-/), expect.any(Buffer), "image/png");
  });

  it("stores a profile image under the profile image prefix", async () => {
    storage.storagePut.mockResolvedValue({ key: "profile-images/member/avatar.png", url: "https://example.test/avatar.png" });

    const result = await storeProfileImage("member-session", {
      mimeType: "image/png",
      dataUrl: "data:image/png;base64,iVBORw0KGgo=",
    });

    expect(result).toEqual({ avatarKey: "profile-images/member/avatar.png", avatarMimeType: "image/png" });
    expect(storage.storagePut).toHaveBeenCalledWith(expect.stringMatching(/^profile-images\/member-session\//), expect.any(Buffer), "image/png");
  });

  it("rejects a payload whose MIME type does not match its file signature", async () => {
    await expect(storeChatImage("member-session", {
      mimeType: "image/png",
      dataUrl: "data:image/png;base64,/9j/",
    })).rejects.toThrow("نوع ملف الصورة لا يطابق محتواه.");
  });
});
