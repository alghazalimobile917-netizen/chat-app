import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import { createHmac } from "node:crypto";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  networkFingerprint: string;
  countryCode: string | null;
};

const COUNTRY_HEADERS = [
  "x-country-code",
  "cf-ipcountry",
  "x-vercel-ip-country",
  "cloudfront-viewer-country",
  "x-geo-country",
  "x-country",
] as const;
const UNKNOWN_COUNTRY_CODES = new Set(["XX", "ZZ", "UN", "T1", "EU"]);
const COUNTRY_CODE_ALIASES: Record<string, string> = { UK: "GB", EL: "GR" };

export function normalizeCountryCode(value: unknown): string | null {
  const raw = Array.isArray(value) ? value[0] : value;
  if (typeof raw !== "string") return null;
  const firstCode = raw.trim().toUpperCase().split(/[\s,;|/_-]+/, 1)[0] ?? "";
  const code = COUNTRY_CODE_ALIASES[firstCode] ?? firstCode;
  return /^[A-Z]{2}$/.test(code) && !UNKNOWN_COUNTRY_CODES.has(code) ? code : null;
}

function deriveCountryCode(req: CreateExpressContextOptions["req"]): string | null {
  for (const name of COUNTRY_HEADERS) {
    const code = normalizeCountryCode(req.headers[name]);
    if (code) return code;
  }
  return null;
}

function deriveNetworkFingerprint(req: CreateExpressContextOptions["req"]): string {
  const forwarded = req.headers["x-forwarded-for"];
  const address = (typeof forwarded === "string" ? forwarded.split(",")[0] : forwarded?.[0]) || req.socket.remoteAddress || "unknown";
  const secret = process.env.JWT_SECRET || "bouh-network-fingerprint";
  return createHmac("sha256", secret).update(String(address).trim()).digest("hex");
}

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Authentication is optional for public procedures.
    user = null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
    networkFingerprint: deriveNetworkFingerprint(opts.req),
    countryCode: deriveCountryCode(opts.req),
  };
}
