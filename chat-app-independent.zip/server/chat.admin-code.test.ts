import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  addChatMessage: vi.fn(),
  areChatSessionsBlocked: vi.fn(),
  banChatSession: vi.fn(),
  isNetworkFingerprintBanned: vi.fn(() => false),
  createOrRefreshChatSession: vi.fn(),
  createRoom: vi.fn(),
  deleteRoom: vi.fn(),
  deleteChatSession: vi.fn(),
  deleteAllChatMessages: vi.fn(),
  deleteRoomChatMessages: vi.fn(),
  deleteFilteredChatMessages: vi.fn(),
  getChatSession: vi.fn(),
  getOnlineMembers: vi.fn(),
  purgeExpiredChatSessions: vi.fn(),
  getRooms: vi.fn(),
  getRoom: vi.fn(),
  moveSessionToRoom: vi.fn(),
  getPrivateMessages: vi.fn(),
  getIncomingPrivateMessageSenderIds: vi.fn(),
  getPublicMessages: vi.fn(),
  getUnreadPrivateMessageCounts: vi.fn(),
  listAdminMessages: vi.fn(),
  listAdminSessions: vi.fn(),
  listChatBlockedMembers: vi.fn(),
  markPrivateMessagesAsRead: vi.fn(),
  requireActiveChatSession: vi.fn(),
  setChatBlock: vi.fn(),
  renameRoom: vi.fn(),
  softDeleteMessage: vi.fn(),
  storeChatImage: vi.fn(),
  touchChatSession: vi.fn(),
  updateChatSessionPreferences: vi.fn(),
  updateRoomBackground: vi.fn(),
  listNameDecorations: vi.fn(() => [
    { id: 1, key: "none", label: "بدون زخرفة", prefix: "", suffix: "", enabled: true, sortOrder: 0 },
    { id: 2, key: "stars", label: "نجوم", prefix: "★ ", suffix: " ★", enabled: true, sortOrder: 1 },
    { id: 3, key: "hearts", label: "قلوب", prefix: "♥ ", suffix: " ♥", enabled: true, sortOrder: 2 },
    { id: 4, key: "diamonds", label: "ألماس", prefix: "◆ ", suffix: " ◆", enabled: true, sortOrder: 3 },
  ]),
  storeProfileImage: vi.fn(),
  storeRoomBackgroundImage: vi.fn(),
  invokeLLM: vi.fn(async () => ({ choices: [{ message: { content: JSON.stringify({ safe: true, reason: "اختبار آمن" }) } }] })),
  AI_FRIEND_PROFILE: {
    sessionId: "00000000-0000-0000-0000-aifriendbouh",
    displayName: "أحمد",
    age: 0,
    gender: "male",
    role: "admin",
    acceptsPrivateMessages: true,
  },
  AI_SARAH_PROFILE: {
    sessionId: "00000000-0000-0000-0000-aisarahbouh",
    displayName: "ساره",
    age: 0,
    gender: "female",
    role: "admin",
    acceptsPrivateMessages: true,
  },
  AI_FRIEND_SESSION_ID: "00000000-0000-0000-0000-aifriendbouh",
  AI_SARAH_SESSION_ID: "00000000-0000-0000-0000-aisarahbouh",
  getAiAssistant: vi.fn((sessionId: string) => sessionId === "00000000-0000-0000-0000-aifriendbouh" ? mocks.AI_FRIEND_PROFILE : sessionId === "00000000-0000-0000-0000-aisarahbouh" ? mocks.AI_SARAH_PROFILE : undefined),
}));

vi.mock("./db", () => ({
  addChatMessage: mocks.addChatMessage,
  areChatSessionsBlocked: mocks.areChatSessionsBlocked,
  banChatSession: mocks.banChatSession,
  isNetworkFingerprintBanned: mocks.isNetworkFingerprintBanned,
  createOrRefreshChatSession: mocks.createOrRefreshChatSession,
  createRoom: mocks.createRoom,
  deleteRoom: mocks.deleteRoom,
  deleteChatSession: mocks.deleteChatSession,
  deleteAllChatMessages: mocks.deleteAllChatMessages,
  deleteRoomChatMessages: mocks.deleteRoomChatMessages,
  deleteFilteredChatMessages: mocks.deleteFilteredChatMessages,
  getChatSession: mocks.getChatSession,
  getOnlineMembers: mocks.getOnlineMembers,
  purgeExpiredChatSessions: mocks.purgeExpiredChatSessions,
  getRooms: mocks.getRooms,
  getRoom: mocks.getRoom,
  moveSessionToRoom: mocks.moveSessionToRoom,
  getPrivateMessages: mocks.getPrivateMessages,
  getIncomingPrivateMessageSenderIds: mocks.getIncomingPrivateMessageSenderIds,
  getPublicMessages: mocks.getPublicMessages,
  getUnreadPrivateMessageCounts: mocks.getUnreadPrivateMessageCounts,
  listAdminMessages: mocks.listAdminMessages,
  listAdminSessions: mocks.listAdminSessions,
  listChatBlockedMembers: mocks.listChatBlockedMembers,
  markPrivateMessagesAsRead: mocks.markPrivateMessagesAsRead,
  requireActiveChatSession: mocks.requireActiveChatSession,
  setChatBlock: mocks.setChatBlock,
  renameRoom: mocks.renameRoom,
  softDeleteMessage: mocks.softDeleteMessage,
  touchChatSession: mocks.touchChatSession,
  updateChatSessionPreferences: mocks.updateChatSessionPreferences,
  updateRoomBackground: mocks.updateRoomBackground,
  listNameDecorations: mocks.listNameDecorations,
  AI_FRIEND_PROFILE: mocks.AI_FRIEND_PROFILE,
  AI_SARAH_PROFILE: mocks.AI_SARAH_PROFILE,
  AI_FRIEND_SESSION_ID: mocks.AI_FRIEND_SESSION_ID,
  AI_SARAH_SESSION_ID: mocks.AI_SARAH_SESSION_ID,
  getAiAssistant: mocks.getAiAssistant,
}));

vi.mock("./_core/llm", () => ({ invokeLLM: mocks.invokeLLM }));

vi.mock("./chatMedia", () => ({
  storeChatImage: mocks.storeChatImage,
  storeProfileImage: mocks.storeProfileImage,
  storeRoomBackgroundImage: mocks.storeRoomBackgroundImage,
}));

import { appRouter } from "./routers";

const memberSessionId = "11111111111111111111111111111111";
const peerSessionId = "22222222222222222222222222222222";
const adminSessionId = "33333333333333333333333333333333";

function caller(countryCode: string | null = "SA") {
  return appRouter.createCaller({ req: {} as never, res: {} as never, user: null, networkFingerprint: "test-fingerprint", countryCode });
}

describe("chat router", () => {
  beforeEach(() => {
    Object.values(mocks).filter((mock) => typeof mock === "function").forEach((mock) => (mock as ReturnType<typeof vi.fn>).mockReset());
    mocks.getAiAssistant.mockImplementation((sessionId: string) => sessionId === mocks.AI_FRIEND_SESSION_ID ? mocks.AI_FRIEND_PROFILE : sessionId === mocks.AI_SARAH_SESSION_ID ? mocks.AI_SARAH_PROFILE : undefined);
    mocks.listNameDecorations.mockResolvedValue([
      { id: 1, key: "none", label: "بدون زخرفة", prefix: "", suffix: "", enabled: true, sortOrder: 0 },
      { id: 2, key: "stars", label: "نجوم", prefix: "★ ", suffix: " ★", enabled: true, sortOrder: 1 },
      { id: 3, key: "hearts", label: "قلوب", prefix: "♥ ", suffix: " ♥", enabled: true, sortOrder: 2 },
      { id: 4, key: "diamonds", label: "ألماس", prefix: "◆ ", suffix: " ◆", enabled: true, sortOrder: 3 },
    ]);
    mocks.invokeLLM.mockResolvedValue({ choices: [{ message: { content: JSON.stringify({ safe: true, reason: "اختبار آمن" }) } }] });
  });

  it("allows an admin to update a room background", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: adminSessionId, role: "admin" });
    mocks.updateRoomBackground.mockResolvedValue({ id: 12, name: "الأصدقاء", isDefault: false, backgroundKey: "room-backgrounds/12/admin-bg.webp", backgroundMimeType: "image/webp", createdAt: new Date() });
    mocks.storeRoomBackgroundImage.mockResolvedValue({ backgroundKey: "room-backgrounds/12/admin-bg.webp", backgroundMimeType: "image/webp" });

    const result = await caller().chat.admin.updateRoomBackground({ sessionId: adminSessionId, roomId: 12, background: { mimeType: "image/webp", dataUrl: "data:image/webp;base64,UklGRg==" } });

    expect(result.backgroundKey).toBe("room-backgrounds/12/admin-bg.webp");
    expect(mocks.storeRoomBackgroundImage).toHaveBeenCalledWith(adminSessionId, 12, expect.objectContaining({ mimeType: "image/webp" }));
    expect(mocks.updateRoomBackground).toHaveBeenCalledWith(12, { backgroundKey: "room-backgrounds/12/admin-bg.webp", backgroundMimeType: "image/webp" });
  });

  it("accepts the configured secret and creates an admin session", async () => {
    const adminCode = process.env.ADMIN_ACCESS_CODE;
    expect(adminCode, "ADMIN_ACCESS_CODE must be configured").toBeTruthy();
    mocks.createOrRefreshChatSession.mockResolvedValue({
      sessionId: adminSessionId,
      displayName: "مدير نبض",
      age: 30,
      gender: "male",
      role: "admin",
      isBanned: false,
      lastSeenAt: new Date(),
      createdAt: new Date(),
    });

    const result = await caller().chat.createSession({
      sessionId: adminSessionId,
      displayName: "مدير نبض",
      age: 30,
      gender: "male",
      adminCode,
    });

    expect(result.profile.role).toBe("admin");
    expect(mocks.createOrRefreshChatSession).toHaveBeenCalledWith(expect.objectContaining({ role: "admin" }));
  });

  it("logs out by announcing that the member left the platform before deleting the session", async () => {
    mocks.getChatSession.mockResolvedValue({ sessionId: memberSessionId, displayName: "أحمد", currentRoomId: 1 });
    mocks.getRoom.mockResolvedValue({ id: 1, name: "العامة", isDefault: true });

    await caller().chat.logout({ sessionId: memberSessionId });

    expect(mocks.addChatMessage).toHaveBeenCalledWith({
      channel: "public",
      roomId: 1,
      senderSessionId: "00000000000000000000000000000000",
      body: "غادر أحمد المنصة.",
    });
    expect(mocks.deleteChatSession).toHaveBeenCalledWith(memberSessionId);
  });

  it("rejects the admin overview for a regular member", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member" });
    await expect(caller().chat.admin.overview({ sessionId: memberSessionId })).rejects.toThrow("هذه العملية متاحة للأدمن فقط");
  });

  it("returns the admin member list without purging persistent sessions", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: adminSessionId, role: "admin" });
    mocks.getRooms.mockResolvedValue([]);
    mocks.listAdminSessions.mockResolvedValue([{ sessionId: memberSessionId }]);
    mocks.listAdminMessages.mockResolvedValue([]);

    const result = await caller().chat.admin.overview({ sessionId: adminSessionId });

    expect(mocks.purgeExpiredChatSessions).not.toHaveBeenCalled();
    expect(result.members).toEqual([{ sessionId: memberSessionId }]);
  });

  it("creates a regular member session without an admin code", async () => {
    mocks.getChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member" });
    mocks.createOrRefreshChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member", currentRoomId: 1 });

    await caller().chat.createSession({ sessionId: memberSessionId, displayName: "أحمد", age: 25, gender: "male" });

    expect(mocks.createOrRefreshChatSession).toHaveBeenCalledWith(expect.objectContaining({ role: "member", gender: "male" }));
    expect(mocks.addChatMessage).not.toHaveBeenCalled();
  });

  it("passes the detected country code into a new guest session", async () => {
    mocks.getChatSession.mockResolvedValue(null);
    mocks.createOrRefreshChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member", currentRoomId: 1 });

    await caller("JO").chat.createSession({ sessionId: memberSessionId, displayName: "زائر الأردن", age: 25, gender: "male" });

    expect(mocks.createOrRefreshChatSession).toHaveBeenCalledWith(expect.objectContaining({ countryCode: "JO", networkFingerprint: "test-fingerprint" }));
  });

  it("adds one welcome message when a member joins the default room for the first time", async () => {
    mocks.getChatSession.mockResolvedValue(null);
    mocks.getRoom.mockResolvedValue({ id: 1, name: "العامة", isDefault: true });
    mocks.createOrRefreshChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member", displayName: "أحمد", currentRoomId: 1 });

    await caller().chat.createSession({ sessionId: memberSessionId, displayName: "أحمد", age: 25, gender: "male" });

    expect(mocks.addChatMessage).toHaveBeenCalledWith({
      channel: "public",
      roomId: 1,
      senderSessionId: "00000000000000000000000000000000",
      body: "انضم أحمد إلى العامة. أهلاً وسهلاً بك!",
    });
  });

  it("announces leaving the previous room and joining the next room", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: memberSessionId, displayName: "أحمد", currentRoomId: 1 });
    mocks.getRoom.mockImplementation(async (roomId: number) => roomId === 1 ? { id: 1, name: "العامة", isDefault: true } : { id: 2, name: "الأصدقاء", isDefault: false });
    mocks.moveSessionToRoom.mockResolvedValue({ sessionId: memberSessionId, displayName: "أحمد", currentRoomId: 2 });

    const result = await caller().chat.joinRoom({ sessionId: memberSessionId, roomId: 2 });

    expect(result.room).toEqual({ id: 2, name: "الأصدقاء", isDefault: false });
    expect(mocks.moveSessionToRoom).toHaveBeenCalledWith(memberSessionId, 2);
    expect(mocks.addChatMessage).toHaveBeenNthCalledWith(1, {
      channel: "public",
      roomId: 1,
      senderSessionId: "00000000000000000000000000000000",
      body: "غادر أحمد غرفة العامة.",
    });
    expect(mocks.addChatMessage).toHaveBeenNthCalledWith(2, {
      channel: "public",
      roomId: 2,
      senderSessionId: "00000000000000000000000000000000",
      body: "انضم أحمد إلى غرفة الأصدقاء. أهلاً وسهلاً بك!",
    });
  });

  it("refreshes a heartbeat without purging persistent sessions", async () => {
    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.getOnlineMembers.mockResolvedValue([]);
    await caller().chat.heartbeat({ sessionId: memberSessionId });
    expect(mocks.purgeExpiredChatSessions).not.toHaveBeenCalled();
    expect(mocks.touchChatSession).toHaveBeenCalledWith(memberSessionId);
  });

  it("refreshes the session and returns both online members and public messages", async () => {
    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.getRooms.mockResolvedValue([{ id: 1, name: "العامة", isDefault: true }]);
    mocks.getRoom.mockResolvedValue({ id: 1, name: "العامة", isDefault: true });
    mocks.getOnlineMembers.mockResolvedValue([{ sessionId: memberSessionId }]);
    mocks.getPublicMessages.mockResolvedValue([{ id: 1, body: "مرحباً" }]);
    mocks.getUnreadPrivateMessageCounts.mockResolvedValue({ [peerSessionId]: 2 });
    mocks.getIncomingPrivateMessageSenderIds.mockResolvedValue([peerSessionId]);

    const result = await caller().chat.bootstrap({ sessionId: memberSessionId });

    expect(mocks.touchChatSession).toHaveBeenCalledWith(memberSessionId);
    expect(result.onlineMembers).toHaveLength(1);
    expect(result.publicMessages).toHaveLength(1);
    expect(result.unreadPrivateCounts).toEqual({ [peerSessionId]: 2 });
    expect(result.incomingPrivateSenderIds).toEqual([peerSessionId]);
  });

  it("adds a public message after updating the sender presence", async () => {
    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.addChatMessage.mockResolvedValue({ id: 10, channel: "public" });

    await caller().chat.sendPublic({ sessionId: memberSessionId, body: "رسالة عامة للتحقق" });

    expect(mocks.addChatMessage).toHaveBeenCalledWith({ channel: "public", roomId: 1, senderSessionId: memberSessionId, body: "رسالة عامة للتحقق" });
  });

  it("stores a public image and records its storage metadata with the message", async () => {
    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.storeChatImage.mockResolvedValue({ imageKey: "chat-images/example.png", imageMimeType: "image/png" });
    mocks.addChatMessage.mockResolvedValue({ id: 11, channel: "public" });

    await caller().chat.sendPublic({
      sessionId: memberSessionId,
      body: "صورة للتحقق",
      image: { mimeType: "image/png", dataUrl: "data:image/png;base64,iVBORw0KGgo=" },
    });

    expect(mocks.storeChatImage).toHaveBeenCalledWith(memberSessionId, expect.objectContaining({ mimeType: "image/png" }));
    expect(mocks.addChatMessage).toHaveBeenCalledWith({
      channel: "public",
      roomId: 1,
      senderSessionId: memberSessionId,
      body: "صورة للتحقق",
      imageKey: "chat-images/example.png",
      imageMimeType: "image/png",
    });
  });

  it("creates a private message only after confirming the recipient is active", async () => {
    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: peerSessionId, role: "member", currentRoomId: 1 });
    mocks.addChatMessage.mockResolvedValue({ id: 14, channel: "private" });

    await caller().chat.sendPrivate({ sessionId: memberSessionId, peerSessionId, body: "رسالة خاصة للتحقق" });

    expect(mocks.requireActiveChatSession).toHaveBeenCalledWith(peerSessionId);
    expect(mocks.addChatMessage).toHaveBeenCalledWith({
      channel: "private",
      roomId: 1,
      senderSessionId: memberSessionId,
      recipientSessionId: peerSessionId,
      body: "رسالة خاصة للتحقق",
    });
  });

  it("sends a private question to صديقك and stores the Manus reply in the same room context", async () => {
    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: mocks.AI_FRIEND_SESSION_ID, role: "admin", currentRoomId: 1, acceptsPrivateMessages: true });
    mocks.addChatMessage
      .mockResolvedValueOnce({ id: 20, channel: "private", senderSessionId: memberSessionId, recipientSessionId: mocks.AI_FRIEND_SESSION_ID, body: "كيف حالك؟" })
      .mockResolvedValueOnce({ id: 21, channel: "private", senderSessionId: mocks.AI_FRIEND_SESSION_ID, recipientSessionId: memberSessionId, body: "أنا بخير، كيف أساعدك؟" });
    mocks.getPrivateMessages.mockResolvedValue([]);
    mocks.invokeLLM.mockResolvedValue({ choices: [{ message: { content: "أنا بخير، كيف أساعدك؟" } }] });

    const result = await caller().chat.sendPrivate({ sessionId: memberSessionId, peerSessionId: mocks.AI_FRIEND_SESSION_ID, body: "كيف حالك؟" });

    expect(mocks.invokeLLM).toHaveBeenCalledWith(expect.objectContaining({ messages: expect.arrayContaining([expect.objectContaining({ role: "system" })]) }));
    expect(mocks.addChatMessage).toHaveBeenNthCalledWith(2, {
      channel: "private",
      roomId: 1,
      senderSessionId: mocks.AI_FRIEND_SESSION_ID,
      recipientSessionId: memberSessionId,
      body: "أنا بخير، كيف أساعدك؟",
    });
    expect(result).toEqual(expect.objectContaining({ senderSessionId: mocks.AI_FRIEND_SESSION_ID, body: "أنا بخير، كيف أساعدك؟" }));
  });

  it("uses masculine identity for أحمد and feminine identity for ساره", async () => {
    expect(mocks.AI_FRIEND_PROFILE).toEqual(expect.objectContaining({ displayName: "أحمد", gender: "male" }));
    expect(mocks.AI_SARAH_PROFILE).toEqual(expect.objectContaining({ displayName: "ساره", gender: "female" }));

    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.addChatMessage
      .mockResolvedValueOnce({ id: 30, channel: "private", senderSessionId: memberSessionId, recipientSessionId: mocks.AI_SARAH_SESSION_ID, body: "كيف حالك؟" })
      .mockResolvedValueOnce({ id: 31, channel: "private", senderSessionId: mocks.AI_SARAH_SESSION_ID, recipientSessionId: memberSessionId, body: "أنا سعيدة بمساعدتك." });
    mocks.getPrivateMessages.mockResolvedValue([]);
    mocks.invokeLLM.mockResolvedValue({ choices: [{ message: { content: "أنا سعيدة بمساعدتك." } }] });

    await caller().chat.sendPrivate({ sessionId: memberSessionId, peerSessionId: mocks.AI_SARAH_SESSION_ID, body: "كيف حالك؟" });

    expect(mocks.invokeLLM).toHaveBeenCalledWith(expect.objectContaining({ messages: expect.arrayContaining([expect.objectContaining({ role: "system", content: expect.stringContaining("ساره") }), expect.objectContaining({ role: "system", content: expect.stringContaining("المؤنث") })]) }));
    expect(mocks.addChatMessage).toHaveBeenNthCalledWith(2, expect.objectContaining({ senderSessionId: mocks.AI_SARAH_SESSION_ID, recipientSessionId: memberSessionId }));
  });

  it("rejects a private message when the recipient disabled private messages", async () => {
    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: peerSessionId, role: "member", currentRoomId: 1, acceptsPrivateMessages: false });

    await expect(caller().chat.sendPrivate({ sessionId: memberSessionId, peerSessionId, body: "رسالة مرفوضة" })).rejects.toThrow("لا يستقبل رسائل خاصة");
    expect(mocks.addChatMessage).not.toHaveBeenCalled();
  });

  it("rejects private messages when either participant blocked the other", async () => {
    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: peerSessionId, role: "member", currentRoomId: 1, acceptsPrivateMessages: true });
    mocks.areChatSessionsBlocked.mockResolvedValue(true);

    await expect(caller().chat.sendPrivate({ sessionId: memberSessionId, peerSessionId, body: "رسالة محظورة" })).rejects.toThrow("بسبب الحظر");
    expect(mocks.addChatMessage).not.toHaveBeenCalled();
  });

  it("updates private-message preference and profile image", async () => {
    mocks.updateChatSessionPreferences.mockResolvedValue({ sessionId: memberSessionId, acceptsPrivateMessages: false, avatarKey: "profile-images/member/avatar.png", avatarMimeType: "image/png" });
    mocks.storeProfileImage.mockResolvedValue({ avatarKey: "profile-images/member/avatar.png", avatarMimeType: "image/png" });

    const result = await caller().chat.updatePreferences({
      sessionId: memberSessionId,
      acceptsPrivateMessages: false,
      image: { mimeType: "image/png", dataUrl: "data:image/png;base64,iVBORw0KGgo=" },
    });

    expect(mocks.storeProfileImage).toHaveBeenCalledWith(memberSessionId, expect.objectContaining({ mimeType: "image/png" }));
    expect(mocks.updateChatSessionPreferences).toHaveBeenCalledWith(memberSessionId, expect.objectContaining({ acceptsPrivateMessages: false, avatarKey: "profile-images/member/avatar.png" }));
    expect(result.profile.acceptsPrivateMessages).toBe(false);
  });

  it("creates and removes a member block", async () => {
    mocks.requireActiveChatSession.mockImplementation(async (sessionId: string) => ({ sessionId, role: "member" }));
    mocks.setChatBlock.mockResolvedValue(undefined);

    await expect(caller().chat.setBlock({ sessionId: memberSessionId, targetSessionId: peerSessionId, blocked: true })).resolves.toEqual({ success: true, blocked: true });
    expect(mocks.setChatBlock).toHaveBeenCalledWith(memberSessionId, peerSessionId, true);
  });

  it("lists blocked members and supports unblocking them", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member" });
    mocks.listChatBlockedMembers.mockResolvedValue([{ sessionId: peerSessionId, displayName: "سوسو", gender: "female", avatarKey: null }]);
    mocks.setChatBlock.mockResolvedValue(undefined);

    const listed = await caller().chat.blockedMembers({ sessionId: memberSessionId });
    expect(listed.members).toEqual([expect.objectContaining({ sessionId: peerSessionId, displayName: "سوسو" })]);

    await expect(caller().chat.setBlock({ sessionId: memberSessionId, targetSessionId: peerSessionId, blocked: false })).resolves.toEqual({ success: true, blocked: false });
    expect(mocks.setChatBlock).toHaveBeenLastCalledWith(memberSessionId, peerSessionId, false);
  });

  it("returns a private conversation only after validating both active participants", async () => {
    mocks.touchChatSession.mockResolvedValue({ sessionId: memberSessionId, currentRoomId: 1 });
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: peerSessionId, role: "member", currentRoomId: 1 });
    mocks.getPrivateMessages.mockResolvedValue([{ id: 15, body: "رسالة خاصة" }]);
    mocks.getUnreadPrivateMessageCounts.mockResolvedValue({});

    const result = await caller().chat.privateMessages({ sessionId: memberSessionId, peerSessionId });

    expect(mocks.getPrivateMessages).toHaveBeenCalledWith(memberSessionId, peerSessionId, 1);
    expect(mocks.markPrivateMessagesAsRead).toHaveBeenCalledWith(memberSessionId, peerSessionId);
    expect(mocks.getUnreadPrivateMessageCounts).toHaveBeenCalledWith(memberSessionId);
    expect(result.messages).toHaveLength(1);
    expect(result.unreadPrivateCounts).toEqual({});
  });

  it("allows an admin to create a room and prevents a member from doing so", async () => {
    mocks.requireActiveChatSession.mockImplementation(async (sessionId: string) => ({
      sessionId,
      role: sessionId === adminSessionId ? "admin" : "member",
    }));
    mocks.createRoom.mockResolvedValue({ id: 2, name: "غرفة الأصدقاء", isDefault: false });

    await expect(caller().chat.admin.createRoom({ sessionId: memberSessionId, name: "غرفة الأصدقاء" })).rejects.toThrow("هذه العملية متاحة للأدمن فقط.");
    await expect(caller().chat.admin.createRoom({ sessionId: adminSessionId, name: "غرفة الأصدقاء" })).resolves.toMatchObject({ id: 2, name: "غرفة الأصدقاء" });
    expect(mocks.createRoom).toHaveBeenCalledWith("غرفة الأصدقاء", adminSessionId);
  });

  it("allows an admin to rename a non-default room and prevents a member from doing so", async () => {
    mocks.requireActiveChatSession.mockImplementation(async (sessionId: string) => ({
      sessionId,
      role: sessionId === adminSessionId ? "admin" : "member",
    }));
    mocks.renameRoom.mockResolvedValue({ id: 2, name: "غرفة العائلة", isDefault: false });

    await expect(caller().chat.admin.renameRoom({ sessionId: memberSessionId, roomId: 2, name: "غرفة العائلة" })).rejects.toThrow("هذه العملية متاحة للأدمن فقط.");
    await expect(caller().chat.admin.renameRoom({ sessionId: adminSessionId, roomId: 2, name: "غرفة العائلة" })).resolves.toMatchObject({ id: 2, name: "غرفة العائلة" });
    expect(mocks.renameRoom).toHaveBeenCalledWith(2, "غرفة العائلة");
  });

  it("allows an admin to delete a non-default room and blocks the default room through the db contract", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: adminSessionId, role: "admin" });
    mocks.deleteRoom.mockResolvedValue(undefined);

    await expect(caller().chat.admin.deleteRoom({ sessionId: adminSessionId, roomId: 2 })).resolves.toEqual({ success: true, roomId: 2 });
    expect(mocks.deleteRoom).toHaveBeenCalledWith(2);
  });

  it("prevents a member from deleting a room", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member" });

    await expect(caller().chat.admin.deleteRoom({ sessionId: memberSessionId, roomId: 2 })).rejects.toThrow("هذه العملية متاحة للأدمن فقط.");
    expect(mocks.deleteRoom).not.toHaveBeenCalled();
  });

  it("allows an admin to delete public and private messages", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: adminSessionId, role: "admin" });
    mocks.softDeleteMessage.mockResolvedValue(undefined);

    await expect(caller().chat.admin.deleteMessage({ sessionId: adminSessionId, messageId: 7 })).resolves.toEqual({ success: true });
    await expect(caller().chat.admin.deleteMessage({ sessionId: adminSessionId, messageId: 8 })).resolves.toEqual({ success: true });
    expect(mocks.softDeleteMessage).toHaveBeenNthCalledWith(1, 7);
    expect(mocks.softDeleteMessage).toHaveBeenNthCalledWith(2, 8);
  });

  it("allows an admin to delete all messages", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: adminSessionId, role: "admin" });
    mocks.deleteAllChatMessages.mockResolvedValue(undefined);

    await expect(caller().chat.admin.deleteAllMessages({ sessionId: adminSessionId })).resolves.toEqual({ success: true });
    expect(mocks.deleteAllChatMessages).toHaveBeenCalledTimes(1);
  });

  it("deletes filtered messages and blocks filtering the default room", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: adminSessionId, role: "admin" });
    mocks.getRoom.mockImplementation(async (roomId: number) => roomId === 1 ? { id: 1, name: "العامة", isDefault: true } : { id: 2, name: "الأصدقاء", isDefault: false });
    mocks.deleteFilteredChatMessages.mockResolvedValue(undefined);

    await expect(caller().chat.admin.deleteFilteredMessages({ sessionId: adminSessionId, roomId: 2, channel: "public" })).resolves.toEqual({ success: true });
    expect(mocks.deleteFilteredChatMessages).toHaveBeenCalledWith({ roomId: 2, channel: "public" });
    await expect(caller().chat.admin.deleteFilteredMessages({ sessionId: adminSessionId, roomId: 1 })).rejects.toThrow("لا يمكن حذف رسائل الغرفة العامة");
  });

  it("allows an admin to disable a non-admin member", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: adminSessionId, role: "admin" });
    mocks.getChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member" });

    await expect(caller().chat.admin.banMember({ sessionId: adminSessionId, targetSessionId: memberSessionId })).resolves.toEqual({ success: true });
    expect(mocks.banChatSession).toHaveBeenCalledWith(memberSessionId);
  });

  it("allows an admin to permanently remove a non-admin member", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: adminSessionId, role: "admin" });
    mocks.getChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member" });

    await expect(caller().chat.admin.deleteMember({ sessionId: adminSessionId, targetSessionId: memberSessionId })).resolves.toEqual({ success: true });
    expect(mocks.deleteChatSession).toHaveBeenCalledWith(memberSessionId);
  });

  it("prevents a member from accessing administrative data", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: memberSessionId, role: "member" });

    await expect(caller().chat.admin.overview({ sessionId: memberSessionId })).rejects.toThrow("هذه العملية متاحة للأدمن فقط.");
  });

  it("prevents an admin from deleting their own administrative session", async () => {
    mocks.requireActiveChatSession.mockResolvedValue({ sessionId: adminSessionId, role: "admin" });

    await expect(caller().chat.admin.deleteMember({ sessionId: adminSessionId, targetSessionId: adminSessionId })).rejects.toThrow("لا يمكنك حذف جلستك الإدارية.");
  });

  it("rejects a regular member who tries to claim a reserved admin name", async () => {
    await expect(caller().chat.createSession({ sessionId: memberSessionId, displayName: "admin", age: 25, gender: "male" })).rejects.toThrow("اسم الإدارة محجوز");
    expect(mocks.createOrRefreshChatSession).not.toHaveBeenCalled();
  });

  it("allows a reserved admin name only with the configured admin password", async () => {
    const adminCode = process.env.ADMIN_ACCESS_CODE;
    expect(adminCode, "ADMIN_ACCESS_CODE must be configured").toBeTruthy();
    mocks.createOrRefreshChatSession.mockResolvedValue({ sessionId: adminSessionId, displayName: "الإدارة", age: 30, gender: "male", role: "admin" });

    await expect(caller().chat.createSession({ sessionId: adminSessionId, displayName: "الإدارة", age: 30, gender: "male", adminCode })).resolves.toMatchObject({ profile: { role: "admin" } });
  });
});


describe("network fingerprint bans", () => {
  it("rejects a new session when its network fingerprint is banned", async () => {
    mocks.createOrRefreshChatSession.mockClear();
    mocks.getChatSession.mockResolvedValue(null);
    mocks.isNetworkFingerprintBanned.mockResolvedValue(true);

    await expect(caller().chat.createSession({ sessionId: memberSessionId, displayName: "زائر جديد", age: 25, gender: "male" })).rejects.toThrow("تم منع هذا الاتصال");
    expect(mocks.createOrRefreshChatSession).not.toHaveBeenCalled();
  });
});
