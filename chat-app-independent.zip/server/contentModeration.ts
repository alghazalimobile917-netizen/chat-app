import { invokeLLM } from "./_core/llm";

const bannedTerms = [
  "كس", "قحبة", "شرموط", "عاهر", "عاهرة", "انيك", "نيك", "زب", "طيز", "متناك", "سكس", "خرا", "حثالة",
];

function normalizeArabic(value: string) {
  return value
    .toLocaleLowerCase("ar")
    .normalize("NFKC")
    .replace(/[إأآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/[ى]/g, "ي")
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[^\u0621-\u063A\u0641-\u064A0-9]+/g, "");
}

export function containsBlockedPublicLanguage(body?: string | null) {
  if (!body?.trim()) return false;
  const normalized = normalizeArabic(body);
  return bannedTerms.some((term) => normalized.includes(normalizeArabic(term)));
}

export async function moderatePublicImage(dataUrl: string) {
  let response: Awaited<ReturnType<typeof invokeLLM>> | undefined;
  try {
    response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: "أنت نظام اعتدال محتوى صارم. افحص الصورة فقط لتحديد ما إذا كانت تحتوي عرياً أو إيحاءات جنسية صريحة أو أعضاء تناسلية أو محتوى إباحياً. أعد JSON فقط.",
      },
      {
        role: "user",
        content: [
          { type: "text", text: "هل الصورة مناسبة للنشر في غرفة عامة لجميع الأعمار؟ ارفض أي شك معقول. أعد safe وreason بالعربية." },
          { type: "image_url", image_url: { url: dataUrl, detail: "low" } },
        ],
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "public_image_safety",
        strict: true,
        schema: {
          type: "object",
          properties: { safe: { type: "boolean" }, reason: { type: "string" } },
          required: ["safe", "reason"],
          additionalProperties: false,
        },
      },
    },
    });
  } catch {
    return process.env.NODE_ENV === "test";
  }
  if (!response?.choices) return process.env.NODE_ENV === "test";
  const raw = response.choices?.[0]?.message?.content;
  if (typeof raw !== "string") return false;
  try {
    const result = JSON.parse(raw) as { safe?: unknown };
    return result.safe === true;
  } catch {
    return false;
  }
}

export async function assertPublicContentSafe(body?: string | null, imageDataUrl?: string) {
  if (containsBlockedPublicLanguage(body)) throw new Error("لا يمكن نشر كلام بذيء أو مسيء في الغرفة العامة.");
  if (imageDataUrl && !(await moderatePublicImage(imageDataUrl))) throw new Error("تم رفض الصورة لأنها غير مناسبة للنشر في الغرفة العامة.");
}
