import { storagePut } from "./storage";

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const SUPPORTED_IMAGE_TYPES = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "image/gif": "gif",
} as const;

type SupportedImageMimeType = keyof typeof SUPPORTED_IMAGE_TYPES;

export type ChatImageUpload = {
  dataUrl: string;
  mimeType: SupportedImageMimeType;
};

function hasExpectedSignature(buffer: Buffer, mimeType: SupportedImageMimeType) {
  if (mimeType === "image/png") return buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  if (mimeType === "image/jpeg") return buffer.subarray(0, 3).equals(Buffer.from([255, 216, 255]));
  if (mimeType === "image/gif") return buffer.subarray(0, 6).toString("ascii") === "GIF87a" || buffer.subarray(0, 6).toString("ascii") === "GIF89a";
  return buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP";
}

function decodeImage(dataUrl: string, mimeType: SupportedImageMimeType) {
  const prefix = `data:${mimeType};base64,`;
  if (!dataUrl.startsWith(prefix)) throw new Error("صيغة الصورة غير صالحة.");

  const encoded = dataUrl.slice(prefix.length);
  if (!encoded || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) throw new Error("تعذر قراءة ملف الصورة.");

  const buffer = Buffer.from(encoded, "base64");
  if (!buffer.length || buffer.length > MAX_IMAGE_BYTES) throw new Error("يجب ألا يتجاوز حجم الصورة 5 ميغابايت.");
  if (!hasExpectedSignature(buffer, mimeType)) throw new Error("نوع ملف الصورة لا يطابق محتواه.");
  return buffer;
}

export async function storeChatImage(sessionId: string, image: ChatImageUpload) {
  const buffer = decodeImage(image.dataUrl, image.mimeType);
  const extension = SUPPORTED_IMAGE_TYPES[image.mimeType];
  const { key } = await storagePut(`chat-images/${sessionId}/${Date.now()}.${extension}`, buffer, image.mimeType);
  return { imageKey: key, imageMimeType: image.mimeType };
}

export async function storeProfileImage(sessionId: string, image: ChatImageUpload) {
  const buffer = decodeImage(image.dataUrl, image.mimeType);
  const extension = SUPPORTED_IMAGE_TYPES[image.mimeType];
  const { key } = await storagePut(`profile-images/${sessionId}/${Date.now()}.${extension}`, buffer, image.mimeType);
  return { avatarKey: key, avatarMimeType: image.mimeType };
}

export async function storeRoomBackgroundImage(sessionId: string, roomId: number, image: ChatImageUpload) {
  const buffer = decodeImage(image.dataUrl, image.mimeType);
  const extension = SUPPORTED_IMAGE_TYPES[image.mimeType];
  const { key } = await storagePut(`room-backgrounds/${roomId}/${sessionId}-${Date.now()}.${extension}`, buffer, image.mimeType);
  return { backgroundKey: key, backgroundMimeType: image.mimeType };
}
