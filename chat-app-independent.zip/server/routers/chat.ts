import { nanoid } from "nanoid";
import { z } from "zod";
import {
  addChatMessage,
  areChatSessionsBlocked,
  areMemberAccountsFriends,
  authenticateMember,
  createMemberAccount,
  getMemberAccountByEmail,
  getMemberAccountByAlias,
  getMemberContext,
  listMemberFriends,
  logoutMemberSession,
  requestMemberFriend,
  respondToMemberFriend,
  startMemberSession,
  banChatSession,
  isNetworkFingerprintBanned,
  createOrRefreshChatSession,
  createRoom,
  deleteRoom,
  deleteChatSession,
  deleteAllChatMessages,
  deleteRoomChatMessages,
  deleteFilteredChatMessages,
  getChatSession,
  getOnlineMembers,
  getPrivateMessages,
  getIncomingPrivateMessageSenderIds,
  getPublicMessages,
  getRoom,
  getRooms,
  getUnreadPrivateMessageCounts,
  listAdminMessages,
  listAdminSessions,
  listChatBlockedMembers,
  markPrivateMessagesAsRead,
  moveSessionToRoom,
  requireActiveChatSession,
  setChatBlock,
  renameRoom,
  softDeleteMessage,
  touchChatSession,
  updateChatSessionPreferences,
  getAiAssistant,
  createChatReport,
  listChatReports,
  updateChatReportStatus,
  updateRoomBackground,
  listPinnedConversations,
  setPinnedConversation,
  listNameDecorations,
  createNameDecoration,
  updateNameDecoration,
  deleteNameDecoration,
} from "../db";
import { storeChatImage, storeProfileImage, storeRoomBackgroundImage } from "../chatMedia";
import { invokeLLM } from "../_core/llm";
import { assertPublicContentSafe } from "../contentModeration";
import { publicProcedure, router } from "../_core/trpc";
import { BOUH_SYSTEM_SESSION_ID } from "@shared/const";
import { decorateDisplayName, decorateWithWrapper, type NameDecoration } from "@shared/nameDecoration";

const sessionIdSchema = z.string().min(24).max(64);
const identitySchema = z.object({
  sessionId: sessionIdSchema,
  displayName: z.string().trim().min(2, "الاسم يجب أن يحتوي حرفين على الأقل.").max(40),
  age: z.number().int().min(1).max(120),
  gender: z.enum(["male", "female"]),
  adminCode: z.string().trim().min(1).max(128).optional(),
  nameDecoration: z.string().trim().min(1).max(32).optional(),
});
const imageSchema = z.object({
  dataUrl: z.string().max(7_000_000, "حجم الصورة يتجاوز الحد المسموح."),
  mimeType: z.enum(["image/png", "image/jpeg", "image/webp", "image/gif"]),
});
const messageContentShape = {
  body: z.string().trim().max(1200, "الرسالة طويلة جداً.").optional(),
  image: imageSchema.optional(),
};
const messageContentSchema = z
  .object(messageContentShape)
  .refine((content) => Boolean(content.body?.trim() || content.image), "أرسل نصاً أو صورة واحدة على الأقل.");

async function prepareMessageContent(sessionId: string, content: z.infer<typeof messageContentSchema>) {
  const image = content.image ? await storeChatImage(sessionId, content.image) : undefined;
  return {
    body: content.body?.trim() || null,
    ...image,
  };
}

function extractAssistantText(response: Awaited<ReturnType<typeof invokeLLM>>) {
  const content = response.choices?.[0]?.message?.content;
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) return content.filter((part) => part.type === "text").map((part) => part.text).join("\n").trim();
  return "";
}

const RESERVED_ADMIN_NAMES = new Set(["الادارة", "الإدارة", "admin", "administrator"]);

function isReservedAdminName(displayName: string) {
  return RESERVED_ADMIN_NAMES.has(displayName.trim().toLocaleLowerCase("ar"));
}

function isValidAdminCode(code?: string) {
  const configuredCode = process.env.ADMIN_ACCESS_CODE;
  return Boolean(configuredCode && code && code === configuredCode);
}

async function resolveNameDecoration(key?: string) {
  const availableDecorations = await listNameDecorations();
  const decoration = availableDecorations.find((item) => item.key === (key ?? "none"));
  if (!decoration) throw new Error("زخرفة الاسم غير متاحة حالياً.");
  return decoration;
}

function applyNameDecoration(name: string, decoration: Awaited<ReturnType<typeof resolveNameDecoration>>) {
  return decoration.key in { none: true, stars: true, hearts: true, diamonds: true }
    ? decorateDisplayName(name, decoration.key as NameDecoration)
    : decorateWithWrapper(name, decoration.prefix, decoration.suffix);
}

const TYPING_TTL_MS = 6_000;
const typingStates = new Map<string, { peerSessionId: string; updatedAt: number }>();
const publicTypingStates = new Map<string, { roomId: number; updatedAt: number }>();

async function addSystemNotice(roomId: number, body: string) {
  try {
    return await addChatMessage({
      channel: "public",
      roomId,
      senderSessionId: BOUH_SYSTEM_SESSION_ID,
      body,
    });
  } catch {
    // إشعار النظام تحسين غير حاجب؛ لا ينبغي أن يمنع دخول العضو أو خروجه.
    return null;
  }
}

function cleanupTypingStates() {
  const now = Date.now();
  typingStates.forEach((state, sessionId) => {
    if (now - state.updatedAt > TYPING_TTL_MS) typingStates.delete(sessionId);
  });
  publicTypingStates.forEach((state, sessionId) => {
    if (now - state.updatedAt > TYPING_TTL_MS) publicTypingStates.delete(sessionId);
  });
}

function isPeerTyping(viewerSessionId: string, peerSessionId: string) {
  cleanupTypingStates();
  const state = typingStates.get(peerSessionId);
  return Boolean(state && state.peerSessionId === viewerSessionId && Date.now() - state.updatedAt <= TYPING_TTL_MS);
}

async function requireAdmin(sessionId: string) {
  const session = await requireActiveChatSession(sessionId);
  if (session.role !== "admin") throw new Error("هذه العملية متاحة للأدمن فقط.");
  return session;
}

export const chatRouter = router({
  logout: publicProcedure.input(z.object({ sessionId: sessionIdSchema, memberToken: z.string().min(40).max(128).optional() })).mutation(async ({ input }) => {
    const session = await getChatSession(input.sessionId);
    if (session) {
      const room = await getRoom(session.currentRoomId);
      if (room) await addSystemNotice(room.id, `غادر ${session.displayName} المنصة.`);
    }
    if (input.memberToken) await logoutMemberSession(input.memberToken);
    else await deleteChatSession(input.sessionId);
    return { success: true };
  }),

  registerMember: publicProcedure.input(z.object({
    email: z.string().trim().email("أدخل بريداً إلكترونياً صحيحاً.").max(320),
    password: z.string().min(8, "كلمة السر يجب أن تتكون من 8 أحرف على الأقل.").max(128),
    alias: z.string().trim().min(2, "الاسم المستعار يجب أن يحتوي حرفين على الأقل.").max(40),
    age: z.number().int().min(13, "يجب أن يكون عمر العضو 13 عاماً على الأقل.").max(120),
    gender: z.enum(["male", "female"]),
    nameDecoration: z.string().trim().min(1).max(32).optional(),
  })).mutation(async ({ input, ctx }) => {
    if (isReservedAdminName(input.alias)) throw new Error("هذا الاسم محجوز للإدارة.");
    const availableDecorations = await listNameDecorations();
    const decoration = availableDecorations.find((item) => item.key === (input.nameDecoration ?? "none"));
    if (!decoration) throw new Error("زخرفة الاسم غير متاحة حالياً.");
    const account = await createMemberAccount({ ...input, nameDecoration: decoration.key });
    const result = await startMemberSession(account, { countryCode: ctx.countryCode });
    return { memberToken: result.token, expiresAt: result.expiresAt, account: result.account, profile: result.profile, generatedAt: new Date() };
  }),

  loginMember: publicProcedure.input(z.object({
    email: z.string().trim().email("أدخل بريداً إلكترونياً صحيحاً.").max(320),
    password: z.string().min(1).max(128),
    nameDecoration: z.string().trim().min(1).max(32).optional(),
  })).mutation(async ({ input, ctx }) => {
    const result = await authenticateMember(input.email, input.password, { countryCode: ctx.countryCode });
    if (input.nameDecoration) {
      const decoration = (await listNameDecorations()).find((item) => item.key === input.nameDecoration);
      if (!decoration) throw new Error("زخرفة الاسم غير متاحة حالياً.");
      const decoratedName = decoration.key in { none: true, stars: true, hearts: true, diamonds: true }
        ? decorateDisplayName(result.account.alias, input.nameDecoration as NameDecoration)
        : decorateWithWrapper(result.account.alias, decoration.prefix, decoration.suffix);
      const profile = await updateChatSessionPreferences(result.profile.sessionId, { displayName: decoratedName, nameDecoration: decoration.key });
      return { memberToken: result.token, expiresAt: result.expiresAt, account: { ...result.account, alias: decoratedName, nameDecoration: decoration.key }, profile, generatedAt: new Date() };
    }
    return { memberToken: result.token, expiresAt: result.expiresAt, account: result.account, profile: result.profile, generatedAt: new Date() };
  }),

  memberMe: publicProcedure.input(z.object({ memberToken: z.string().min(40).max(128) })).query(async ({ input }) => {
    const result = await getMemberContext(input.memberToken);
    return { account: { id: result.account.id, alias: result.account.alias, age: result.account.age, gender: result.account.gender, avatarKey: result.account.avatarKey, avatarMimeType: result.account.avatarMimeType, acceptsPrivateMessages: result.account.acceptsPrivateMessages, privateMessagePolicy: result.account.privateMessagePolicy, showPresence: result.account.showPresence, fontFamily: result.account.fontFamily, textColor: result.account.textColor, nameDecoration: result.account.nameDecoration }, profile: result.profile, generatedAt: new Date() };
  }),

  createSession: publicProcedure.input(identitySchema).mutation(async ({ input, ctx }) => {
    const existingSession = await getChatSession(input.sessionId);
    if (!existingSession && await isNetworkFingerprintBanned(ctx.networkFingerprint)) {
      throw new Error("تم منع هذا الاتصال من دخول الدردشة.");
    }
    const reservedAdminName = isReservedAdminName(input.displayName);
    const wantsAdmin = Boolean(input.adminCode);
    if (reservedAdminName && !process.env.ADMIN_ACCESS_CODE) {
      throw new Error("لم تُضبط كلمة سر الإدارة بعد. أضفها من إعدادات المشروع أولاً.");
    }
    if (reservedAdminName && !isValidAdminCode(input.adminCode)) {
      throw new Error("اسم الإدارة محجوز. أدخل كلمة سر الإدارة الصحيحة.");
    }
    if (wantsAdmin && !process.env.ADMIN_ACCESS_CODE) {
      throw new Error("لم يُضبط رمز الإدارة بعد. أضفه من إعدادات المشروع أولاً.");
    }
    if (wantsAdmin && !isValidAdminCode(input.adminCode)) {
      throw new Error("كلمة سر الإدارة غير صحيحة.");
    }
    const decoration = await resolveNameDecoration(input.nameDecoration);
    const profile = await createOrRefreshChatSession({
      sessionId: input.sessionId,
      displayName: wantsAdmin ? input.displayName : applyNameDecoration(input.displayName, decoration),
      age: input.age,
      gender: input.gender,
      role: wantsAdmin ? "admin" : "member",
      networkFingerprint: ctx.networkFingerprint,
      countryCode: ctx.countryCode,
    });
    if (!existingSession) {
      const room = await getRoom(profile.currentRoomId);
      if (room) await addSystemNotice(room.id, `انضم ${profile.displayName} إلى ${room.name}. أهلاً وسهلاً بك!`);
    }
    return { profile, generatedAt: new Date() };
  }),

  heartbeat: publicProcedure.input(z.object({ sessionId: sessionIdSchema })).mutation(async ({ input }) => {
    const profile = await touchChatSession(input.sessionId);
    return { profile, onlineMembers: await getOnlineMembers(profile.currentRoomId, input.sessionId), generatedAt: new Date() };
  }),

  bootstrap: publicProcedure.input(z.object({ sessionId: sessionIdSchema })).query(async ({ input }) => {
    const profile = await touchChatSession(input.sessionId);
    return {
      profile,
      rooms: await getRooms(),
      currentRoom: await getRoom(profile.currentRoomId),
      onlineMembers: await getOnlineMembers(profile.currentRoomId, input.sessionId),
      publicMessages: await getPublicMessages(profile.currentRoomId),
      publicTyping: (() => {
        cleanupTypingStates();
        return Array.from(publicTypingStates.entries()).some(([typingSessionId, state]) => typingSessionId !== input.sessionId && state.roomId === profile.currentRoomId && Date.now() - state.updatedAt <= TYPING_TTL_MS);
      })(),
      unreadPrivateCounts: await getUnreadPrivateMessageCounts(input.sessionId),
      incomingPrivateSenderIds: await getIncomingPrivateMessageSenderIds(input.sessionId),
      generatedAt: new Date(),
    };
  }),

  members: publicProcedure.input(z.object({ sessionId: sessionIdSchema })).query(async ({ input }) => {
    const profile = await touchChatSession(input.sessionId);
    return { onlineMembers: await getOnlineMembers(profile.currentRoomId, input.sessionId), generatedAt: new Date() };
  }),

  publicMessages: publicProcedure.input(z.object({ sessionId: sessionIdSchema })).query(async ({ input }) => {
    const profile = await touchChatSession(input.sessionId);
      cleanupTypingStates();
      const publicTyping = Array.from(publicTypingStates.entries()).some(([typingSessionId, state]) => typingSessionId !== input.sessionId && state.roomId === profile.currentRoomId && Date.now() - state.updatedAt <= TYPING_TTL_MS);
      return { messages: await getPublicMessages(profile.currentRoomId), publicTyping, generatedAt: new Date() };
  }),

  joinRoom: publicProcedure.input(z.object({ sessionId: sessionIdSchema, roomId: z.number().int().positive() })).mutation(async ({ input }) => {
    const previousProfile = await requireActiveChatSession(input.sessionId);
    const previousRoom = await getRoom(previousProfile.currentRoomId);
    const nextRoom = await getRoom(input.roomId);
    if (!previousRoom || !nextRoom) throw new Error("الغرفة غير موجودة.");
    if (previousRoom.id === nextRoom.id) return { profile: previousProfile, room: nextRoom, previousRoom, generatedAt: new Date() };

    const profile = await moveSessionToRoom(input.sessionId, nextRoom.id);
    await Promise.all([
      addSystemNotice(previousRoom.id, `غادر ${profile.displayName} غرفة ${previousRoom.name}.`),
      addSystemNotice(nextRoom.id, `انضم ${profile.displayName} إلى غرفة ${nextRoom.name}. أهلاً وسهلاً بك!`),
    ]);
    return { profile, room: nextRoom, previousRoom, generatedAt: new Date() };
  }),

  privateMessages: publicProcedure
    .input(z.object({ sessionId: sessionIdSchema, peerSessionId: sessionIdSchema }))
    .query(async ({ input }) => {
      const profile = await touchChatSession(input.sessionId);
      const aiAssistant = getAiAssistant(input.peerSessionId);
      const isAiFriend = Boolean(aiAssistant);
      if (isAiFriend) {
        if (!aiAssistant?.acceptsPrivateMessages) throw new Error(`${aiAssistant?.displayName ?? "المساعد"} لا يستقبل رسائل خاصة حالياً.`);
      } else {
        const peer = await requireActiveChatSession(input.peerSessionId);
        if (peer.currentRoomId !== profile.currentRoomId) throw new Error("يجب أن يكون العضوان في الغرفة نفسها.");
        if (peer.acceptsPrivateMessages === false || peer.privateMessagePolicy === "nobody" || (peer.privateMessagePolicy === "friends" && !(await areMemberAccountsFriends(input.sessionId, input.peerSessionId)))) throw new Error("هذا العضو لا يستقبل رسائل خاصة حالياً أو يقبلها من الأصدقاء فقط.");
        if (await areChatSessionsBlocked(input.sessionId, input.peerSessionId)) throw new Error("لا يمكن فتح هذه المحادثة بسبب الحظر.");
      }
      const messages = await getPrivateMessages(input.sessionId, input.peerSessionId, profile.currentRoomId);
      if (!isAiFriend) await markPrivateMessagesAsRead(input.sessionId, input.peerSessionId);
      return {
        peerSessionId: input.peerSessionId,
        messages,
        peerTyping: !isAiFriend && isPeerTyping(input.sessionId, input.peerSessionId),
        unreadPrivateCounts: await getUnreadPrivateMessageCounts(input.sessionId),
        generatedAt: new Date(),
      };
    }),

  sendPublic: publicProcedure
    .input(z.object({ sessionId: sessionIdSchema, ...messageContentShape }).refine((content) => Boolean(content.body?.trim() || content.image), "أرسل نصاً أو صورة واحدة على الأقل."))
    .mutation(async ({ input }) => {
      const profile = await touchChatSession(input.sessionId);
      await assertPublicContentSafe(input.body, input.image?.dataUrl);
      const content = await prepareMessageContent(input.sessionId, input);
      return addChatMessage({ channel: "public", roomId: profile.currentRoomId, senderSessionId: input.sessionId, ...content });
    }),

  setPublicTyping: publicProcedure
    .input(z.object({ sessionId: sessionIdSchema, isTyping: z.boolean() }))
    .mutation(async ({ input }) => {
      const profile = await touchChatSession(input.sessionId);
      cleanupTypingStates();
      if (input.isTyping) publicTypingStates.set(input.sessionId, { roomId: profile.currentRoomId, updatedAt: Date.now() });
      else publicTypingStates.delete(input.sessionId);
      return { publicTyping: Array.from(publicTypingStates.entries()).some(([typingSessionId, state]) => typingSessionId !== input.sessionId && state.roomId === profile.currentRoomId) };
    }),

  setTyping: publicProcedure
    .input(z.object({ sessionId: sessionIdSchema, peerSessionId: sessionIdSchema, isTyping: z.boolean() }))
    .mutation(async ({ input }) => {
      const profile = await touchChatSession(input.sessionId);
      const peer = await requireActiveChatSession(input.peerSessionId);
      if (peer.currentRoomId !== profile.currentRoomId || await areChatSessionsBlocked(input.sessionId, input.peerSessionId)) {
        typingStates.delete(input.sessionId);
        return { peerTyping: false };
      }
      if (input.isTyping) typingStates.set(input.sessionId, { peerSessionId: input.peerSessionId, updatedAt: Date.now() });
      else typingStates.delete(input.sessionId);
      return { peerTyping: isPeerTyping(input.peerSessionId, input.sessionId) };
    }),

  sendPrivate: publicProcedure
    .input(z.object({ sessionId: sessionIdSchema, peerSessionId: sessionIdSchema, ...messageContentShape }).refine((content) => Boolean(content.body?.trim() || content.image), "أرسل نصاً أو صورة واحدة على الأقل."))
    .mutation(async ({ input }) => {
      const profile = await touchChatSession(input.sessionId);
      const aiAssistant = getAiAssistant(input.peerSessionId);
      const isAiFriend = Boolean(aiAssistant);
      if (isAiFriend) {
        if (!aiAssistant?.acceptsPrivateMessages) throw new Error(`${aiAssistant?.displayName ?? "المساعد"} لا يستقبل رسائل خاصة حالياً.`);
      } else {
        const peer = await requireActiveChatSession(input.peerSessionId);
        if (peer.currentRoomId !== profile.currentRoomId) throw new Error("يجب أن يكون العضوان في الغرفة نفسها.");
        if (peer.acceptsPrivateMessages === false || peer.privateMessagePolicy === "nobody" || (peer.privateMessagePolicy === "friends" && !(await areMemberAccountsFriends(input.sessionId, input.peerSessionId)))) throw new Error("هذا العضو لا يستقبل رسائل خاصة حالياً أو يقبلها من الأصدقاء فقط.");
        if (await areChatSessionsBlocked(input.sessionId, input.peerSessionId)) throw new Error("لا يمكن إرسال الرسالة بسبب الحظر.");
      }
      if (isAiFriend && (!input.body?.trim() || input.image)) throw new Error(`${aiAssistant?.displayName ?? "المساعد"} يستقبل رسائل نصية فقط حالياً.`);
      const content = await prepareMessageContent(input.sessionId, input);
      const userMessage = await addChatMessage({
        channel: "private",
        roomId: profile.currentRoomId,
        senderSessionId: input.sessionId,
        recipientSessionId: input.peerSessionId,
        ...content,
      });
      if (!isAiFriend) return userMessage;

      const history = await getPrivateMessages(input.sessionId, input.peerSessionId, profile.currentRoomId);
      const response = await invokeLLM({
        messages: [
          { role: "system", content: `أنت ${aiAssistant?.displayName ?? "مساعد مسرى"}، عضو ذكاء اصطناعي ${aiAssistant?.gender === "female" ? "أنثى" : "ذكر"} وودود داخل تطبيق مسرى. تحدث بضمير ${aiAssistant?.gender === "female" ? "المؤنث" : "المذكر"}، وتحدث بالعربية بأسلوب طبيعي ودافئ وعفوي، ويمكنك أن تكون صريحاً وجريئاً في التعبير ومفصلاً عند الحاجة، مع احترام الطرف الآخر وعدم اختلاق معلومات. ناقش الموضوعات العامة براحة ولا تكن متحفظاً بلا سبب، لكن ارفض بلطف أي طلب ضار أو غير قانوني أو ينتهك الخصوصية أو يتضمن استغلالاً أو محتوى جنسياً مع قاصر. لا تدّعِ معرفة بيانات الأعضاء أو الرسائل خارج هذه المحادثة، ولا تذكر أنك نظام داخلي إلا إذا سُئلت مباشرة.` },
          ...history.slice(-12).map((message) => ({ role: message.senderSessionId === input.sessionId ? "user" as const : "assistant" as const, content: message.body ?? "" })).filter((message) => message.content),
        ],
      });
      const answer = extractAssistantText(response);
      if (!answer) throw new Error(`تعذر الحصول على رد من ${aiAssistant?.displayName ?? "المساعد"} حالياً.`);
      return addChatMessage({
        channel: "private",
        roomId: profile.currentRoomId,
        senderSessionId: aiAssistant!.sessionId,
        recipientSessionId: input.sessionId,
        body: answer,
      });
    }),

  nameDecorations: publicProcedure.query(async () => ({ decorations: await listNameDecorations(), generatedAt: new Date() })),
  memberPreferences: publicProcedure.input(z.object({ memberToken: z.string().min(40).max(128) })).query(async ({ input }) => {
    const context = await getMemberContext(input.memberToken);
    return { preferences: { fontFamily: context.account.fontFamily, textColor: context.account.textColor, nameDecoration: context.account.nameDecoration }, generatedAt: new Date() };
  }),

  updatePreferences: publicProcedure
    .input(z.object({ sessionId: sessionIdSchema, memberToken: z.string().min(40).max(128).optional(), displayName: z.string().trim().min(2).max(40).optional(), acceptsPrivateMessages: z.boolean().optional(), privateMessagePolicy: z.enum(["everyone", "friends", "nobody"]).optional(), showPresence: z.boolean().optional(), fontFamily: z.enum(["cairo", "tajawal", "system"]).optional(), textColor: z.string().regex(/^#[0-9a-f]{6}$/i).optional(), nameDecoration: z.string().trim().min(1).max(32).optional(), image: imageSchema.optional() }))
    .mutation(async ({ input }) => {
      const image = input.image ? await storeProfileImage(input.sessionId, input.image) : {};
      const profile = await updateChatSessionPreferences(input.sessionId, {
        displayName: input.displayName,
        acceptsPrivateMessages: input.acceptsPrivateMessages,
        privateMessagePolicy: input.privateMessagePolicy,
        showPresence: input.showPresence,
        fontFamily: input.fontFamily,
        textColor: input.textColor,
        nameDecoration: input.nameDecoration,
        ...image,
      });
      return { profile, preferences: input.memberToken ? (await getMemberContext(input.memberToken)).account : null, generatedAt: new Date() };
    }),

  pinnedConversations: publicProcedure.input(z.object({ memberToken: z.string().min(40).max(128) })).query(async ({ input }) => ({ peerSessionIds: await listPinnedConversations(input.memberToken), generatedAt: new Date() })),

  setPinnedConversation: publicProcedure.input(z.object({ memberToken: z.string().min(40).max(128), peerSessionId: sessionIdSchema, pinned: z.boolean() })).mutation(async ({ input }) => ({ ...(await setPinnedConversation(input.memberToken, input.peerSessionId, input.pinned)), generatedAt: new Date() })),

  friends: publicProcedure.input(z.object({ memberToken: z.string().min(40).max(128) })).query(async ({ input }) => ({ friends: await listMemberFriends(input.memberToken), generatedAt: new Date() })),

  requestFriend: publicProcedure.input(z.object({ memberToken: z.string().min(40).max(128), targetSessionId: sessionIdSchema })).mutation(async ({ input }) => ({ ...(await requestMemberFriend(input.memberToken, input.targetSessionId)), generatedAt: new Date() })),

  respondFriend: publicProcedure.input(z.object({ memberToken: z.string().min(40).max(128), friendshipId: z.number().int().positive(), status: z.enum(["accepted", "declined"]) })).mutation(async ({ input }) => ({ ...(await respondToMemberFriend(input.memberToken, input.friendshipId, input.status)), generatedAt: new Date() })),

  report: publicProcedure
    .input(z.object({ sessionId: sessionIdSchema, targetSessionId: sessionIdSchema.optional(), messageId: z.number().int().positive().optional(), roomId: z.number().int().positive().optional(), channel: z.enum(["public", "private"]).optional(), reason: z.string().trim().min(2).max(80), details: z.string().trim().max(500).optional() }).refine((value) => Boolean(value.targetSessionId || value.messageId), "حدد الرسالة أو المستخدم المُبلّغ عنه."))
    .mutation(async ({ input }) => {
      await requireActiveChatSession(input.sessionId);
      if (input.targetSessionId === input.sessionId) throw new Error("لا يمكنك الإبلاغ عن نفسك.");
      return { ...(await createChatReport({ ...input, reporterSessionId: input.sessionId })), generatedAt: new Date() };
    }),

  homepageSupport: publicProcedure
    .input(z.object({ topic: z.enum(["report", "contact"]), name: z.string().trim().max(40).optional(), email: z.string().trim().max(120).optional(), message: z.string().trim().min(10, "اكتب تفاصيل لا تقل عن 10 أحرف.").max(500) }))
    .mutation(async ({ input }) => {
      const reporterSessionId = `homepage-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`.slice(0, 64);
      const topicLabel = input.topic === "report" ? "بلاغ من الصفحة الرئيسية" : "تواصل من الصفحة الرئيسية";
      const details = [
        input.name ? `الاسم: ${input.name}` : "الاسم: غير مذكور",
        input.email ? `البريد: ${input.email}` : "البريد: غير مذكور",
        `التفاصيل: ${input.message}`,
      ].join("\n");
      return { ...(await createChatReport({ reporterSessionId, channel: "public", reason: topicLabel, details })), generatedAt: new Date() };
    }),

  blockedMembers: publicProcedure
    .input(z.object({ sessionId: sessionIdSchema }))
    .query(async ({ input }) => {
      await requireActiveChatSession(input.sessionId);
      return { members: await listChatBlockedMembers(input.sessionId), generatedAt: new Date() };
    }),

  setBlock: publicProcedure
    .input(z.object({ sessionId: sessionIdSchema, targetSessionId: sessionIdSchema, blocked: z.boolean() }))
    .mutation(async ({ input }) => {
      const actor = await requireActiveChatSession(input.sessionId);
      const target = await requireActiveChatSession(input.targetSessionId);
      if (actor.role === "admin" && target.role === "admin") throw new Error("لا يمكن تغيير حظر أدمن آخر.");
      await setChatBlock(input.sessionId, input.targetSessionId, input.blocked);
      return { success: true, blocked: input.blocked };
    }),

  admin: router({
    createRoom: publicProcedure.input(z.object({ sessionId: sessionIdSchema, name: z.string().trim().min(2).max(80) })).mutation(async ({ input }) => {
      await requireAdmin(input.sessionId);
      return createRoom(input.name, input.sessionId);
    }),
    renameRoom: publicProcedure
      .input(z.object({ sessionId: sessionIdSchema, roomId: z.number().int().positive(), name: z.string().trim().min(2).max(80) }))
      .mutation(async ({ input }) => {
        await requireAdmin(input.sessionId);
        return renameRoom(input.roomId, input.name);
      }),
    deleteRoom: publicProcedure
      .input(z.object({ sessionId: sessionIdSchema, roomId: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await requireAdmin(input.sessionId);
        await deleteRoom(input.roomId);
        return { success: true, roomId: input.roomId };
      }),
    updateRoomBackground: publicProcedure
      .input(z.object({ sessionId: sessionIdSchema, roomId: z.number().int().positive(), background: imageSchema.nullable() }))
      .mutation(async ({ input }) => {
        await requireAdmin(input.sessionId);
        const stored = input.background ? await storeRoomBackgroundImage(input.sessionId, input.roomId, input.background) : { backgroundKey: null, backgroundMimeType: null };
        return updateRoomBackground(input.roomId, stored);
      }),
    reports: publicProcedure.input(z.object({ sessionId: sessionIdSchema })).query(async ({ input }) => {
      await requireAdmin(input.sessionId);
      return { reports: await listChatReports(), generatedAt: new Date() };
    }),
    reviewReport: publicProcedure.input(z.object({ sessionId: sessionIdSchema, reportId: z.number().int().positive(), status: z.enum(["reviewed", "dismissed", "actioned"]) })).mutation(async ({ input }) => {
      await requireAdmin(input.sessionId);
      await updateChatReportStatus(input.reportId, input.status, input.sessionId);
      return { success: true, reportId: input.reportId, status: input.status };
    }),
    listNameDecorations: publicProcedure.input(z.object({ sessionId: sessionIdSchema })).query(async ({ input }) => { await requireAdmin(input.sessionId); return { decorations: await listNameDecorations(true), generatedAt: new Date() }; }),
    createNameDecoration: publicProcedure.input(z.object({ sessionId: sessionIdSchema, key: z.string().trim().regex(/^[a-z0-9-]{2,32}$/), label: z.string().trim().min(2).max(80), prefix: z.string().max(16), suffix: z.string().max(16), sortOrder: z.number().int().min(0).max(999).default(10) })).mutation(async ({ input }) => { await requireAdmin(input.sessionId); return createNameDecoration({ key: input.key, label: input.label, prefix: input.prefix, suffix: input.suffix, sortOrder: input.sortOrder, enabled: true }); }),
    updateNameDecoration: publicProcedure.input(z.object({ sessionId: sessionIdSchema, id: z.number().int().positive(), label: z.string().trim().min(2).max(80).optional(), prefix: z.string().max(16).optional(), suffix: z.string().max(16).optional(), enabled: z.boolean().optional(), sortOrder: z.number().int().min(0).max(999).optional() })).mutation(async ({ input }) => { await requireAdmin(input.sessionId); return updateNameDecoration(input.id, { label: input.label, prefix: input.prefix, suffix: input.suffix, enabled: input.enabled, sortOrder: input.sortOrder }); }),
    deleteNameDecoration: publicProcedure.input(z.object({ sessionId: sessionIdSchema, id: z.number().int().positive() })).mutation(async ({ input }) => { await requireAdmin(input.sessionId); await deleteNameDecoration(input.id); return { success: true }; }),
    overview: publicProcedure.input(z.object({ sessionId: sessionIdSchema, roomId: z.number().int().positive().optional(), channel: z.enum(["public", "private"]).optional() })).query(async ({ input }) => {
      await requireAdmin(input.sessionId);
      return {
        rooms: await getRooms(),
        members: await listAdminSessions(),
        messages: await listAdminMessages({ roomId: input.roomId, channel: input.channel }),
        generatedAt: new Date(),
      };
    }),
    deleteMessage: publicProcedure
      .input(z.object({ sessionId: sessionIdSchema, messageId: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await requireAdmin(input.sessionId);
        await softDeleteMessage(input.messageId);
        return { success: true };
      }),
    deleteAllMessages: publicProcedure
      .input(z.object({ sessionId: sessionIdSchema }))
      .mutation(async ({ input }) => {
        await requireAdmin(input.sessionId);
        await deleteAllChatMessages();
        return { success: true };
      }),
    deleteRoomMessages: publicProcedure
      .input(z.object({ sessionId: sessionIdSchema, roomId: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await requireAdmin(input.sessionId);
        const room = await getRoom(input.roomId);
        if (!room) throw new Error("الغرفة غير موجودة.");
        if (room.isDefault) throw new Error("لا يمكن حذف رسائل الغرفة العامة الافتراضية بهذا الخيار.");
        await deleteRoomChatMessages(input.roomId);
        return { success: true, roomId: input.roomId };
      }),
    deleteFilteredMessages: publicProcedure
      .input(z.object({ sessionId: sessionIdSchema, roomId: z.number().int().positive().optional(), channel: z.enum(["public", "private"]).optional() }))
      .mutation(async ({ input }) => {
        await requireAdmin(input.sessionId);
        if (!input.roomId && !input.channel) throw new Error("اختر غرفة أو نوع محادثة قبل الحذف.");
        if (input.roomId) {
          const room = await getRoom(input.roomId);
          if (!room) throw new Error("الغرفة غير موجودة.");
          if (room.isDefault) throw new Error("لا يمكن حذف رسائل الغرفة العامة الافتراضية بهذا الخيار.");
        }
        await deleteFilteredChatMessages({ roomId: input.roomId, channel: input.channel });
        return { success: true };
      }),
    banMember: publicProcedure
      .input(z.object({ sessionId: sessionIdSchema, targetSessionId: sessionIdSchema }))
      .mutation(async ({ input }) => {
        await requireAdmin(input.sessionId);
        if (input.sessionId === input.targetSessionId) throw new Error("لا يمكنك تعطيل جلستك الإدارية.");
        const target = await getChatSession(input.targetSessionId);
        if (target?.role === "admin") throw new Error("لا يمكن تعطيل حساب أدمن.");
        await banChatSession(input.targetSessionId);
        return { success: true };
      }),
    deleteMember: publicProcedure
      .input(z.object({ sessionId: sessionIdSchema, targetSessionId: sessionIdSchema }))
      .mutation(async ({ input }) => {
        await requireAdmin(input.sessionId);
        if (input.sessionId === input.targetSessionId) throw new Error("لا يمكنك حذف جلستك الإدارية.");
        const target = await getChatSession(input.targetSessionId);
        if (target?.role === "admin") throw new Error("لا يمكن حذف حساب أدمن.");
        await deleteChatSession(input.targetSessionId);
        return { success: true };
      }),
  }),
});

export function createClientSessionId() {
  return nanoid(32);
}
