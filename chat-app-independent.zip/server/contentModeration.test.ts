import { describe, expect, it } from "vitest";
import { containsBlockedPublicLanguage } from "./contentModeration";

describe("public content moderation", () => {
  it("blocks configured abusive Arabic language", () => {
    expect(containsBlockedPublicLanguage("هذا كلام سكس")) .toBe(true);
    expect(containsBlockedPublicLanguage("هذا نص محترم")) .toBe(false);
  });

  it("normalizes Arabic diacritics, variants, spaces, and punctuation", () => {
    expect(containsBlockedPublicLanguage("س ك س")) .toBe(true);
    expect(containsBlockedPublicLanguage("سَـكْـس!!!")) .toBe(true);
    expect(containsBlockedPublicLanguage("إشاعة عادية")) .toBe(false);
  });

  it("allows empty or missing message bodies", () => {
    expect(containsBlockedPublicLanguage(undefined)).toBe(false);
    expect(containsBlockedPublicLanguage(null)).toBe(false);
    expect(containsBlockedPublicLanguage("   ")).toBe(false);
  });
});
