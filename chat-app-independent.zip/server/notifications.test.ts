import { describe, expect, it } from "vitest";
import { getNewUnreadPeerIds, getTotalUnread, getUnreadPeerIds, preparePrivateNotificationAudio, shouldPlayPrivateNotification } from "../client/src/lib/notifications";

describe("private notification helpers", () => {
  it("sums unread messages across all private peers", () => {
    expect(getTotalUnread({ alpha: 2, beta: 3, empty: 0 })).toBe(5);
  });

  it("returns zero after every conversation is read", () => {
    expect(getTotalUnread({ alpha: 0, beta: 0 })).toBe(0);
    expect(getTotalUnread(undefined)).toBe(0);
  });

  it("lists only conversations that currently have unread messages", () => {
    expect(getUnreadPeerIds({ alpha: 2, beta: 0, gamma: -1 })).toEqual(["alpha"]);
  });

  it("detects only peers whose unread count increased", () => {
    expect(getNewUnreadPeerIds({ alpha: 1, beta: 3 }, { alpha: 2, beta: 0, gamma: 1 })).toEqual(["alpha", "gamma"]);
    expect(getNewUnreadPeerIds(null, { alpha: 2 })).toEqual([]);
  });

  it("fails safely when Web Audio is unavailable", () => {
    expect(preparePrivateNotificationAudio()).toBe(false);
  });

  it("plays only when the unread total increases and sound is enabled", () => {
    expect(shouldPlayPrivateNotification(1, 2, true)).toBe(true);
    expect(shouldPlayPrivateNotification(2, 2, true)).toBe(false);
    expect(shouldPlayPrivateNotification(1, 2, false)).toBe(false);
    expect(shouldPlayPrivateNotification(null, 2, true)).toBe(false);
  });
});
