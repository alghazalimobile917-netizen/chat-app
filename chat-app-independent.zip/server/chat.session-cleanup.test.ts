import { describe, expect, it } from "vitest";
import { isChatMessageSentBySession } from "./db";

describe("chat session cleanup", () => {
  it("deletes only messages sent by the session that logs out", () => {
    const departingSessionId = "departing-session";
    const ownMessage = { senderSessionId: departingSessionId };
    const incomingMessage = { senderSessionId: "another-member" };

    expect(isChatMessageSentBySession(ownMessage, departingSessionId)).toBe(true);
    expect(isChatMessageSentBySession(incomingMessage, departingSessionId)).toBe(false);
  });
});
