export type NameDecoration = "none" | "stars" | "hearts" | "diamonds";

const DECORATION_WRAPPERS: Record<NameDecoration, (name: string) => string> = {
  none: (name) => name,
  stars: (name) => `✦ ${name} ✦`,
  hearts: (name) => `♥ ${name} ♥`,
  diamonds: (name) => `◆ ${name} ◆`,
};

export const NAME_DECORATION_LABELS: Record<NameDecoration, string> = {
  none: "بدون زخرفة",
  stars: "نجوم",
  hearts: "قلوب",
  diamonds: "ألماسات",
};

export function cleanDisplayName(name: string) {
  return name.replace(/[✦♥◆]/g, "").replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 32);
}

export function decorateDisplayName(name: string, decoration: NameDecoration = "none") {
  return DECORATION_WRAPPERS[decoration](cleanDisplayName(name)).slice(0, 40);
}

export function cleanDecorationPart(value: string, maxLength = 16) {
  return value.replace(/[<>]/g, "").replace(/[\u0000-\u001F\u007F]/g, "").slice(0, maxLength);
}

export function decorateWithWrapper(name: string, prefix = "", suffix = "") {
  const clean = cleanDisplayName(name);
  return `${cleanDecorationPart(prefix)}${clean}${cleanDecorationPart(suffix)}`.slice(0, 40);
}
