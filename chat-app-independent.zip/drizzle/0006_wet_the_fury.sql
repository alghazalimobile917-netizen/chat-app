CREATE TABLE `memberAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`passwordHash` varchar(512) NOT NULL,
	`alias` varchar(40) NOT NULL,
	`age` int NOT NULL,
	`gender` enum('male','female') NOT NULL,
	`avatarKey` varchar(512),
	`avatarMimeType` varchar(100),
	`acceptsPrivateMessages` boolean NOT NULL DEFAULT true,
	`chatSessionId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `memberAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `memberAccounts_email_unique` UNIQUE(`email`),
	CONSTRAINT `memberAccounts_alias_unique` UNIQUE(`alias`),
	CONSTRAINT `memberAccounts_chatSessionId_unique` UNIQUE(`chatSessionId`)
);
--> statement-breakpoint
CREATE TABLE `memberFriendships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`requesterAccountId` int NOT NULL,
	`addresseeAccountId` int NOT NULL,
	`status` enum('pending','accepted','declined') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `memberFriendships_id` PRIMARY KEY(`id`),
	CONSTRAINT `memberFriendships_requester_addressee_unique` UNIQUE(`requesterAccountId`,`addresseeAccountId`)
);
--> statement-breakpoint
CREATE TABLE `memberSessions` (
	`token` varchar(128) NOT NULL,
	`accountId` int NOT NULL,
	`chatSessionId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp NOT NULL,
	`lastSeenAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `memberSessions_token` PRIMARY KEY(`token`)
);
--> statement-breakpoint
ALTER TABLE `chatSessions` ADD `accountId` int;