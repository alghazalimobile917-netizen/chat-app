CREATE TABLE `chatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`channel` enum('public','private') NOT NULL,
	`senderSessionId` varchar(64) NOT NULL,
	`recipientSessionId` varchar(64),
	`body` text NOT NULL,
	`deletedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chatSessions` (
	`sessionId` varchar(64) NOT NULL,
	`displayName` varchar(40) NOT NULL,
	`age` int NOT NULL,
	`gender` enum('male','female') NOT NULL,
	`role` enum('member','admin') NOT NULL DEFAULT 'member',
	`isBanned` boolean NOT NULL DEFAULT false,
	`lastSeenAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatSessions_sessionId` PRIMARY KEY(`sessionId`)
);
