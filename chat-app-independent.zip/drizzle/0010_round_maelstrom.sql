CREATE TABLE `chatReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reporterSessionId` varchar(64) NOT NULL,
	`targetSessionId` varchar(64),
	`messageId` int,
	`roomId` int,
	`channel` enum('public','private') NOT NULL DEFAULT 'public',
	`reason` varchar(80) NOT NULL,
	`details` text,
	`status` enum('pending','reviewed','dismissed','actioned') NOT NULL DEFAULT 'pending',
	`reviewedBySessionId` varchar(64),
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatReports_id` PRIMARY KEY(`id`),
	CONSTRAINT `chatReports_reporter_message_unique` UNIQUE(`reporterSessionId`,`messageId`)
);
