ALTER TABLE `chatRooms` ADD `backgroundKey` varchar(512);--> statement-breakpoint
ALTER TABLE `chatRooms` ADD `backgroundMimeType` varchar(64);