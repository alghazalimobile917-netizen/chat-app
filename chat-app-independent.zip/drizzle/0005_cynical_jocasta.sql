CREATE TABLE `chatBlocks` (
	`blockerSessionId` varchar(64) NOT NULL,
	`blockedSessionId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now())
);
--> statement-breakpoint
ALTER TABLE `chatSessions` ADD `avatarKey` varchar(512);--> statement-breakpoint
ALTER TABLE `chatSessions` ADD `avatarMimeType` varchar(100);--> statement-breakpoint
ALTER TABLE `chatSessions` ADD `acceptsPrivateMessages` boolean DEFAULT true NOT NULL;