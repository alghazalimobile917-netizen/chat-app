CREATE TABLE `chatRooms` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(80) NOT NULL,
	`isDefault` boolean NOT NULL DEFAULT false,
	`createdBySessionId` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatRooms_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `chatMessages` ADD `roomId` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `chatSessions` ADD `currentRoomId` int DEFAULT 1 NOT NULL;