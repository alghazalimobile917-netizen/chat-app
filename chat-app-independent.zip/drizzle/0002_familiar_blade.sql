ALTER TABLE `chatMessages` MODIFY COLUMN `body` text;--> statement-breakpoint
ALTER TABLE `chatMessages` ADD `imageKey` varchar(512);--> statement-breakpoint
ALTER TABLE `chatMessages` ADD `imageMimeType` varchar(100);