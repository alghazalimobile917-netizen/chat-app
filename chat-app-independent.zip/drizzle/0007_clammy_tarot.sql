ALTER TABLE `chatSessions` ADD `privateMessagePolicy` enum('everyone','friends','nobody') DEFAULT 'everyone' NOT NULL;--> statement-breakpoint
ALTER TABLE `chatSessions` ADD `showPresence` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `memberAccounts` ADD `privateMessagePolicy` enum('everyone','friends','nobody') DEFAULT 'everyone' NOT NULL;--> statement-breakpoint
ALTER TABLE `memberAccounts` ADD `showPresence` boolean DEFAULT true NOT NULL;