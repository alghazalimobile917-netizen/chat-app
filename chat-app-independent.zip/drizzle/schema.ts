import {
  boolean,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  uniqueIndex,
} from "drizzle-orm/mysql-core";

/**
 * جدول المستخدمين الأساسي المضمّن في القالب. يُحافظ عليه لتوافق البنية،
 * بينما يستخدم التطبيق جلسات الدردشة الداخلية أدناه بدلاً من OAuth.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/** غرف الدردشة التي يديرها الأدمن، مع غرفة عامة افتراضية ثابتة برقم 1. */
export const chatRooms = mysqlTable("chatRooms", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 80 }).notNull(),
  isDefault: boolean("isDefault").default(false).notNull(),
  createdBySessionId: varchar("createdBySessionId", { length: 64 }),
  backgroundKey: varchar("backgroundKey", { length: 512 }),
  backgroundMimeType: varchar("backgroundMimeType", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** جلسة دردشة محلية مرتبطة بمعرّف محفوظ في المتصفح، من دون مصادقة خارجية. */
export const memberAccounts = mysqlTable("memberAccounts", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 512 }).notNull(),
  alias: varchar("alias", { length: 40 }).notNull().unique(),
  age: int("age").notNull(),
  gender: mysqlEnum("gender", ["male", "female"]).notNull(),
  avatarKey: varchar("avatarKey", { length: 512 }),
  avatarMimeType: varchar("avatarMimeType", { length: 100 }),
  acceptsPrivateMessages: boolean("acceptsPrivateMessages").default(true).notNull(),
  privateMessagePolicy: mysqlEnum("privateMessagePolicy", ["everyone", "friends", "nobody"]).default("everyone").notNull(),
  showPresence: boolean("showPresence").default(true).notNull(),
  fontFamily: varchar("fontFamily", { length: 32 }).default("cairo").notNull(),
  textColor: varchar("textColor", { length: 16 }).default("#0f172a").notNull(),
  nameDecoration: varchar("nameDecoration", { length: 32 }).default("none").notNull(),
  chatSessionId: varchar("chatSessionId", { length: 64 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const nameDecorations = mysqlTable("nameDecorations", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 32 }).notNull().unique(),
  label: varchar("label", { length: 80 }).notNull(),
  prefix: varchar("prefix", { length: 16 }).notNull(),
  suffix: varchar("suffix", { length: 16 }).notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const memberSessions = mysqlTable("memberSessions", {
  token: varchar("token", { length: 128 }).primaryKey(),
  accountId: int("accountId").notNull(),
  chatSessionId: varchar("chatSessionId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  /** null تعني جلسة مستمرة لا تنتهي تلقائياً؛ تُحذف فقط عند الخروج الصريح. */
  expiresAt: timestamp("expiresAt"),
  lastSeenAt: timestamp("lastSeenAt").defaultNow().onUpdateNow().notNull(),
});

export const chatPinnedConversations = mysqlTable("chatPinnedConversations", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  peerSessionId: varchar("peerSessionId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  accountPeerUnique: uniqueIndex("chatPinnedConversations_account_peer_unique").on(table.accountId, table.peerSessionId),
}));

export const chatReports = mysqlTable("chatReports", {
  id: int("id").autoincrement().primaryKey(),
  reporterSessionId: varchar("reporterSessionId", { length: 64 }).notNull(),
  targetSessionId: varchar("targetSessionId", { length: 64 }),
  messageId: int("messageId"),
  roomId: int("roomId"),
  channel: mysqlEnum("channel", ["public", "private"]).default("public").notNull(),
  reason: varchar("reason", { length: 80 }).notNull(),
  details: text("details"),
  status: mysqlEnum("status", ["pending", "reviewed", "dismissed", "actioned"]).default("pending").notNull(),
  reviewedBySessionId: varchar("reviewedBySessionId", { length: 64 }),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  reporterMessageUnique: uniqueIndex("chatReports_reporter_message_unique").on(table.reporterSessionId, table.messageId),
}));

export const memberFriendships = mysqlTable("memberFriendships", {
  id: int("id").autoincrement().primaryKey(),
  requesterAccountId: int("requesterAccountId").notNull(),
  addresseeAccountId: int("addresseeAccountId").notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "declined"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  requesterAddresseeUnique: uniqueIndex("memberFriendships_requester_addressee_unique").on(table.requesterAccountId, table.addresseeAccountId),
}));

/** جلسة دردشة محلية مرتبطة بمعرّف محفوظ في المتصفح، من دون مصادقة خارجية. */
export const chatSessions = mysqlTable("chatSessions", {
  sessionId: varchar("sessionId", { length: 64 }).primaryKey(),
  displayName: varchar("displayName", { length: 40 }).notNull(),
  accountId: int("accountId"),
  /** بصمة HMAC أحادية الاتجاه للشبكة؛ لا تُعرض ولا تحتوي عنوان IP خاماً. */
  networkFingerprint: varchar("networkFingerprint", { length: 128 }),
  /** رمز ISO-3166-1 من ترويسات البلد المتاحة؛ لا نخزن IP الخام. */
  countryCode: varchar("countryCode", { length: 2 }),
  age: int("age").notNull(),
  gender: mysqlEnum("gender", ["male", "female"]).notNull(),
  avatarKey: varchar("avatarKey", { length: 512 }),
  avatarMimeType: varchar("avatarMimeType", { length: 100 }),
  acceptsPrivateMessages: boolean("acceptsPrivateMessages").default(true).notNull(),
  privateMessagePolicy: mysqlEnum("privateMessagePolicy", ["everyone", "friends", "nobody"]).default("everyone").notNull(),
  showPresence: boolean("showPresence").default(true).notNull(),
  role: mysqlEnum("role", ["member", "admin"]).default("member").notNull(),
  currentRoomId: int("currentRoomId").default(1).notNull(),
  isBanned: boolean("isBanned").default(false).notNull(),
  lastSeenAt: timestamp("lastSeenAt").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** حظر اختياري بين جلسات الدردشة؛ المفتاح المركب يمنع التكرار. */
export const chatBlocks = mysqlTable("chatBlocks", {
  blockerSessionId: varchar("blockerSessionId", { length: 64 }).notNull(),
  blockedSessionId: varchar("blockedSessionId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** الرسائل العامة والخاصة؛ تُخفى الرسالة المحذوفة مع بقاء أثرها الإداري. */
export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  roomId: int("roomId").default(1).notNull(),
  channel: mysqlEnum("channel", ["public", "private"]).notNull(),
  senderSessionId: varchar("senderSessionId", { length: 64 }).notNull(),
  recipientSessionId: varchar("recipientSessionId", { length: 64 }),
  body: text("body"),
  imageKey: varchar("imageKey", { length: 512 }),
  imageMimeType: varchar("imageMimeType", { length: 100 }),
  readAt: timestamp("readAt"),
  deletedAt: timestamp("deletedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MemberAccount = typeof memberAccounts.$inferSelect;
export type InsertMemberAccount = typeof memberAccounts.$inferInsert;
export type NameDecorationRow = typeof nameDecorations.$inferSelect;
export type InsertNameDecoration = typeof nameDecorations.$inferInsert;
export type MemberSession = typeof memberSessions.$inferSelect;
export type InsertMemberSession = typeof memberSessions.$inferInsert;
export type ChatReport = typeof chatReports.$inferSelect;
export type InsertChatReport = typeof chatReports.$inferInsert;
export type MemberFriendship = typeof memberFriendships.$inferSelect;
export type InsertMemberFriendship = typeof memberFriendships.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type ChatRoom = typeof chatRooms.$inferSelect;
export type InsertChatRoom = typeof chatRooms.$inferInsert;
export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertChatSession = typeof chatSessions.$inferInsert;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;
