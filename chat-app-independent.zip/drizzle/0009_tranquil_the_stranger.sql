CREATE TABLE `chatPinnedConversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`peerSessionId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatPinnedConversations_id` PRIMARY KEY(`id`),
	CONSTRAINT `chatPinnedConversations_account_peer_unique` UNIQUE(`accountId`,`peerSessionId`)
);
