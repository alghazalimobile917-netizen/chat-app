CREATE TABLE `nameDecorations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(32) NOT NULL,
	`label` varchar(80) NOT NULL,
	`prefix` varchar(16) NOT NULL,
	`suffix` varchar(16) NOT NULL,
	`enabled` boolean NOT NULL DEFAULT true,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `nameDecorations_id` PRIMARY KEY(`id`),
	CONSTRAINT `nameDecorations_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
ALTER TABLE `memberAccounts` ADD `fontFamily` varchar(32) DEFAULT 'cairo' NOT NULL;--> statement-breakpoint
ALTER TABLE `memberAccounts` ADD `textColor` varchar(16) DEFAULT '#0f172a' NOT NULL;--> statement-breakpoint
ALTER TABLE `memberAccounts` ADD `nameDecoration` varchar(32) DEFAULT 'none' NOT NULL;