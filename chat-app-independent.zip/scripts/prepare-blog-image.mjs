import { readFile } from "node:fs/promises";
import sharp from "sharp";

const input = "/home/ubuntu/screenshots/webdev-preview-root-1787864826720258042-6346.png";
const output = "/home/ubuntu/webdev-static-assets/masra-blog-home-latest.webp";

await sharp(await readFile(input))
  .resize({ width: 1280, height: 720, fit: "cover", position: "center" })
  .webp({ quality: 84, effort: 5 })
  .toFile(output);

console.log(output);
