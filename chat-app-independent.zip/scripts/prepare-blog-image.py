from pathlib import Path
from PIL import Image

source = Path('/home/ubuntu/screenshots/webdev-preview-root-1787864826720258042-6346.png')
target = Path('/home/ubuntu/webdev-static-assets/masra-blog-home-latest.webp')

with Image.open(source) as image:
    image = image.convert('RGB')
    image = image.resize((1280, 720), Image.Resampling.LANCZOS)
    image.save(target, 'WEBP', quality=84, method=6)

print(target)
