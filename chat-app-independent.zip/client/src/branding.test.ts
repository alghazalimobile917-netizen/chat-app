import { describe, expect, it } from "vitest";

describe("هوية مسرى", () => {
  it("تستخدم عنوان التطبيق الجديد من إعدادات العميل", () => {
    expect(import.meta.env.VITE_APP_TITLE).toBe("مسرى | مساحة دردشة");
  });
});
