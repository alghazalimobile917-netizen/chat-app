export function appendUniqueChatMessage<T extends { id: number }>(messages: T[], message: T) {
  return messages.some((current) => current.id === message.id) ? messages : [...messages, message];
}

export function replaceOptimisticChatMessage<T extends { id: number }>(messages: T[], message: T, matches: (candidate: T) => boolean) {
  const index = messages.findIndex(matches);
  if (index < 0) return appendUniqueChatMessage(messages, message);
  const next = [...messages];
  next[index] = message;
  return next;
}

export function removeOptimisticChatMessage<T extends { id: number }>(messages: T[], matches: (candidate: T) => boolean) {
  return messages.filter((message) => !matches(message));
}

export function filterMembersWithIncomingPrivateMessages<T extends { sessionId: string }>(members: T[], incomingSenderIds: readonly string[]) {
  const incomingIds = new Set(incomingSenderIds);
  return members.filter((member) => incomingIds.has(member.sessionId));
}
