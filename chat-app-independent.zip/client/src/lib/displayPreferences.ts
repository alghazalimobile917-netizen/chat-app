import {
  NAME_DECORATION_LABELS,
  cleanDisplayName,
  decorateDisplayName,
  decorateWithWrapper,
  type NameDecoration,
} from "@shared/nameDecoration";

export type { NameDecoration } from "@shared/nameDecoration";
export { decorateDisplayName } from "@shared/nameDecoration";

export type DisplayPreferences = {
  fontFamily: "cairo" | "tajawal" | "system";
  textColor: string;
};

export type NameDecorationOption = {
  key: string;
  label: string;
  prefix: string;
  suffix: string;
  enabled?: boolean;
  sortOrder?: number;
  id?: number;
};

export const DISPLAY_PREFERENCES_KEY = "masra-display-preferences-v3";
export const DEFAULT_DISPLAY_PREFERENCES: DisplayPreferences = { fontFamily: "cairo", textColor: "#0f172a" };

export type DisplayTheme = "light" | "dark";

/** اللون الافتراضي لمحرر الكتابة؛ يبقى اللون المحفوظ قابلاً للتخصيص ولا يفرض على المستخدم. */
export function getDefaultComposerTextColor(theme: DisplayTheme) {
  return theme === "dark" ? "#f8fafc" : "#0f172a";
}

/** رسائل المستخدم تُعرض داخل فقاعة كحلية، لذلك يكون الافتراضي أبيضاً لتجنب ضعف التباين. */
export function getDefaultOwnMessageTextColor() {
  return "#ffffff";
}


export const FONT_OPTIONS: Record<DisplayPreferences["fontFamily"], { label: string; css: string }> = {
  cairo: { label: "القاهرة", css: "Cairo, sans-serif" },
  tajawal: { label: "تجوال", css: "Tajawal, sans-serif" },
  system: { label: "خط الجهاز", css: "system-ui, sans-serif" },
};

export const NAME_DECORATIONS: Record<NameDecoration, { label: string; wrap: (name: string) => string; prefix: string; suffix: string }> = {
  none: { label: NAME_DECORATION_LABELS.none, wrap: (name) => decorateDisplayName(name, "none"), prefix: "", suffix: "" },
  stars: { label: NAME_DECORATION_LABELS.stars, wrap: (name) => decorateDisplayName(name, "stars"), prefix: "✦ ", suffix: " ✦" },
  hearts: { label: NAME_DECORATION_LABELS.hearts, wrap: (name) => decorateDisplayName(name, "hearts"), prefix: "♥ ", suffix: " ♥" },
  diamonds: { label: NAME_DECORATION_LABELS.diamonds, wrap: (name) => decorateDisplayName(name, "diamonds"), prefix: "◆ ", suffix: " ◆" },
};

export const BUILTIN_NAME_DECORATIONS: NameDecorationOption[] = Object.entries(NAME_DECORATIONS).map(([key, value], sortOrder) => ({
  key,
  label: value.label,
  prefix: value.prefix,
  suffix: value.suffix,
  sortOrder,
}));

export function decorateNameWithOption(name: string, option?: NameDecorationOption | null) {
  const clean = cleanDisplayName(name);
  if (!option || option.key === "none") return clean;
  const builtin = NAME_DECORATIONS[option.key as NameDecoration];
  return builtin ? builtin.wrap(clean) : decorateWithWrapper(clean, option.prefix, option.suffix);
}

export function normalizeDisplayPreferences(value: Partial<DisplayPreferences> | null | undefined): DisplayPreferences {
  const fontFamily = value?.fontFamily && value.fontFamily in FONT_OPTIONS ? value.fontFamily : DEFAULT_DISPLAY_PREFERENCES.fontFamily;
  const textColor = typeof value?.textColor === "string" && /^#[0-9a-f]{6}$/i.test(value.textColor) ? value.textColor : DEFAULT_DISPLAY_PREFERENCES.textColor;
  return { fontFamily, textColor };
}

export function readDisplayPreferences(): DisplayPreferences {
  try {
    const saved = JSON.parse(localStorage.getItem(DISPLAY_PREFERENCES_KEY) ?? "null") as Partial<DisplayPreferences> | null;
    return normalizeDisplayPreferences(saved);
  } catch {
    return DEFAULT_DISPLAY_PREFERENCES;
  }
}

export function saveDisplayPreferences(preferences: DisplayPreferences) {
  localStorage.setItem(DISPLAY_PREFERENCES_KEY, JSON.stringify(normalizeDisplayPreferences(preferences)));
}
