import { beforeEach, describe, expect, it } from "vitest";
import {
  DEFAULT_DISPLAY_PREFERENCES,
  FONT_OPTIONS,
  NAME_DECORATIONS,
  DISPLAY_PREFERENCES_KEY,
  decorateDisplayName,
  getDefaultComposerTextColor,
  getDefaultOwnMessageTextColor,
  readDisplayPreferences,
  saveDisplayPreferences,
} from "./displayPreferences";

function installLocalStorage() {
  const values = new Map<string, string>();
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: {
      getItem: (key: string) => values.get(key) ?? null,
      setItem: (key: string, value: string) => values.set(key, value),
      removeItem: (key: string) => values.delete(key),
    },
  });
}

describe("display preferences", () => {
  beforeEach(() => installLocalStorage());

  it("provides safe Arabic name decorations without allowing nested decoration", () => {
    expect(decorateDisplayName("  ✦ أحمد ✦ ", "hearts")).toBe("♥ أحمد ♥");
    expect(decorateDisplayName("سارة", "stars")).toBe("✦ سارة ✦");
    expect(NAME_DECORATIONS.diamonds.wrap("مسرى")).toBe("◆ مسرى ◆");
  });

  it("keeps a readable default message color and exposes the available fonts", () => {
    expect(DEFAULT_DISPLAY_PREFERENCES.textColor).toBe("#0f172a");
    expect(Object.keys(FONT_OPTIONS)).toEqual(["cairo", "tajawal", "system"]);
  });

  it("uses contrasting composer and own-message defaults for both themes", () => {
    expect(getDefaultComposerTextColor("light")).toBe("#0f172a");
    expect(getDefaultComposerTextColor("dark")).toBe("#f8fafc");
    expect(getDefaultOwnMessageTextColor()).toBe("#ffffff");
  });

  it("persists and validates a user's font and text color locally", () => {
    const preferences = { fontFamily: "tajawal" as const, textColor: "#f59e0b" };
    saveDisplayPreferences(preferences);
    expect(localStorage.getItem(DISPLAY_PREFERENCES_KEY)).toContain("tajawal");
    expect(readDisplayPreferences()).toEqual(preferences);

    localStorage.setItem(DISPLAY_PREFERENCES_KEY, JSON.stringify({ fontFamily: "unknown", textColor: "red" }));
    expect(readDisplayPreferences()).toEqual(DEFAULT_DISPLAY_PREFERENCES);
  });
});
