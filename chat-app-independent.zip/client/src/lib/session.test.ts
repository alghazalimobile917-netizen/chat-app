/** @vitest-environment jsdom */
import { beforeEach, describe, expect, it } from "vitest";
import { clearLocalSession, persistLocalSession, restoreLocalSession } from "./session";

describe("جلسة مسرى المحلية", () => {
  beforeEach(() => localStorage.clear());

  it("يحفظ جلسة العضو ويستعيد رمزها دون تخزين البريد الإلكتروني", () => {
    persistLocalSession({
      sessionId: "member-session",
      displayName: "عضو دائم",
      age: 25,
      gender: "male",
      role: "member",
      accountId: 7,
      memberToken: "a".repeat(48),
      isGuest: false,
    });

    const raw = localStorage.getItem("nabd-chat-session-v1") ?? "";
    expect(raw).not.toContain("email");
    expect(restoreLocalSession()).toMatchObject({
      sessionId: "member-session",
      displayName: "عضو دائم",
      accountId: 7,
      memberToken: "a".repeat(48),
      isGuest: false,
    });
  });

  it("يميز الزائر المؤقت ويزيل جلسة العضو بالكامل عند الخروج", () => {
    persistLocalSession({ sessionId: "guest-session", displayName: "زائر", age: 20, gender: "female", role: "member", isGuest: true });
    expect(restoreLocalSession()?.isGuest).toBe(true);
    clearLocalSession();
    expect(restoreLocalSession()).toBeNull();
    expect(localStorage.getItem("bouh-member-token-v1")).toBeNull();
  });
});
