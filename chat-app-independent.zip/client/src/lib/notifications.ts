export type UnreadCounts = Record<string, number>;

type BrowserAudioWindow = Window & typeof globalThis & {
  webkitAudioContext?: typeof AudioContext;
};

let sharedAudioContext: AudioContext | null = null;
let audioActivationAttempted = false;
let audioResumePromise: Promise<void> | null = null;

function normalizedUnreadCount(value: number | null | undefined) {
  return Math.max(0, Number(value) || 0);
}

export function getTotalUnread(unreadByPeer: UnreadCounts | null | undefined) {
  return Object.values(unreadByPeer ?? {}).reduce((total, count) => total + normalizedUnreadCount(count), 0);
}

export function getUnreadPeerIds(unreadByPeer: UnreadCounts | null | undefined) {
  return Object.entries(unreadByPeer ?? {})
    .filter(([, count]) => normalizedUnreadCount(count) > 0)
    .map(([peerSessionId]) => peerSessionId);
}

export function getNewUnreadPeerIds(previous: UnreadCounts | null, next: UnreadCounts | null | undefined) {
  if (previous === null) return [];
  return getUnreadPeerIds(next).filter((peerSessionId) => normalizedUnreadCount(next?.[peerSessionId]) > normalizedUnreadCount(previous[peerSessionId]));
}

export function shouldPlayPrivateNotification(previousTotal: number | null, nextTotal: number, soundEnabled: boolean) {
  return soundEnabled && previousTotal !== null && nextTotal > previousTotal;
}

function getSharedAudioContext() {
  if (typeof window === "undefined") return null;
  if (sharedAudioContext) return sharedAudioContext;
  const audioWindow = window as BrowserAudioWindow;
  const AudioContextClass = audioWindow.AudioContext ?? audioWindow.webkitAudioContext;
  if (!AudioContextClass) return null;
  try {
    sharedAudioContext = new AudioContextClass();
  } catch {
    return null;
  }
  return sharedAudioContext;
}

/** Call this from a user gesture so browsers allow later background notification tones. */
export function preparePrivateNotificationAudio() {
  const context = getSharedAudioContext();
  if (!context) return false;
  audioActivationAttempted = true;
  if (context.state === "suspended") {
    audioResumePromise ??= context.resume().catch(() => undefined);
  }
  return true;
}

function runAfterAudioResumes(callback: (context: AudioContext) => boolean) {
  const context = getSharedAudioContext();
  if (!context) return false;
  if (context.state === "suspended") {
    if (!audioActivationAttempted) return false;
    audioResumePromise ??= context.resume().catch(() => undefined);
    void audioResumePromise.then(() => callback(context));
    return true;
  }
  return callback(context);
}

/** A short, clearly audible click for general notification feedback. */
export function playNotificationClickTone() {
  return runAfterAudioResumes((context) => scheduleTone(context, {
    frequency: 1_180,
    endFrequency: 920,
    volume: 0.16,
    duration: 0.085,
  }));
}

/** A two-note signature sound reserved for incoming private messages. */
export function playPrivateNotificationTone() {
  return runAfterAudioResumes((context) => {
    const first = scheduleTone(context, { frequency: 680, endFrequency: 820, volume: 0.14, duration: 0.12 });
    const second = scheduleTone(context, { frequency: 920, endFrequency: 1_080, volume: 0.13, duration: 0.17, offset: 0.095 });
    return first || second;
  });
}

type ToneOptions = {
  frequency: number;
  endFrequency: number;
  volume: number;
  duration: number;
  offset?: number;
};

function scheduleTone(context: AudioContext, options: ToneOptions) {
  try {
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const startAt = context.currentTime + (options.offset ?? 0);
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(options.frequency, startAt);
    oscillator.frequency.exponentialRampToValueAtTime(options.endFrequency, startAt + Math.min(0.06, options.duration / 2));
    gain.gain.setValueAtTime(0.0001, startAt);
    gain.gain.exponentialRampToValueAtTime(options.volume, startAt + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, startAt + options.duration);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start(startAt);
    oscillator.stop(startAt + options.duration + 0.01);
    oscillator.addEventListener("ended", () => {
      oscillator.disconnect();
      gain.disconnect();
    }, { once: true });
    return true;
  } catch {
    return false;
  }
}
