export type Gender = "male" | "female";

export type LocalSession = {
  sessionId: string;
  displayName: string;
  age: number;
  gender: Gender;
  role: "member" | "admin";
  avatarKey?: string | null;
  avatarMimeType?: string | null;
  acceptsPrivateMessages?: boolean;
  privateMessagePolicy?: "everyone" | "friends" | "nobody";
  showPresence?: boolean;
  accountId?: number | null;
  memberToken?: string;
  isGuest?: boolean;
};

export const SESSION_KEY = "nabd-chat-session-v1";
export const MEMBER_TOKEN_KEY = "bouh-member-token-v1";

export function persistLocalSession(session: LocalSession) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  if (session.memberToken) localStorage.setItem(MEMBER_TOKEN_KEY, session.memberToken);
  else localStorage.removeItem(MEMBER_TOKEN_KEY);
}

export function clearLocalSession() {
  localStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(MEMBER_TOKEN_KEY);
}

export function restoreLocalSession(): LocalSession | null {
  try {
    const saved = localStorage.getItem(SESSION_KEY);
    if (!saved) return null;
    const session = JSON.parse(saved) as LocalSession;
    const memberToken = localStorage.getItem(MEMBER_TOKEN_KEY) ?? session.memberToken;
    return { ...session, memberToken: memberToken || undefined, isGuest: session.isGuest ?? !memberToken };
  } catch {
    return null;
  }
}
