import { describe, expect, it } from "vitest";
import { isValidAdSensePublisherId } from "@/components/AdSenseAutoLoader";

describe("Google AdSense configuration", () => {
  it("accepts the configured publisher id and rejects malformed values", () => {
    const publisherId = process.env.VITE_ADSENSE_PUBLISHER_ID;
    expect(publisherId).toMatch(/^pub-[A-Za-z0-9]+$/);
    expect(isValidAdSensePublisherId(publisherId)).toBe(true);
    expect(isValidAdSensePublisherId("ca-pub-5791974568221143")).toBe(false);
    expect(isValidAdSensePublisherId("pub-")).toBe(false);
    expect(isValidAdSensePublisherId(undefined)).toBe(false);
  });

  it("reaches the official AdSense script endpoint", async () => {
    const publisherId = process.env.VITE_ADSENSE_PUBLISHER_ID;
    expect(publisherId).toMatch(/^pub-[A-Za-z0-9]+$/);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8_000);
    try {
      const response = await fetch(
        `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-${publisherId}`,
        { method: "HEAD", signal: controller.signal },
      );
      expect(response.status).toBeLessThan(500);
    } finally {
      clearTimeout(timeout);
    }
  }, 12_000);
});
