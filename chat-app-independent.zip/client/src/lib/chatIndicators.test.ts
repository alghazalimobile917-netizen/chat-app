import { describe, expect, it } from "vitest";
import { getMessageReadLabel, getMessageReadState, isTypingIndicatorFresh } from "./chatIndicators";

describe("chat indicators", () => {
  it("shows a sent state only for the sender", () => {
    expect(getMessageReadState(null, true)).toBe("sent");
    expect(getMessageReadLabel(null, true)).toBe("تم إرسال الرسالة");
    expect(getMessageReadState(null, false)).toBeNull();
  });

  it("shows a read state when readAt exists", () => {
    expect(getMessageReadState(new Date(), true)).toBe("read");
    expect(getMessageReadLabel("2026-08-23T10:00:00.000Z", true)).toBe("تمت قراءة الرسالة");
    expect(getMessageReadLabel(null, false)).toBeNull();
  });

  it("expires typing indicators after the privacy-safe short TTL", () => {
    expect(isTypingIndicatorFresh(10_000, 15_000, 6_000)).toBe(true);
    expect(isTypingIndicatorFresh(10_000, 16_001, 6_000)).toBe(false);
    expect(isTypingIndicatorFresh(undefined, 15_000)).toBe(false);
    expect(isTypingIndicatorFresh(20_000, 19_000)).toBe(false);
  });
});
