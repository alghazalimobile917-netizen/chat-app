export type MessageReadState = "sent" | "read";

export function getMessageReadState(readAt: Date | string | null | undefined, isOwnMessage: boolean): MessageReadState | null {
  if (!isOwnMessage) return null;
  return readAt ? "read" : "sent";
}

export function getMessageReadLabel(readAt: Date | string | null | undefined, isOwnMessage: boolean) {
  const state = getMessageReadState(readAt, isOwnMessage);
  if (state === "read") return "تمت قراءة الرسالة";
  if (state === "sent") return "تم إرسال الرسالة";
  return null;
}

export function isTypingIndicatorFresh(updatedAt: number | null | undefined, now = Date.now(), ttlMs = 6_000) {
  return typeof updatedAt === "number" && now - updatedAt >= 0 && now - updatedAt <= ttlMs;
}
