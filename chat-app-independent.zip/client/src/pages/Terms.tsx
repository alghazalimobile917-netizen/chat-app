import React from "react";
import { ArrowRight, FileText, Heart } from "lucide-react";

function LegalHeader({ title, eyebrow }: { title: string; eyebrow: string }) {
  return <header className="border-b border-white/10 bg-[#111b35] text-white">
    <div className="mx-auto flex w-full max-w-5xl items-center justify-between gap-4 px-4 py-5 sm:px-6">
      <a href="/" className="inline-flex min-h-10 items-center gap-2 rounded-xl px-2 text-sm font-bold text-slate-200 transition hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400" aria-label="العودة إلى مسرى"><ArrowRight className="size-4" />العودة إلى مسرى</a>
      <div className="text-right"><div className="flex items-center justify-end gap-2"><span className="grid size-8 place-items-center rounded-xl bg-blue-600"><Heart className="size-4 fill-rose-400 text-rose-400" /></span><span className="text-xl font-black tracking-tight">مسرى</span></div><p className="mt-1 text-[11px] text-slate-400">{eyebrow}</p></div>
    </div>
    <div className="mx-auto w-full max-w-5xl px-4 pb-8 pt-4 sm:px-6"><h1 className="text-3xl font-black tracking-tight sm:text-4xl">{title}</h1><p className="mt-3 max-w-2xl text-sm leading-7 text-slate-300">آخر تحديث: 28 أغسطس 2026</p></div>
  </header>;
}

function LegalFooter() {
  return <footer className="mt-12 border-t border-slate-200 pt-6 text-center text-sm text-slate-500"><div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2"><a href="/privacy" className="font-bold text-blue-700 hover:text-blue-900">سياسة الخصوصية</a><a href="/terms" className="font-bold text-blue-700 hover:text-blue-900">شروط الاستخدام</a><a href="/" className="font-bold text-slate-700 hover:text-slate-950">العودة للدردشة</a></div><p className="mt-3 text-xs">مسرى — مساحة عربية للدردشة العامة والخاصة.</p></footer>;
}

export default function Terms() {
  return <main dir="rtl" className="min-h-screen bg-[#f8fafc] text-slate-800">
    <LegalHeader title="شروط الاستخدام" eyebrow="دردشة محترمة وآمنة للجميع" />
    <article className="mx-auto w-full max-w-4xl px-4 py-8 sm:px-6 sm:py-12">
      <div className="mb-8 flex items-start gap-3 rounded-2xl border border-amber-100 bg-amber-50/90 p-4 text-sm leading-7 text-amber-950"><FileText className="mt-1 size-5 shrink-0 text-amber-700" /><p>باستخدام مسرى، توافق على الالتزام بهذه الشروط وعلى استخدام المنصة للتواصل المشروع والمحترم. إذا لم توافق عليها، يرجى عدم استخدام الخدمة.</p></div>
      <div className="space-y-8 rounded-[2rem] border border-slate-200 bg-white p-5 shadow-sm sm:p-9">
        <section><h2 className="text-xl font-black text-slate-950">1. قبول الشروط والأهلية</h2><p className="mt-3 text-sm leading-8 text-slate-600">تشكل هذه الشروط اتفاقاً بينك وبين مشغّل منصة مسرى عند دخولك أو استخدامك للموقع. يجب أن تكون مؤهلاً قانونياً لاستخدام خدمة الدردشة في بلدك، وأن تقدم معلومات صحيحة وغير مضللة عند إنشاء حساب دائم أو جلسة زائر.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">2. الحسابات والجلسات</h2><ul className="mt-3 list-disc space-y-2 pr-5 text-sm leading-8 text-slate-600"><li>أنت مسؤول عن المحافظة على سرية كلمة مرور حساب العضو وعن كل نشاط يتم من خلاله.</li><li>الاسم الظاهر ليس وسيلة لإثبات الهوية، ويُمنع انتحال شخصية شخص أو جهة أخرى.</li><li>جلسة الزائر مؤقتة، بينما قد يحتفظ العضو الدائم ببياناته ومحادثاته وفق سياسة الخصوصية.</li><li>يحق للإدارة تعليق أو حذف الحساب أو الجلسة عند مخالفة الشروط أو لحماية المنصة والمستخدمين.</li></ul></section>
        <section><h2 className="text-xl font-black text-slate-950">3. قواعد المحتوى والسلوك</h2><p className="mt-3 text-sm leading-8 text-slate-600">يحظر إرسال أو نشر أي محتوى غير قانوني أو تهديدي أو تحريضي أو تشهيري أو مضلل أو ينتهك حقوق الآخرين. كما يُمنع التحرش والتنمر والكراهية والابتزاز والمضايقة المتكررة، ونشر بيانات شخصية أو كلمات مرور أو معلومات مالية، ومحاولة خداع المستخدمين أو استدراجهم.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">4. الصور والوسائط</h2><p className="mt-3 text-sm leading-8 text-slate-600">يجب ألا تحتوي الصور المرسلة على عري أو استغلال جنسي أو عنف صادم أو إساءة للأطفال أو رموز كراهية أو مواد تنتهك حقوق الملكية الفكرية. نحتفظ بحق رفض الصورة أو حذفها أو تقييد الحساب عند الاشتباه في مخالفة، ويُرجى عدم مشاركة صورة شخص آخر دون إذنه المناسب.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">5. البلاغات والإشراف</h2><p className="mt-3 text-sm leading-8 text-slate-600">يمكنك الإبلاغ عن رسالة أو مستخدم مخالف عبر أدوات المنصة. قد تراجع الإدارة البلاغات والمحتوى اللازم للتحقق منها، وتحذف الرسائل المخالفة أو تحظر المستخدم أو تتخذ إجراءات أخرى مناسبة. لا تضمن مسرى قراءة كل رسالة أو اكتشاف كل مخالفة فوراً، لذلك لا تعتمد على الدردشة لحماية معلومات عاجلة أو حساسة.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">6. الاستخدامات الممنوعة تقنياً</h2><p className="mt-3 text-sm leading-8 text-slate-600">يُمنع تعطيل الخدمة أو اختبارها بطريقة مؤذية، أو إرسال رسائل آلية مزعجة، أو محاولة الوصول غير المصرح به، أو فحص الثغرات دون إذن، أو جمع أسماء الأعضاء وبياناتهم آلياً، أو التحايل على الحظر، أو استخدام المنصة لتوزيع برمجيات ضارة أو روابط احتيالية.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">7. الملكية والمسؤولية عن المحتوى</h2><p className="mt-3 text-sm leading-8 text-slate-600">تحتفظ بحقوقك في المحتوى الذي تنشره، وتمنح مسرى ترخيصاً محدوداً لاستضافته وعرضه ومعالجته بالقدر اللازم لتشغيل الدردشة ومراجعة البلاغات. أنت مسؤول عن امتلاك الحقوق اللازمة لما ترسله. لا تمثل الرسائل أو إجابات المساعد الافتراضي رأياً أو ضماناً من مسرى، ولا ينبغي الاعتماد عليها كنصيحة مهنية.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">8. الإعلانات والخدمات الخارجية</h2><p className="mt-3 text-sm leading-8 text-slate-600">قد تتضمن المنصة إعلانات أو روابط لخدمات خارجية. لا تتحكم مسرى في سياسات تلك الجهات أو محتواها أو توفرها، وتخضع تفاعلاتك معها لشروطها وسياسات الخصوصية الخاصة بها. يجب ألا تؤثر الإعلانات في قدرتك على قراءة الدردشة أو استخدام أدواتها الأساسية.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">9. التوفر والتعديلات</h2><p className="mt-3 text-sm leading-8 text-slate-600">قد تتوقف بعض الوظائف مؤقتاً للصيانة أو الأمان أو بسبب عوامل خارجة عن السيطرة. يجوز تحديث المنصة أو هذه الشروط عند إضافة وظائف أو تغير المتطلبات؛ سنعرض تاريخ آخر تحديث في أعلى الصفحة. استمرار الاستخدام بعد التحديث يعني قبول الشروط المعدلة.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">10. التواصل</h2><p className="mt-3 text-sm leading-8 text-slate-600">للاستفسارات المتعلقة بهذه الشروط أو للإبلاغ عن إساءة، استخدم قناة التواصل الرسمية مع إدارة مسرى. عند التواصل، اذكر تفاصيل كافية للتحقق من الطلب دون إرسال كلمات مرور أو بيانات مالية.</p></section>
      </div>
      <LegalFooter />
    </article>
  </main>;
}
