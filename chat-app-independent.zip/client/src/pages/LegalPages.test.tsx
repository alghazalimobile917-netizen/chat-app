// @vitest-environment jsdom
import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import Privacy from "./Privacy";
import Terms from "./Terms";

describe("صفحات الامتثال القانوني", () => {
  afterEach(() => cleanup());

  it("يعرض سياسة الخصوصية مع روابط العودة والتنقل", () => {
    render(<Privacy />);

    expect(screen.getByRole("heading", { name: "سياسة الخصوصية" })).toBeTruthy();
    expect(screen.getByRole("link", { name: "العودة إلى مسرى" }).getAttribute("href")).toBe("/");
    expect(screen.getByRole("link", { name: "شروط الاستخدام" }).getAttribute("href")).toBe("/terms");
  });

  it("يعرض شروط الاستخدام مع رابط سياسة الخصوصية", () => {
    render(<Terms />);

    expect(screen.getByRole("heading", { name: "شروط الاستخدام" })).toBeTruthy();
    expect(screen.getByRole("link", { name: "سياسة الخصوصية" }).getAttribute("href")).toBe("/privacy");
    expect(screen.getByRole("link", { name: "العودة إلى مسرى" }).getAttribute("href")).toBe("/");
  });
});
