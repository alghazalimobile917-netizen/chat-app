import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { MemberAuthPanel } from "@/components/MemberAuthPanel";
import { type Gender, type LocalSession, clearLocalSession, persistLocalSession, restoreLocalSession } from "@/lib/session";
import { BUILTIN_NAME_DECORATIONS, DEFAULT_DISPLAY_PREFERENCES, FONT_OPTIONS, getDefaultComposerTextColor, getDefaultOwnMessageTextColor, normalizeDisplayPreferences, readDisplayPreferences, saveDisplayPreferences, type DisplayPreferences, type NameDecorationOption } from "@/lib/displayPreferences";
import { DisplayPreferencesDialog } from "@/components/DisplayPreferencesDialog";
import { HomepageSupportDialog, type SupportTopic } from "@/components/HomepageSupportDialog";
import { AdSenseAutoLoader } from "@/components/AdSenseAutoLoader";
import { trpc } from "@/lib/trpc";
import { BOUH_SYSTEM_SESSION_ID } from "@shared/const";
import { cn } from "@/lib/utils";
import { useTheme } from "@/contexts/ThemeContext";
import { getNewUnreadPeerIds, getTotalUnread, getUnreadPeerIds, playNotificationClickTone, playPrivateNotificationTone, preparePrivateNotificationAudio, type UnreadCounts } from "@/lib/notifications";
import { getMessageReadLabel } from "@/lib/chatIndicators";
import { appendUniqueChatMessage, filterMembersWithIncomingPrivateMessages, removeOptimisticChatMessage, replaceOptimisticChatMessage } from "@/lib/chatMessages";
import {
  Ban,
  Bell,
  BookOpen,
  BellOff,
  Flag,
  ChevronRight,
  Circle,
  Clock3,
  Crown,
  Heart,
  Hash,
  Menu,
  Share2,
  PanelRightClose,
  Pin,
  Search,
  Settings2,
  ImagePlus,
  Plus,
  Volume2,
  VolumeX,
  Loader2,
  LockKeyhole,
  LogOut,
  MessageCircle,
  Pencil,
  Radio,
  Send,
  ShieldCheck,
  Trash2,
  Check,
  CheckCheck,
  UserRound,
  Users,
  UserPlus,
  X,
  Moon,
  Sun,
} from "lucide-react";
import React, { ChangeEvent, FormEvent, lazy, Suspense, type CSSProperties, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

const AdminPanel = lazy(() => import("@/components/AdminPanel").then((module) => ({ default: module.AdminPanel })));
const ProfileSettingsDialog = lazy(() => import("@/components/ProfileSettingsDialog").then((module) => ({ default: module.ProfileSettingsDialog })));

type Room = {
  id: number;
  name: string;
  isDefault: boolean;
  createdAt?: Date;
  backgroundKey?: string | null;
  backgroundMimeType?: string | null;
};

export function getMemberPanelClass(isOpen: boolean) {
  return cn(
    "fixed right-3 top-[7.25rem] z-30 h-[calc(100vh-7.75rem)] w-[min(320px,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-3xl border border-white/70 bg-white/55 shadow-[-18px_18px_45px_-24px_rgba(30,50,90,0.5)] backdrop-blur-2xl md:right-5 md:w-[320px] dark:border-white/10 dark:bg-[#17213d]/70",
    isOpen ? "flex" : "hidden",
  );
}

export function getMemberPanelToggleLabel(isOpen: boolean) {
  return isOpen ? "إخفاء لوحة الأعضاء" : "إظهار لوحة الأعضاء";
}

export function getHomepageSupportActionsClass() {
  return "grid grid-cols-3 gap-2";
}

type Member = {
  sessionId: string;
  displayName: string;
  age: number;
  gender: Gender;
  role: "member" | "admin";
  lastSeenAt: Date;
  avatarKey?: string | null;
  avatarMimeType?: string | null;
  acceptsPrivateMessages: boolean;
  privateMessagePolicy: "everyone" | "friends" | "nobody";
  showPresence: boolean;
  isRegistered: boolean;
  isBlocked: boolean;
  hasBlockedViewer: boolean;
  countryCode?: string | null;
};

export type ChatMessage = {
  id: number;
  roomId: number;
  channel: "public" | "private";
  senderSessionId: string;
  recipientSessionId: string | null;
  body: string | null;
  imageKey: string | null;
  imageMimeType: string | null;
  pendingImageUrl?: string;
  readAt: Date | null;
  createdAt: Date;
  deletedAt: Date | null;
  sender: { sessionId: string; displayName: string; gender: Gender } | null;
  recipient: { sessionId: string; displayName: string; gender: Gender } | null;
};

let optimisticMessageSequence = 0;
function createOptimisticChatMessage({ sessionId, displayName, gender, roomId, channel, body, peerSessionId, image }: { sessionId: string; displayName: string; gender: Gender; roomId: number; channel: "public" | "private"; body: string; peerSessionId?: string; image?: OutgoingImage }): ChatMessage {
  return {
    id: -(++optimisticMessageSequence),
    roomId,
    channel,
    senderSessionId: sessionId,
    recipientSessionId: peerSessionId ?? null,
    body: body || null,
    imageKey: null,
    imageMimeType: image?.mimeType ?? null,
    pendingImageUrl: image?.dataUrl,
    readAt: null,
    createdAt: new Date(),
    deletedAt: null,
    sender: { sessionId, displayName, gender },
    recipient: null,
  };
}

function genderClass(gender: Gender) {
  return gender === "male" ? "text-blue-600" : "text-pink-600";
}

function genderSoftClass(gender: Gender) {
  return gender === "male" ? "bg-blue-50 text-blue-700 ring-blue-100" : "bg-pink-50 text-pink-700 ring-pink-100";
}

function initialFor(name: string) {
  return name.trim().slice(0, 1).toUpperCase() || "؟";
}

export function normalizeDisplayCountryCode(countryCode?: string | null) {
  const raw = countryCode?.trim().toUpperCase();
  if (!raw) return null;
  const firstCode = raw.split(/[\s,;|/_-]+/, 1)[0] ?? "";
  const aliases: Record<string, string> = { UK: "GB", EL: "GR" };
  const code = aliases[firstCode] ?? firstCode;
  return /^[A-Z]{2}$/.test(code) && !new Set(["XX", "ZZ", "UN", "T1", "EU"]).has(code) ? code : null;
}

export function countryFlag(countryCode?: string | null) {
  const code = normalizeDisplayCountryCode(countryCode);
  if (!code) return "🌐";
  return String.fromCodePoint(...code.split("").map((letter) => 127397 + letter.charCodeAt(0)));
}

export function isFatalChatSessionError(error: unknown) {
  const message = error instanceof Error ? error.message : String(error ?? "");
  return /انتهت الجلسة|تم تعطيل هذه الجلسة|سجّل الدخول من جديد/.test(message);
}

function formatTime(value: Date) {
  return new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit" }).format(new Date(value));
}

function storedImageUrl(key: string) {
  return `/manus-storage/${key}`;
}

export function getVisualViewportKeyboardInset(viewportHeight: number, layoutHeight: number, offsetTop = 0) {
  return Math.max(0, Math.round(layoutHeight - viewportHeight - offsetTop));
}

function createSessionId() {
  return typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `chat-${Date.now()}-${Math.random().toString(36).slice(2, 14)}`;
}

function Name({ name, gender, className }: { name: string; gender: Gender; className?: string }) {
  return <span className={cn("font-bold", genderClass(gender), className)}>{name}</span>;
}

type PrivateAccessMember = Pick<Member, "sessionId" | "acceptsPrivateMessages" | "privateMessagePolicy" | "isBlocked" | "hasBlockedViewer">;
export type PrivateAccessReason = "self" | "blocked" | "friends" | "disabled";

export function getPrivateAccessReason(member: PrivateAccessMember, viewerSessionId: string, hasAcceptedFriend: boolean) : PrivateAccessReason | null {
  if (member.sessionId === viewerSessionId) return "self";
  if (member.isBlocked || member.hasBlockedViewer) return "blocked";
  if (member.privateMessagePolicy === "friends" && !hasAcceptedFriend) return "friends";
  if (member.acceptsPrivateMessages === false || member.privateMessagePolicy === "nobody") return "disabled";
  return null;
}

export function getReplyComposerDraft(displayName: string) {
  return `@${displayName.trim()} `;
}

export function shouldShowAdminPassword(displayName: string) {
  const normalizedName = displayName.trim().toLocaleLowerCase("ar");
  return ["الادارة", "الإدارة", "admin", "administrator"].includes(normalizedName);
}

export function AdminPasswordField({ visible, value, onChange }: { visible: boolean; value: string; onChange: (value: string) => void }) {
  if (!visible) return null;
  return <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3">
    <label className="flex items-center gap-2 text-sm font-bold text-slate-700"><ShieldCheck className="size-4 text-slate-500" /> كلمة سر الإدارة</label>
    <Input type="password" value={value} onChange={(event) => onChange(event.target.value)} placeholder="أدخل كلمة سر الإدارة" autoComplete="current-password" className="mt-3 h-11 rounded-lg border-slate-200 bg-white text-right" />
  </div>;
}

function MasraWordmark({ className, light = false }: { className?: string; light?: boolean }) {
  return (
    <span className={cn("relative inline-block font-black tracking-[-0.02em]", light ? "text-white" : "text-slate-950", className)} aria-label="مسرى">
      مسرى
      <Heart className="absolute -top-2 -left-3 size-[0.7em] fill-rose-500 text-rose-500 drop-shadow-sm" strokeWidth={2.6} aria-hidden="true" />
    </span>
  );
}

export const MASRA_BLOG_URL = "https://chatmasra.blogspot.com/#mr-blog";

function getPlatformShareLink() {
  return typeof window !== "undefined" ? window.location.origin : "https://chatapp-9gpzhnwm.manus.space";
}
export async function sharePlatformExternally() {
  const link = getPlatformShareLink();
  if (navigator.share) await navigator.share({ url: link });
  else if (navigator.clipboard) await navigator.clipboard.writeText(link);
  else throw new Error("المتصفح لا يدعم مشاركة الرابط أو نسخه.");
}
function LoginScreen({ onSessionCreated }: { onSessionCreated: (session: LocalSession) => void }) {
  const [entryMode, setEntryMode] = useState<"guest" | "member">("guest");
  const [displayName, setDisplayName] = useState("");
  const [age, setAge] = useState("20");
  const [gender, setGender] = useState<Gender>("male");
  const [nameDecoration, setNameDecoration] = useState("none");
  const [adminCode, setAdminCode] = useState("");
  const [supportOpen, setSupportOpen] = useState(false);
  const [supportTopic, setSupportTopic] = useState<SupportTopic>("contact");
  const showAdminPassword = shouldShowAdminPassword(displayName);
  const decorationsQuery = trpc.chat.nameDecorations.useQuery(undefined, { staleTime: 60_000, retry: 1 });
  const decorationOptions: NameDecorationOption[] = decorationsQuery.data?.decorations?.length ? decorationsQuery.data.decorations : BUILTIN_NAME_DECORATIONS;
  const selectedDecoration = decorationOptions.find((option) => option.key === nameDecoration) ?? decorationOptions.find((option) => option.key === "none") ?? decorationOptions[0];

  useEffect(() => {
    if (selectedDecoration && selectedDecoration.key !== nameDecoration) setNameDecoration(selectedDecoration.key);
  }, [nameDecoration, selectedDecoration]);

  const createSession = trpc.chat.createSession.useMutation({
    onSuccess: ({ profile }) => {
      const session: LocalSession = {
        sessionId: profile.sessionId,
        displayName: profile.displayName,
        age: profile.age,
        gender: profile.gender,
        role: profile.role,
        isGuest: true,
      };
      persistLocalSession(session);
      onSessionCreated(session);
      toast.success("أهلاً بك في مسرى.");
    },
    onError: (error) => toast.error(error.message),
  });

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const numericAge = Number(age);
    if (displayName.trim().length < 2) {
      toast.error("أدخل اسماً من حرفين على الأقل.");
      return;
    }
    if (!Number.isInteger(numericAge) || numericAge < 1 || numericAge > 120) {
      toast.error("أدخل عمراً صحيحاً بين 1 و120.");
      return;
    }
    if (showAdminPassword && !adminCode.trim()) {
      toast.error("أدخل كلمة سر الإدارة للمتابعة.");
      return;
    }
    createSession.mutate({
      sessionId: createSessionId(),
      displayName: displayName.trim(),
      age: numericAge,
      gender,
      adminCode: showAdminPassword ? adminCode.trim() : undefined,
      nameDecoration: selectedDecoration?.key ?? "none",
    });
  };

  return (
    <>
      <AdSenseAutoLoader />
      <main className="relative min-h-screen overflow-hidden bg-[#0b102b] px-4 py-8 text-white sm:px-6 lg:px-10" dir="rtl">
      <div className="login-orb login-orb-a" />
      <div className="login-orb login-orb-b" />
      <div className="bouh-grid" />
      <div className="mx-auto grid min-h-[calc(100vh-4rem)] max-w-6xl items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
        <section className="relative order-2 text-center lg:order-1 lg:text-right">
          <div className="bouh-signature mb-7">
            <span className="bouh-signature-icon"><Heart className="size-4 fill-rose-400 text-rose-400" /></span>
            <span>مساحة هادئة لقول ما تريد</span>
          </div>
          <div className="mb-5 hidden justify-start lg:flex"><span className="bouh-rule" /></div>
          <h1 className="max-w-2xl text-5xl font-black leading-[1.18] tracking-[-0.045em] text-white sm:text-6xl">
            كل ما تريد قوله، يجد مكانه في <MasraWordmark className="text-blue-600" />.
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-base leading-8 text-slate-300 lg:mx-0">
            ادخل باسمك، تعرّف إلى المتصلين، وابدأ حديثاً عاماً أو خاصاً ضمن واجهة عربية هادئة وواضحة.
          </p>
          <div className="mt-9 flex flex-wrap justify-center gap-3 lg:justify-start">
            <div className="bouh-card rounded-2xl border border-white bg-white/70 px-4 py-3 text-right shadow-sm backdrop-blur">
              <p className="text-xs text-slate-400">غرفة عامة</p>
              <p className="mt-1 text-sm font-bold text-slate-800">لجميع المتصلين</p>
            </div>
            <div className="bouh-card rounded-2xl border border-white bg-white/70 px-4 py-3 text-right shadow-sm backdrop-blur">
              <p className="text-xs text-slate-400">دردشة خاصة</p>
              <p className="mt-1 text-sm font-bold text-slate-800">بنقرة واحدة</p>
            </div>
            <div className="bouh-card rounded-2xl border border-white bg-white/70 px-4 py-3 text-right shadow-sm backdrop-blur">
              <p className="text-xs text-slate-400">تحديث مباشر</p>
              <p className="mt-1 text-sm font-bold text-slate-800">كل بضع ثوانٍ</p>
            </div>
          </div>
        </section>

        <section className="order-1 mx-auto w-full max-w-md lg:order-2">
          <div className="rounded-[2rem] border border-white/90 bg-white/90 p-6 shadow-[0_28px_90px_-38px_rgba(20,35,70,0.42)] backdrop-blur-xl sm:p-8">
            <div className="mb-8 flex items-center gap-3">
              <div className="grid size-12 place-items-center rounded-2xl bg-[#172554] text-white shadow-lg shadow-blue-950/20">
                <MessageCircle className="size-6" />
              </div>
              <div>
                <p className="text-xl leading-none"><MasraWordmark /></p>
                <p className="mt-1 text-xs font-medium text-slate-400">الدخول إلى مساحة المسرى</p>
              </div>
            </div>

            <a href={MASRA_BLOG_URL} className="mb-5 flex min-h-11 items-center justify-center gap-2 rounded-xl border border-blue-100 bg-blue-50/60 px-3 py-2.5 text-sm font-bold text-blue-700 transition hover:bg-blue-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500" aria-label="فتح الصفحة الرئيسية التعريفية لمسرى"><BookOpen className="size-4" aria-hidden="true" />الصفحة الرئيسية لمسرى</a>
            <div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-slate-100 p-1" role="tablist" aria-label="طريقة الدخول إلى مسرى"><button type="button" role="tab" aria-selected={entryMode === "guest"} onClick={() => setEntryMode("guest")} className={cn("rounded-lg px-3 py-2.5 text-sm font-bold transition", entryMode === "guest" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500")}>دخول سريع كزائر</button><button type="button" role="tab" aria-selected={entryMode === "member"} onClick={() => setEntryMode("member")} className={cn("rounded-lg px-3 py-2.5 text-sm font-bold transition", entryMode === "member" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500")}>عضو دائم</button></div>
            {entryMode === "member" ? <MemberAuthPanel onSessionCreated={onSessionCreated} onGuestSelected={() => setEntryMode("guest")} /> : <form className="space-y-5" onSubmit={submit}>
              <label className="block space-y-2">
                <span className="text-sm font-bold text-slate-700">الاسم الظاهر</span>
                <Input value={displayName} onChange={(event) => setDisplayName(event.target.value)} maxLength={32} placeholder="اكتب اسمك" className="h-12 rounded-xl border-slate-200 bg-slate-50/70 text-right text-black shadow-none placeholder:text-slate-500 focus-visible:ring-blue-500" />
              </label>
              <label className="block space-y-2">
                <span className="text-sm font-bold text-slate-700">العمر</span>
                <Input type="number" value={age} onChange={(event) => setAge(event.target.value)} min="1" max="120" className="h-12 rounded-xl border-slate-200 bg-slate-50/70 text-right text-black shadow-none focus-visible:ring-blue-500" />
              </label>
              <fieldset className="space-y-2">
                <legend className="text-sm font-bold text-slate-700">الجنس</legend>
                <div className="grid grid-cols-2 gap-3">
                  <button type="button" onClick={() => setGender("male")} className={cn("flex h-12 items-center justify-center gap-2 rounded-xl border text-sm font-bold transition-all", gender === "male" ? "border-blue-200 bg-blue-50 text-blue-700 shadow-sm" : "border-slate-200 bg-white text-slate-500 hover:bg-slate-50")}>
                    <span className="size-2 rounded-full bg-blue-500" /> ذكر
                  </button>
                  <button type="button" onClick={() => setGender("female")} className={cn("flex h-12 items-center justify-center gap-2 rounded-xl border text-sm font-bold transition-all", gender === "female" ? "border-pink-200 bg-pink-50 text-pink-700 shadow-sm" : "border-slate-200 bg-white text-slate-500 hover:bg-slate-50")}>
                    <span className="size-2 rounded-full bg-pink-500" /> أنثى
                  </button>
                </div>
                            </fieldset>
              <label className="block space-y-2"><span className="text-sm font-bold text-slate-700">زخرفة الاسم</span><select aria-label="زخرفة الاسم" value={selectedDecoration?.key ?? "none"} onChange={(event) => setNameDecoration(event.target.value)} disabled={decorationsQuery.isLoading && !decorationsQuery.data} className="h-12 w-full rounded-xl border border-slate-200 bg-slate-50/70 px-3 text-right text-sm font-bold text-black disabled:cursor-wait disabled:opacity-70">{decorationOptions.map((option) => <option key={option.key} value={option.key}>{option.label}</option>)}</select><span className="block text-xs text-slate-400">{decorationsQuery.isError ? "تعذر تحديث القائمة؛ ستظهر الخيارات الأساسية مؤقتاً." : "سيظهر الاسم بهذه الزخرفة للأعضاء الآخرين."}</span></label>
              <AdminPasswordField visible={showAdminPassword} value={adminCode} onChange={setAdminCode} />

              <Button type="submit" disabled={createSession.isPending} className="h-12 w-full rounded-xl bg-[#172554] text-base font-bold text-white shadow-lg shadow-blue-950/20 hover:bg-[#1e3a8a]">
                {createSession.isPending ? <Loader2 className="size-5 animate-spin" /> : <>ادخل إلى الدردشة <ChevronRight className="size-5" /></>}
              </Button>
            </form>}
            <p className="mt-5 text-center text-xs leading-6 text-slate-400">الزائر مؤقت وسريع، أما العضو الدائم فيحتفظ بمحادثاته وصورته الشخصية وأصدقائه بعد تسجيل الدخول لاحقاً.</p>
            <nav aria-label="الروابط القانونية" className="mt-4 flex flex-wrap items-center justify-center gap-x-4 gap-y-2 border-t border-slate-200 pt-4 text-xs"><a href="/privacy" className="font-bold text-blue-700 hover:text-blue-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500">سياسة الخصوصية</a><a href="/terms" className="font-bold text-blue-700 hover:text-blue-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500">شروط الاستخدام</a></nav>
            <div data-testid="homepage-support-actions" className={`${getHomepageSupportActionsClass()} mt-4 border-t border-slate-100 pt-4`}>
              <Button type="button" variant="outline" className="min-h-11 rounded-xl border-blue-100 bg-blue-50/60 p-0 text-blue-700 hover:bg-blue-100" onClick={() => void sharePlatformExternally().then(() => toast.success("تمت مشاركة رابط منصة مسرى أو نسخه.")).catch((error) => { if (error?.name !== "AbortError") toast.error("تعذر مشاركة رابط المنصة."); })} aria-label="مشاركة منصة مسرى" title="مشاركة منصة مسرى"><Share2 className="size-4" /></Button>
              <button type="button" onClick={() => { setSupportTopic("report"); setSupportOpen(true); }} className="flex min-h-11 items-center justify-center gap-1 rounded-xl border border-amber-200 bg-amber-50/70 px-2 py-2 text-xs font-bold text-amber-800 transition hover:bg-amber-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"><Flag className="size-4 shrink-0" aria-hidden="true" />بلّغ</button>
              <button type="button" onClick={() => { setSupportTopic("contact"); setSupportOpen(true); }} className="flex min-h-11 items-center justify-center gap-1 rounded-xl border border-blue-100 bg-blue-50/70 px-2 py-2 text-xs font-bold text-blue-800 transition hover:bg-blue-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"><MessageCircle className="size-4 shrink-0" aria-hidden="true" />تواصل مع الإدارة</button>
            </div>
          </div>
        </section>
      </div>
    <HomepageSupportDialog open={supportOpen} onOpenChange={setSupportOpen} initialTopic={supportTopic} />
    </main>
    </>
  );
}

function MemberItem({ member, active, unreadCount = 0, onSelect, self }: { member: Member; active?: boolean; unreadCount?: number; onSelect: () => void; self?: boolean }) {
  return (
    <button type="button" onClick={onSelect} disabled={self} className={cn("group flex w-full items-center gap-2 rounded-xl px-2 py-2.5 text-right transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 sm:gap-3 sm:rounded-2xl sm:px-3 sm:py-3", active ? "bg-slate-100 shadow-sm ring-1 ring-inset ring-slate-200" : "hover:bg-slate-50", self && "cursor-default")} aria-current={active ? "true" : undefined}>
      <div className="relative shrink-0">
        <Avatar className={cn("size-8 ring-2 sm:size-10", active ? "ring-white/20" : genderSoftClass(member.gender).split(" ").slice(-1)[0])}>
          {member.avatarKey && <AvatarImage src={storedImageUrl(member.avatarKey)} alt={`صورة ${member.displayName}`} />}
          <AvatarFallback className={cn("font-black", active ? "bg-white/15 text-white" : genderSoftClass(member.gender).split(" ").slice(0, 2).join(" "))}>{initialFor(member.displayName)}</AvatarFallback>
        </Avatar>
        <span className="absolute -bottom-0.5 -left-0.5 size-3 rounded-full border-2 border-white bg-emerald-400" />
      </div>
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1 truncate text-[11px] sm:gap-1.5 sm:text-sm"><span className="inline-flex items-center gap-1"><Name name={member.displayName} gender={member.gender} /><span className="text-sm leading-none" title="بلد العضو" aria-label="علم بلد العضو">{countryFlag(member.countryCode)}</span></span>{member.role === "admin" && <Crown className="size-3 text-amber-500 sm:size-3.5" />}{member.isRegistered ? <span className="rounded-md bg-blue-50 px-1 py-0.5 text-[8px] font-black text-blue-700">عضو</span> : <span className="rounded-md bg-slate-100 px-1 py-0.5 text-[8px] font-bold text-slate-500">زائر</span>}{!self && unreadCount > 0 && <span className="inline-flex min-w-5 items-center justify-center rounded-full bg-rose-500 px-1.5 py-0.5 text-[10px] font-black leading-none text-white shadow-sm shadow-rose-500/25" aria-label={`${unreadCount} رسائل غير مقروءة`}>{unreadCount > 99 ? "99+" : unreadCount}</span>}</span>
        <span className="mt-0.5 block text-[10px] text-slate-400 sm:mt-1 sm:text-xs">{self ? "أنت الآن" : member.showPresence ? "متصل الآن" : "الحضور مخفي"}</span>
      </span>
      {!self && <ChevronRight className={cn("hidden size-4 transition-transform group-hover:-translate-x-0.5 sm:block", active ? "text-slate-300" : "text-slate-300")} />}
    </button>
  );
}

function MessageFeed({ messages, currentSessionId, emptyText, canDelete, onDelete, onReport, isPrivate, memberBySession, onAvatarClick, onNameClick, ownMessageStyle }: { messages: ChatMessage[]; currentSessionId: string; emptyText: string; canDelete?: boolean; onDelete?: (messageId: number) => void; onReport?: (messageId: number, targetSessionId: string) => void; isPrivate?: boolean; memberBySession?: Record<string, Member>; onAvatarClick?: (sender: NonNullable<ChatMessage["sender"]>) => void; onNameClick?: (sender: NonNullable<ChatMessage["sender"]>) => void; ownMessageStyle?: CSSProperties }) {
  const endRef = useRef<HTMLDivElement>(null);
  const [previewImage, setPreviewImage] = useState<{ url: string; sender: string } | null>(null);
  useEffect(() => {
    const frame = window.requestAnimationFrame(() => endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }));
    return () => window.cancelAnimationFrame(frame);
  }, [messages.length, messages[messages.length - 1]?.id]);

  if (!messages.length) {
    return <div className="grid h-full place-items-center px-6 text-center"><div><div className="mx-auto grid size-14 place-items-center rounded-2xl bg-slate-100 text-slate-400"><MessageCircle className="size-6" /></div><p className="mt-4 text-sm font-bold text-slate-600">{emptyText}</p><p className="mt-1 text-xs text-slate-400">كن أول من يرسل رسالة.</p></div></div>;
  }
  return (
    <div className="chat-shell min-w-0 max-w-full space-y-5 overflow-x-hidden px-1 py-2">
      {messages.map((message) => {
        if (message.senderSessionId === BOUH_SYSTEM_SESSION_ID) {
          return <div key={message.id} className="flex w-full justify-center px-2 py-1"><span className="max-w-full rounded-full border border-blue-100 bg-blue-50 px-3 py-1.5 text-center text-[11px] font-bold leading-5 text-blue-700" role="status">{message.deletedAt ? "تم حذف هذه الرسالة بواسطة المسؤول" : message.body}</span></div>;
        }
        const own = message.senderSessionId === currentSessionId;
        const sender = message.sender ?? { sessionId: message.senderSessionId, displayName: "مستخدم محذوف", gender: "male" as Gender };
        const senderProfile = memberBySession?.[sender.sessionId];
        const canInteractWithSender = !own && !message.deletedAt && sender.sessionId !== BOUH_SYSTEM_SESSION_ID;
        return (
          <article key={message.id} className={cn("flex w-full min-w-0 max-w-full gap-2 sm:gap-3", own ? "flex-row-reverse" : "") }>
            {canInteractWithSender && onAvatarClick ? <button type="button" onClick={() => onAvatarClick(sender)} className="mt-1 shrink-0 rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500" aria-label={`فتح محادثة خاصة مع ${sender.displayName}`} title={`مراسلة ${sender.displayName} خاصاً`}><Avatar className={cn("size-9", genderSoftClass(sender.gender).split(" ").slice(-1)[0])}>
              {senderProfile?.avatarKey && <AvatarImage src={storedImageUrl(senderProfile.avatarKey)} alt={`صورة ${sender.displayName}`} />}
              <AvatarFallback className={cn("text-xs font-black", genderSoftClass(sender.gender).split(" ").slice(0, 2).join(" "))}>{initialFor(sender.displayName)}</AvatarFallback>
            </Avatar></button> : <Avatar className={cn("mt-1 size-9 shrink-0", genderSoftClass(sender.gender).split(" ").slice(-1)[0])}>
              {senderProfile?.avatarKey && <AvatarImage src={storedImageUrl(senderProfile.avatarKey)} alt={`صورة ${sender.displayName}`} />}
              <AvatarFallback className={cn("text-xs font-black", genderSoftClass(sender.gender).split(" ").slice(0, 2).join(" "))}>{initialFor(sender.displayName)}</AvatarFallback>
            </Avatar>}
            <div className={cn("w-full min-w-0 max-w-[calc(100%_-_2.75rem)] sm:max-w-[72%]", own ? "text-left" : "text-right")}>
              <div className={cn("mb-1 flex items-center gap-2 text-xs", own ? "justify-start" : "justify-end")}>
                {canInteractWithSender && onNameClick ? <button type="button" onClick={() => onNameClick(sender)} className="rounded-md px-1 text-right focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500" aria-label={`الرد على ${sender.displayName}`} title={`الرد على ${sender.displayName}`}><Name name={sender.displayName} gender={sender.gender} /></button> : <Name name={sender.displayName} gender={sender.gender} />}
                  <span className="text-slate-400">{formatTime(message.createdAt)}</span>
                  {isPrivate && own && !message.deletedAt && <span className={cn("inline-flex items-center gap-0.5", message.readAt ? "text-blue-500" : "text-slate-400")} title={getMessageReadLabel(message.readAt, own) ?? undefined} aria-label={getMessageReadLabel(message.readAt, own) ?? undefined}>{message.readAt ? <CheckCheck className="size-3.5" /> : <Check className="size-3.5" />}</span>}
                  {canDelete && onDelete && !message.deletedAt && <button type="button" onClick={() => onDelete(message.id)} className="rounded-md p-1 text-rose-500 hover:bg-rose-50" aria-label="حذف الرسالة"><Trash2 className="size-3" /></button>}
                  {onReport && !own && !message.deletedAt && <button type="button" onClick={() => onReport(message.id, sender.sessionId)} className="rounded-md p-1 text-slate-400 hover:bg-amber-50 hover:text-amber-600" aria-label="الإبلاغ عن الرسالة" title="الإبلاغ عن الرسالة"><Flag className="size-3" /></button>}
                </div>
              <div className={cn("chat-message-content rounded-2xl text-right text-sm leading-7 shadow-sm", message.deletedAt ? "border border-dashed border-slate-200 bg-slate-50 px-4 py-3 text-slate-400" : message.imageKey || message.pendingImageUrl ? "p-1.5" : "px-4 py-3", own ? "rounded-tl-md" : "rounded-tr-md", !message.deletedAt && (own ? "bg-[#182642] text-white shadow-blue-950/10" : "border border-[#e8edf5] bg-white/95 text-slate-700"))}>
                {message.deletedAt ? <p className="italic" role="status">تم حذف هذه الرسالة بواسطة المسؤول</p> : <>
                  {(message.imageKey || message.pendingImageUrl) && <button type="button" onClick={() => { const url = message.pendingImageUrl ?? storedImageUrl(message.imageKey!); setPreviewImage({ url, sender: sender.displayName }); }} className="block overflow-hidden rounded-xl focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:outline-none" aria-label={`عرض الصورة المرسلة من ${sender.displayName}`}><img src={message.pendingImageUrl ?? storedImageUrl(message.imageKey!)} alt={`صورة أرسلها ${sender.displayName}`} className="max-h-80 max-w-full rounded-xl object-cover transition-transform duration-200 hover:scale-[1.02]" loading="lazy" /></button>}
                  {message.body && <p style={own ? ownMessageStyle : undefined} className={cn("whitespace-pre-wrap break-words", (message.imageKey || message.pendingImageUrl) && "px-2 pb-1 pt-2")}>{message.body}</p>}
                </>}
              </div>
            </div>
          </article>
        );
      })}
      <div ref={endRef} />
      <Dialog open={Boolean(previewImage)} onOpenChange={(open) => !open && setPreviewImage(null)}>
        <DialogContent className="max-w-4xl border-0 bg-slate-950 p-2 text-white sm:max-w-4xl">
          <DialogTitle className="sr-only">معاينة الصورة المرسلة من {previewImage?.sender}</DialogTitle>
          {previewImage && <img src={previewImage.url} alt={`صورة أرسلها ${previewImage.sender}`} className="max-h-[80vh] w-full rounded-md object-contain" />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

type OutgoingImage = { dataUrl: string; mimeType: "image/png" | "image/jpeg" | "image/webp" | "image/gif" };
type OutgoingMessage = { body: string; image?: OutgoingImage };

async function compressImageFile(file: File): Promise<OutgoingImage> {
  const sourceUrl = URL.createObjectURL(file);
  try {
    const source = new Image();
    source.decoding = "async";
    source.src = sourceUrl;
    await new Promise<void>((resolve, reject) => { source.onload = () => resolve(); source.onerror = () => reject(new Error("image-load")); });
    const scale = Math.min(1, 1600 / Math.max(source.naturalWidth, source.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(source.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(source.naturalHeight * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("canvas-unavailable");
    context.drawImage(source, 0, 0, canvas.width, canvas.height);
    const mimeType: OutgoingImage["mimeType"] = "image/webp";
    const dataUrl = canvas.toDataURL(mimeType, 0.82);
    return { dataUrl, mimeType };
  } finally {
    URL.revokeObjectURL(sourceUrl);
  }
}

function Composer({ placeholder, pending, onSend, onTyping, keyboardInset, replyTarget, onClearReply, textStyle }: { placeholder: string; pending: boolean; onSend: (content: OutgoingMessage) => void; onTyping?: (isTyping: boolean) => void; keyboardInset: number; replyTarget?: string | null; onClearReply?: () => void; textStyle: CSSProperties }) {
  const [body, setBody] = useState("");
  const textInputRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => {
    if (!replyTarget) return;
    setBody((current) => current.trim() ? current : getReplyComposerDraft(replyTarget));
    requestAnimationFrame(() => textInputRef.current?.focus());
  }, [replyTarget]);
  const [image, setImage] = useState<OutgoingImage | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const selectImage = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    const supportedTypes = ["image/png", "image/jpeg", "image/webp", "image/gif"] as const;
    if (!supportedTypes.includes(file.type as OutgoingImage["mimeType"])) {
      toast.error("الصور المدعومة: PNG وJPG وWEBP وGIF.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("يجب ألا يتجاوز حجم الصورة 5 ميغابايت.");
      return;
    }
    compressImageFile(file).then(setImage).catch(() => toast.error("تعذر ضغط الصورة. حاول مرة أخرى."));
  };
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if ((!body.trim() && !image) || pending) return;
    onTyping?.(false);
    onSend({ body: body.trim(), image: image ?? undefined });
    setBody("");
    setImage(null);
  };
  return (
    <form onSubmit={submit} style={{ "--bouh-keyboard-inset": `${keyboardInset}px` } as CSSProperties} className="chat-shell chat-composer fixed inset-x-0 bottom-[var(--bouh-keyboard-inset)] z-40 w-full max-w-full min-w-0 border-t border-slate-200/80 bg-white/90 px-3 py-3 shadow-[0_-12px_35px_-28px_rgba(30,50,90,.45)] backdrop-blur sm:px-6 sm:py-4">
      {replyTarget && <div data-testid="reply-banner" className="mb-3 flex w-fit max-w-full items-center gap-2 rounded-xl border border-blue-100 bg-blue-50/75 px-3 py-2 text-xs text-blue-800"><MessageCircle className="size-3.5 shrink-0" /><span className="truncate">الرد على <strong>{replyTarget}</strong></span><button type="button" onClick={onClearReply} className="rounded-md p-1 text-blue-500 hover:bg-white hover:text-blue-700" aria-label="إلغاء الرد" title="إلغاء الرد"><X className="size-3.5" /></button></div>}
      {image && <div className="mb-3 flex w-fit max-w-full items-start gap-3 rounded-2xl border border-blue-100 bg-blue-50/60 p-2"><img src={image.dataUrl} alt="معاينة الصورة المختارة" className="size-16 shrink-0 rounded-xl object-cover" /><div className="min-w-0 pt-1 text-right"><p className="text-xs font-bold text-slate-700">صورة جاهزة للإرسال</p><p className="mt-1 text-[11px] text-slate-400">يمكنك إضافة تعليق أو الإرسال مباشرة.</p></div><Button type="button" size="icon" variant="ghost" onClick={() => setImage(null)} className="size-8 rounded-lg text-slate-400 hover:bg-white hover:text-rose-600" aria-label="إزالة الصورة المختارة"><X className="size-4" /></Button></div>}
      <div className="chat-composer-row flex w-full max-w-full min-w-0 items-end gap-1.5 sm:gap-3">
        <label className={cn("flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 transition-colors hover:border-blue-200 hover:bg-blue-50 hover:text-blue-600", pending && "pointer-events-none cursor-not-allowed opacity-50")} aria-label="إرفاق صورة">
          <Input ref={imageInputRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={selectImage} disabled={pending} className="sr-only" aria-label="اختيار صورة" />
          <ImagePlus className="size-4" aria-hidden="true" />
        </label>
        <Textarea data-testid="message-composer" ref={textInputRef} value={body} onChange={(event) => { setBody(event.target.value); onTyping?.(Boolean(event.target.value.trim())); }} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); submit(event); } }} placeholder={placeholder} rows={1} maxLength={1200} style={textStyle} className="min-h-11 min-w-0 flex-1 resize-none rounded-xl border-slate-200 bg-slate-50 px-4 py-3 text-right leading-5 text-slate-900 shadow-none placeholder:text-slate-400 focus-visible:ring-blue-500 dark:bg-slate-900/80 dark:text-slate-50" />
        <Button type="button" variant="outline" disabled={pending} onClick={() => void sharePlatformExternally().then(() => toast.success("تمت مشاركة رابط منصة مسرى أو نسخه.")).catch((error) => { if (error?.name !== "AbortError") toast.error("تعذر مشاركة رابط المنصة."); })} className="size-11 shrink-0 rounded-xl border-blue-100 bg-blue-50 p-0 text-blue-700 hover:bg-blue-100" aria-label="مشاركة منصة مسرى" title="مشاركة منصة مسرى"><Share2 className="size-4" /></Button>
        <Button type="submit" disabled={(!body.trim() && !image) || pending} className="size-11 shrink-0 rounded-xl bg-[#2563eb] p-0 shadow-md shadow-blue-500/25 hover:bg-[#1d4ed8]" aria-label="إرسال الرسالة">
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
        </Button>
      </div>
    </form>
  );
}


function UnifiedSettingsDialog({
  open,
  onOpenChange,
  onOpenProfile,
  onOpenDisplay,
  onOpenFriends,
  theme,
  toggleTheme,
  soundEnabled,
  onToggleSound,
  memberToken,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onOpenProfile: () => void;
  onOpenDisplay: () => void;
  onOpenFriends: () => void;
  theme: "light" | "dark";
  toggleTheme?: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  memberToken?: string;
}) {
  const openChild = (callback: () => void) => {
    onOpenChange(false);
    callback();
  };
  return <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent dir="rtl" className="max-w-sm">
      <DialogTitle className="flex items-center gap-2"><Settings2 className="size-5 text-blue-600" />إعدادات مسرى</DialogTitle>
      <p className="text-sm leading-6 text-slate-500">تحكم سريع في الحساب والمظهر والتنبيهات من مكان واحد.</p>
      <div className="grid gap-2 py-2">
        <button type="button" onClick={() => openChild(onOpenProfile)} className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-3 py-3 text-right transition hover:border-blue-200 hover:bg-blue-50/70">
          <UserRound className="size-5 shrink-0 text-blue-600" /><span><strong className="block text-sm text-slate-800">الملف الشخصي</strong><small className="mt-0.5 block text-xs text-slate-500">الصورة والخصوصية والأعضاء المحظورون</small></span>
        </button>
        <button type="button" onClick={() => openChild(onOpenDisplay)} className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-3 py-3 text-right transition hover:border-blue-200 hover:bg-blue-50/70">
          <Pencil className="size-5 shrink-0 text-blue-600" /><span><strong className="block text-sm text-slate-800">الخط ولون الكتابة</strong><small className="mt-0.5 block text-xs text-slate-500">تخصيص القراءة ومحرر الرسائل</small></span>
        </button>
        {memberToken && <button type="button" onClick={() => openChild(onOpenFriends)} className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-3 py-3 text-right transition hover:border-blue-200 hover:bg-blue-50/70">
          <UserPlus className="size-5 shrink-0 text-blue-600" /><span><strong className="block text-sm text-slate-800">الأصدقاء</strong><small className="mt-0.5 block text-xs text-slate-500">إدارة طلبات الصداقة والمحادثات الموثوقة</small></span>
        </button>}
        <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-3 py-3">
          <div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-xl bg-blue-100 text-blue-700">{soundEnabled ? <Volume2 className="size-5" /> : <VolumeX className="size-5" />}</span><span><strong className="block text-sm text-slate-800">صوت الإشعارات</strong><small className="mt-0.5 block text-xs text-slate-500">تنبيه عند وصول رسالة خاصة</small></span></div>
          <button type="button" role="switch" aria-checked={soundEnabled} onClick={onToggleSound} className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors", soundEnabled ? "bg-blue-600" : "bg-slate-300")} aria-label={soundEnabled ? "كتم صوت الإشعارات" : "تشغيل صوت الإشعارات"}><span className={cn("absolute top-1 size-4 rounded-full bg-white shadow transition-transform", soundEnabled ? "translate-x-1" : "translate-x-6")} /></button>
        </div>
        {toggleTheme && <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-3 py-3"><div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-xl bg-amber-100 text-amber-700">{theme === "dark" ? <Sun className="size-5" /> : <Moon className="size-5" />}</span><span><strong className="block text-sm text-slate-800">الوضع الداكن</strong><small className="mt-0.5 block text-xs text-slate-500">{theme === "dark" ? "مفعّل حالياً" : "مظهر هادئ للضوء المنخفض"}</small></span></div><button type="button" role="switch" aria-checked={theme === "dark"} onClick={toggleTheme} className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors", theme === "dark" ? "bg-blue-600" : "bg-slate-300")} aria-label={theme === "dark" ? "إيقاف الوضع الداكن" : "تفعيل الوضع الداكن"}><span className={cn("absolute top-1 size-4 rounded-full bg-white shadow transition-transform", theme === "dark" ? "translate-x-1" : "translate-x-6")} /></button></div>}
      </div>
    </DialogContent>
  </Dialog>;
}

function ChatShell({ session, onLogout }: { session: LocalSession; onLogout: () => void }) {
  const { theme, toggleTheme } = useTheme();
  const [displayPreferences, setDisplayPreferences] = useState<DisplayPreferences>(() => readDisplayPreferences());
  const [displayPreferencesOpen, setDisplayPreferencesOpen] = useState(false);
  const [unifiedSettingsOpen, setUnifiedSettingsOpen] = useState(false);
  const [memberListTab, setMemberListTab] = useState<"members" | "private">("members");
  const [view, setView] = useState<"public" | "private" | "admin">("public");
  const [privatePeer, setPrivatePeer] = useState<Member | null>(null);
  const [replyTarget, setReplyTarget] = useState<{ sessionId: string; displayName: string } | null>(null);
  const [mobileMembersOpen, setMobileMembersOpen] = useState(false);
  const [keyboardInset, setKeyboardInset] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [mutedConversations, setMutedConversations] = useState<Record<string, boolean>>({});
  const [pinnedConversations, setPinnedConversations] = useState<string[]>(() => { try { return JSON.parse(localStorage.getItem(`bouh:pinned:${session.memberToken ?? session.sessionId}`) ?? "[]") as string[]; } catch { return []; } });
  const [memberSearch, setMemberSearch] = useState("");
  const [chatSearch, setChatSearch] = useState("");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [friendsOpen, setFriendsOpen] = useState(false);
  const typingStopTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const previousUnreadCounts = useRef<UnreadCounts | null>(null);
  const utils = trpc.useUtils();
  const bootstrap = trpc.chat.bootstrap.useQuery({ sessionId: session.sessionId }, { refetchInterval: 2_500, refetchIntervalInBackground: true, refetchOnWindowFocus: true, refetchOnReconnect: true, retry: false });
  const memberPreferences = trpc.chat.memberPreferences.useQuery({ memberToken: session.memberToken ?? "" }, { enabled: Boolean(session.memberToken), staleTime: 60_000, retry: false });
  const privateMessages = trpc.chat.privateMessages.useQuery({ sessionId: session.sessionId, peerSessionId: privatePeer?.sessionId ?? session.sessionId }, { enabled: view === "private" && Boolean(privatePeer), refetchInterval: 4_000, refetchIntervalInBackground: true, refetchOnWindowFocus: true, refetchOnReconnect: true, retry: false });
  const heartbeat = trpc.chat.heartbeat.useMutation();
  const updateRemotePreferences = trpc.chat.updatePreferences.useMutation({ onError: () => toast.error("تعذر مزامنة المظهر؛ بقي محفوظاً على هذا الجهاز.") });
  const sendPublic = trpc.chat.sendPublic.useMutation({
    onMutate: (variables) => {
      const optimistic = createOptimisticChatMessage({ sessionId: session.sessionId, displayName: session.displayName, gender: session.gender, roomId: (bootstrap.data?.currentRoom as Room | undefined)?.id ?? 1, channel: "public", body: variables.body ?? "", image: variables.image });
      utils.chat.bootstrap.setData({ sessionId: session.sessionId }, (previous) => previous ? { ...previous, publicMessages: appendUniqueChatMessage(previous.publicMessages ?? [], optimistic) } : previous);
      return { optimisticId: optimistic.id };
    },
    onSuccess: (message, _variables, context) => {
      utils.chat.bootstrap.setData({ sessionId: session.sessionId }, (previous) => previous ? { ...previous, publicMessages: replaceOptimisticChatMessage(previous.publicMessages ?? [], message, (candidate) => candidate.id === context?.optimisticId) } : previous);
      void utils.chat.bootstrap.invalidate();
    },
    onError: (error, _variables, context) => {
      utils.chat.bootstrap.setData({ sessionId: session.sessionId }, (previous) => previous ? { ...previous, publicMessages: removeOptimisticChatMessage(previous.publicMessages ?? [], (candidate) => candidate.id === context?.optimisticId) } : previous);
      toast.error(error.message);
    },
  });
  const sendPrivate = trpc.chat.sendPrivate.useMutation({
    onMutate: (variables) => {
      const optimistic = createOptimisticChatMessage({ sessionId: session.sessionId, displayName: session.displayName, gender: session.gender, roomId: (bootstrap.data?.currentRoom as Room | undefined)?.id ?? 1, channel: "private", body: variables.body ?? "", peerSessionId: variables.peerSessionId, image: variables.image });
      utils.chat.privateMessages.setData({ sessionId: session.sessionId, peerSessionId: variables.peerSessionId }, (previous) => previous ? { ...previous, messages: appendUniqueChatMessage(previous.messages ?? [], optimistic) } : previous);
      return { optimisticId: optimistic.id };
    },
    onSuccess: (message, variables, context) => {
      const isAiAssistant = variables.peerSessionId.includes("aifriend") || variables.peerSessionId.includes("aisarah");
      utils.chat.privateMessages.setData({ sessionId: session.sessionId, peerSessionId: variables.peerSessionId }, (previous) => {
        if (!previous) return previous;
        const messages = isAiAssistant ? appendUniqueChatMessage(previous.messages ?? [], message) : replaceOptimisticChatMessage(previous.messages ?? [], message, (candidate) => candidate.id === context?.optimisticId);
        return { ...previous, messages };
      });
      void utils.chat.privateMessages.invalidate();
      void utils.chat.bootstrap.invalidate();
    },
    onError: (error, _variables, context) => {
      utils.chat.privateMessages.setData({ sessionId: session.sessionId, peerSessionId: _variables.peerSessionId }, (previous) => previous ? { ...previous, messages: removeOptimisticChatMessage(previous.messages ?? [], (candidate) => candidate.id === context?.optimisticId) } : previous);
      toast.error(error.message);
    },
  });
  const setTyping = trpc.chat.setTyping.useMutation();
  const setPublicTyping = trpc.chat.setPublicTyping.useMutation();
  const deleteMessage = trpc.chat.admin.deleteMessage.useMutation({ onSuccess: () => { utils.chat.bootstrap.invalidate(); utils.chat.privateMessages.invalidate(); toast.success("تم حذف الرسالة."); }, onError: (error) => toast.error(error.message) });
  const joinRoom = trpc.chat.joinRoom.useMutation({
    onMutate: async ({ roomId }) => {
      await utils.chat.bootstrap.cancel({ sessionId: session.sessionId });
      const previous = utils.chat.bootstrap.getData({ sessionId: session.sessionId });
      const nextRoom = (previous?.rooms ?? []).find((room) => room.id === roomId);
      if (nextRoom) {
        setView("public");
        setPrivatePeer(null);
        setReplyTarget(null);
        setChatSearch("");
        utils.chat.bootstrap.setData({ sessionId: session.sessionId }, (current) => current ? {
          ...current,
          profile: { ...current.profile, currentRoomId: nextRoom.id },
          currentRoom: nextRoom,
          publicMessages: [],
          publicTyping: false,
          onlineMembers: [],
        } : current);
      }
      return { previous, previousView: view, previousPrivatePeer: privatePeer };
    },
    onSuccess: (result) => {
      setView("public");
      setPrivatePeer(null);
      setReplyTarget(null);
      utils.chat.bootstrap.setData({ sessionId: session.sessionId }, (previous) => previous ? {
        ...previous,
        profile: { ...previous.profile, ...result.profile },
        currentRoom: result.room,
        publicMessages: [],
        publicTyping: false,
        onlineMembers: [],
        generatedAt: result.generatedAt,
      } : previous);
      void utils.chat.bootstrap.invalidate();
      toast.success(`غادرت غرفة ${result.previousRoom?.name ?? "سابقة"} وانتقلت إلى ${result.room?.name ?? "الغرفة الجديدة"}.`);
    },
    onError: (error, _variables, context) => {
      if (context?.previous) utils.chat.bootstrap.setData({ sessionId: session.sessionId }, context.previous);
      if (context?.previousView) setView(context.previousView);
      if (context?.previousPrivatePeer) setPrivatePeer(context.previousPrivatePeer);
      toast.error(error.message);
    },
  });
  const selectRoom = (roomId: number) => {
    const currentRoomId = (bootstrap.data?.currentRoom as Room | undefined)?.id;
    if (joinRoom.isPending || roomId === currentRoomId) return;
    joinRoom.mutate({ sessionId: session.sessionId, roomId });
  };
  const setBlock = trpc.chat.setBlock.useMutation({ onSuccess: () => { setView("public"); setPrivatePeer(null); utils.chat.bootstrap.invalidate(); utils.chat.privateMessages.invalidate(); toast.success("تم حظر العضو وإغلاق المحادثة."); }, onError: (error) => toast.error(error.message) });
  const reportContent = trpc.chat.report.useMutation({ onSuccess: () => toast.success("تم استلام البلاغ وسيُراجع من الإدارة."), onError: (error) => toast.error(error.message) });
  const friends = trpc.chat.friends.useQuery({ memberToken: session.memberToken ?? "" }, { enabled: Boolean(session.memberToken), retry: false });
  const pinnedRemote = trpc.chat.pinnedConversations.useQuery({ memberToken: session.memberToken ?? "" }, { enabled: Boolean(session.memberToken), retry: false });
  const setPinnedRemote = trpc.chat.setPinnedConversation.useMutation({ onSuccess: () => pinnedRemote.refetch(), onError: (error) => toast.error(error.message) });
  const requestFriend = trpc.chat.requestFriend.useMutation({ onSuccess: (result) => { friends.refetch(); toast.success(result.status === "accepted" ? "تم قبول طلب الصداقة." : "تم إرسال طلب الصداقة."); }, onError: (error) => toast.error(error.message) });
  const respondFriend = trpc.chat.respondFriend.useMutation({ onSuccess: () => { friends.refetch(); toast.success("تم تحديث طلب الصداقة."); }, onError: (error) => toast.error(error.message) });
  const logoutSession = trpc.chat.logout.useMutation({
    onSuccess: async () => {
      await Promise.all([utils.chat.bootstrap.invalidate(), utils.chat.privateMessages.invalidate(), utils.chat.admin.overview.invalidate()]);
      toast.success("غادرت منصة مسرى.");
      onLogout();
    },
    onError: (error) => {
      toast.error(error.message || "تعذر تسجيل الخروج، تم إنهاء الجلسة محلياً.");
      onLogout();
    },
  });

  useEffect(() => {
    if (!session.memberToken || !memberPreferences.data?.preferences) return;
    const remote = normalizeDisplayPreferences({ fontFamily: memberPreferences.data.preferences.fontFamily as DisplayPreferences["fontFamily"], textColor: memberPreferences.data.preferences.textColor });
    setDisplayPreferences(remote);
    saveDisplayPreferences(remote);
  }, [memberPreferences.data, session.memberToken]);

  useEffect(() => {
    const activateAudio = () => {
      preparePrivateNotificationAudio();
      window.removeEventListener("pointerdown", activateAudio);
      window.removeEventListener("keydown", activateAudio);
      window.removeEventListener("touchstart", activateAudio);
    };
    window.addEventListener("pointerdown", activateAudio, { passive: true });
    window.addEventListener("keydown", activateAudio);
    window.addEventListener("touchstart", activateAudio, { passive: true });
    return () => {
      window.removeEventListener("pointerdown", activateAudio);
      window.removeEventListener("keydown", activateAudio);
      window.removeEventListener("touchstart", activateAudio);
    };
  }, []);

  useEffect(() => {
    const updateKeyboardInset = () => {
      const viewport = window.visualViewport;
      setKeyboardInset(viewport ? getVisualViewportKeyboardInset(viewport.height, window.innerHeight, viewport.offsetTop) : 0);
    };
    updateKeyboardInset();
    window.addEventListener("resize", updateKeyboardInset);
    const viewport = window.visualViewport;
    viewport?.addEventListener("resize", updateKeyboardInset);
    viewport?.addEventListener("scroll", updateKeyboardInset);
    return () => {
      window.removeEventListener("resize", updateKeyboardInset);
      viewport?.removeEventListener("resize", updateKeyboardInset);
      viewport?.removeEventListener("scroll", updateKeyboardInset);
    };
  }, []);

  useEffect(() => {
    if (!bootstrap.error || !isFatalChatSessionError(bootstrap.error)) return;
    toast.error(bootstrap.error.message);
    onLogout();
  }, [bootstrap.error, onLogout]);

  useEffect(() => {
    let disposed = false;
    const refreshConnection = () => {
      if (disposed || !navigator.onLine) return;
      void heartbeat.mutateAsync({ sessionId: session.sessionId })
        .then(() => utils.chat.bootstrap.invalidate())
        .catch(() => undefined);
    };
    const handleVisibility = () => {
      if (document.visibilityState === "visible") refreshConnection();
    };
    const handleOnline = () => refreshConnection();
    document.addEventListener("visibilitychange", handleVisibility);
    window.addEventListener("online", handleOnline);
    refreshConnection();
    return () => {
      disposed = true;
      document.removeEventListener("visibilitychange", handleVisibility);
      window.removeEventListener("online", handleOnline);
    };
  }, [heartbeat.mutateAsync, session.sessionId, utils]);

  const members = (bootstrap.data?.onlineMembers ?? []) as Member[];
  const visibleMembers = useMemo(() => members.filter((member) => member.displayName.toLocaleLowerCase().includes(memberSearch.trim().toLocaleLowerCase())).sort((a, b) => Number(pinnedConversations.includes(b.sessionId)) - Number(pinnedConversations.includes(a.sessionId))), [members, memberSearch, pinnedConversations]);
  useEffect(() => {
    if (session.memberToken) {
      if (pinnedRemote.data) setPinnedConversations(pinnedRemote.data.peerSessionIds);
      return;
    }
    localStorage.setItem(`bouh:pinned:${session.sessionId}`, JSON.stringify(pinnedConversations));
  }, [pinnedRemote.data, session.memberToken, session.sessionId]);
  const togglePinnedConversation = (peerSessionId: string) => {
    const pinned = !pinnedConversations.includes(peerSessionId);
    setPinnedConversations((current) => pinned ? [peerSessionId, ...current.filter((id) => id !== peerSessionId)] : current.filter((id) => id !== peerSessionId));
    if (session.memberToken) setPinnedRemote.mutate({ memberToken: session.memberToken, peerSessionId, pinned });
  };
  const publicMessages = (bootstrap.data?.publicMessages ?? []) as ChatMessage[];
  const unreadPrivateCounts = useMemo(() => (bootstrap.data?.unreadPrivateCounts ?? {}) as UnreadCounts, [bootstrap.data?.unreadPrivateCounts]);
  const activePrivatePeerId = view === "private" ? privatePeer?.sessionId : undefined;
  const visibleUnreadCounts = useMemo(() => {
    if (!activePrivatePeerId || !unreadPrivateCounts[activePrivatePeerId]) return unreadPrivateCounts;
    return { ...unreadPrivateCounts, [activePrivatePeerId]: 0 };
  }, [activePrivatePeerId, unreadPrivateCounts]);
  const incomingPrivateSenderIds = useMemo(() => (bootstrap.data?.incomingPrivateSenderIds ?? []) as string[], [bootstrap.data?.incomingPrivateSenderIds]);
  const privateConversationMembers = useMemo(() => filterMembersWithIncomingPrivateMessages(visibleMembers, incomingPrivateSenderIds).sort((a, b) => {
    const unreadDifference = (visibleUnreadCounts[b.sessionId] ?? 0) - (visibleUnreadCounts[a.sessionId] ?? 0);
    if (unreadDifference !== 0) return unreadDifference;
    return Number(pinnedConversations.includes(b.sessionId)) - Number(pinnedConversations.includes(a.sessionId));
  }), [visibleMembers, incomingPrivateSenderIds, visibleUnreadCounts, pinnedConversations]);
  const panelMembers = memberListTab === "private" ? privateConversationMembers : visibleMembers;
  const privateListUnreadCount = getTotalUnread(visibleUnreadCounts);
  const conversationMessages = (view === "public" ? publicMessages : ((privateMessages.data?.messages ?? []) as ChatMessage[]));
  const visibleConversationMessages = useMemo(() => { const term = chatSearch.trim().toLocaleLowerCase(); return term ? conversationMessages.filter((message) => (message.body ?? "").toLocaleLowerCase().includes(term)) : conversationMessages; }, [conversationMessages, chatSearch]);
  const totalUnread = getTotalUnread(visibleUnreadCounts);
  const peerTyping = view === "private" && privatePeer && !privatePeer.sessionId.includes("aifriend") && !privatePeer.sessionId.includes("aisarah") ? Boolean(privateMessages.data?.peerTyping) : false;
  const publicTyping = view === "public" ? Boolean(bootstrap.data?.publicTyping) : false;
  const handlePublicTyping = (isTyping: boolean) => {
    if (view !== "public") return;
    if (typingStopTimer.current) clearTimeout(typingStopTimer.current);
    setPublicTyping.mutate({ sessionId: session.sessionId, isTyping });
    if (isTyping) typingStopTimer.current = setTimeout(() => setPublicTyping.mutate({ sessionId: session.sessionId, isTyping: false }), 4_500);
  };
  const handleTyping = (isTyping: boolean) => {
    if (!privatePeer || view !== "private" || privatePeer.sessionId.includes("aifriend") || privatePeer.sessionId.includes("aisarah")) return;
    if (typingStopTimer.current) clearTimeout(typingStopTimer.current);
    setTyping.mutate({ sessionId: session.sessionId, peerSessionId: privatePeer.sessionId, isTyping });
    if (isTyping) typingStopTimer.current = setTimeout(() => setTyping.mutate({ sessionId: session.sessionId, peerSessionId: privatePeer.sessionId, isTyping: false }), 4_500);
  };
  const rooms = (bootstrap.data?.rooms ?? []) as Room[];
  const currentRoom = bootstrap.data?.currentRoom as Room | undefined;
  const current = bootstrap.data?.profile;
  const shownName = current?.displayName ?? session.displayName;
  const shownGender = current?.gender ?? session.gender;
  const shownProfile = { ...session, ...current } as LocalSession & { avatarKey?: string | null; acceptsPrivateMessages?: boolean };
  const usesDefaultTextColor = displayPreferences.textColor.toLowerCase() === DEFAULT_DISPLAY_PREFERENCES.textColor;
  const composerTextColor = usesDefaultTextColor ? getDefaultComposerTextColor(theme) : displayPreferences.textColor;
  const ownMessageTextColor = usesDefaultTextColor ? getDefaultOwnMessageTextColor() : displayPreferences.textColor;
  const openPrivate = (member: Member) => {
    const isAcceptedFriend = Boolean(session.memberToken && friends.data?.friends.some((friend) => friend.status === "accepted" && friend.profile.sessionId === member.sessionId));
    const accessReason = getPrivateAccessReason(member, session.sessionId, isAcceptedFriend);
    if (accessReason) {
      if (accessReason === "friends") toast.error("هذا العضو يقبل الرسائل الخاصة من الأصدقاء فقط.");
      else if (accessReason === "disabled") toast.error("هذا العضو لا يستقبل رسائل خاصة حالياً.");
      else if (accessReason === "blocked") toast.error("لا يمكن فتح هذه المحادثة بسبب الحظر.");
      return;
    }
    setPrivatePeer(member);
    setReplyTarget(null);
    setView("private");
    setMobileMembersOpen(false);
    utils.chat.bootstrap.setData({ sessionId: session.sessionId }, (previous) => previous ? {
      ...previous,
      unreadPrivateCounts: { ...(previous.unreadPrivateCounts ?? {}), [member.sessionId]: 0 },
    } : previous);
  };
  const membersBySession = useMemo(() => Object.fromEntries(members.map((member) => [member.sessionId, member])) as Record<string, Member>, [members]);
  const handlePublicAvatarClick = (sender: NonNullable<ChatMessage["sender"]>) => {
    if (view !== "public") return;
    const member = membersBySession[sender.sessionId];
    if (!member) {
      toast.info("يجب أن يكون العضو متصلاً لبدء محادثة خاصة.");
      return;
    }
    openPrivate(member);
  };
  const handlePublicNameClick = (sender: NonNullable<ChatMessage["sender"]>) => {
    if (view !== "public" || sender.sessionId === session.sessionId) return;
    setReplyTarget({ sessionId: sender.sessionId, displayName: sender.displayName });
  };
  useEffect(() => {
    const readState = privateMessages.data;
    if (view !== "private" || !privatePeer || !readState || readState.peerSessionId !== privatePeer.sessionId) return;
    utils.chat.bootstrap.setData({ sessionId: session.sessionId }, (previous) => previous ? { ...previous, unreadPrivateCounts: readState.unreadPrivateCounts } : previous);
  }, [privateMessages.data, privatePeer, session.sessionId, utils, view]);
  const firstUnreadPeer = useMemo(() => {
    const unreadPeerIds = getUnreadPeerIds(visibleUnreadCounts);
    return members.find((member) => unreadPeerIds.includes(member.sessionId) && !member.isBlocked && !member.hasBlockedViewer) ?? null;
  }, [members, visibleUnreadCounts]);
  const openFirstUnreadConversation = () => {
    if (firstUnreadPeer) {
      openPrivate(firstUnreadPeer);
      return;
    }
    toast.info("لديك رسائل غير مقروءة، لكن مرسلها غير متصل حالياً.");
  };
  const isAdmin = session.role === "admin" || current?.role === "admin";
  useEffect(() => {
    const previous = previousUnreadCounts.current;
    const currentPeerIds = new Set(getUnreadPeerIds(unreadPrivateCounts));
    for (const peerSessionId of getUnreadPeerIds(previous)) {
      if (!currentPeerIds.has(peerSessionId)) toast.dismiss(`bouh-unread-${peerSessionId}`);
    }
    const newPeerIds = getNewUnreadPeerIds(previous, unreadPrivateCounts).filter((peerSessionId) => peerSessionId !== activePrivatePeerId && !mutedConversations[peerSessionId]);
    if (newPeerIds.length > 0 && soundEnabled) {
      try { playPrivateNotificationTone(); } catch { /* قد يمنع المتصفح الصوت قبل أول تفاعل */ }
    }
    for (const peerSessionId of newPeerIds) {
      const peer = members.find((member) => member.sessionId === peerSessionId);
      const peerName = peer?.displayName ?? "عضو";
      const notificationId = `bouh-unread-${peerSessionId}`;
      toast(`وصلت رسالة جديدة من ${peerName}`, {
        id: notificationId,
        action: peer ? { label: "فتح", onClick: () => { toast.dismiss(notificationId); openPrivate(peer); } } : undefined,
      });
    }
    previousUnreadCounts.current = unreadPrivateCounts;
  }, [activePrivatePeerId, members, mutedConversations, soundEnabled, unreadPrivateCounts]);
  const pageTitle = view === "public" ? "الغرفة العامة" : view === "private" ? "دردشة خاصة" : "لوحة الإدارة";
  const pageDetail = view === "public" ? "مساحة مشتركة لكل الأعضاء المتصلين" : view === "private" && privatePeer ? `محادثة آمنة مع ${privatePeer.displayName}` : "إدارة الأعضاء والرسائل";
  useEffect(() => () => { if (typingStopTimer.current) clearTimeout(typingStopTimer.current); if (privatePeer && !privatePeer.sessionId.includes("aifriend") && !privatePeer.sessionId.includes("aisarah")) setTyping.mutate({ sessionId: session.sessionId, peerSessionId: privatePeer.sessionId, isTyping: false }); }, [privatePeer, session.sessionId]);
  const handleLogout = () => {
    if (logoutSession.isPending) return;
    logoutSession.mutate({ sessionId: session.sessionId, memberToken: session.memberToken });
  };
  const saveProfile = (updated: LocalSession & { avatarKey?: string | null; acceptsPrivateMessages?: boolean }) => {
    const nextSession = { ...session, ...updated };
    persistLocalSession(nextSession);
    utils.chat.bootstrap.setData({ sessionId: session.sessionId }, (previous) => previous ? { ...previous, profile: { ...previous.profile, ...updated } } : previous);
  };
  const saveDisplayPreferencesForSession = (nextPreferences: DisplayPreferences) => {
    const normalized = normalizeDisplayPreferences(nextPreferences);
    setDisplayPreferences(normalized);
    saveDisplayPreferences(normalized);
    if (session.memberToken) updateRemotePreferences.mutate({ sessionId: session.sessionId, memberToken: session.memberToken, fontFamily: normalized.fontFamily, textColor: normalized.textColor });
  };

  if (bootstrap.isLoading) return <div className="grid min-h-screen place-items-center bg-[#0b102b] text-white" dir="rtl"><div className="text-center"><div className="mx-auto grid size-14 place-items-center rounded-2xl bg-slate-950 text-white"><Loader2 className="size-6 animate-spin" /></div><p className="mt-4 text-sm font-bold text-slate-300">نجهّز مساحة الدردشة…</p></div></div>;

  return (
    <>
      <AdSenseAutoLoader />
      <main className="w-full max-w-full min-h-screen overflow-x-hidden bg-[#0b102b] pt-[6.75rem] text-slate-100" style={{ fontFamily: FONT_OPTIONS[displayPreferences.fontFamily].css }} dir="rtl">
      <header data-testid="top-chat-banner" className="fixed inset-x-0 top-0 z-50 max-w-full overflow-hidden border-b border-[#263556] bg-[#111b35] px-3 text-white shadow-lg shadow-blue-950/20 sm:px-6"><div className="mx-auto w-full max-w-[1600px]"><div className="flex h-16 min-w-0 items-center justify-between gap-3"><div className="flex min-w-0 items-center gap-2.5"><Button type="button" size="icon" variant="ghost" onClick={() => setMobileMembersOpen((open) => !open)} className="size-9 shrink-0 rounded-xl border border-white/10 text-slate-200 hover:bg-white/10 hover:text-white" aria-controls="online-members-panel" aria-expanded={mobileMembersOpen} data-testid="members-panel-toggle" aria-label={getMemberPanelToggleLabel(mobileMembersOpen)} title={getMemberPanelToggleLabel(mobileMembersOpen)}>{mobileMembersOpen ? <PanelRightClose className="size-4" /> : <Menu className="size-5" />}</Button><div className="grid size-9 shrink-0 place-items-center rounded-xl bg-blue-600"><Heart className="size-4 fill-rose-400 text-rose-400" /></div><div className="min-w-0"><p className="text-base leading-none"><MasraWordmark light /></p><p className="mt-1 text-[10px] font-medium text-slate-400">مساحة دردشة مباشرة</p></div>{totalUnread > 0 && <Button type="button" data-testid="unread-notifications" onClick={openFirstUnreadConversation} className="h-8 gap-1 rounded-full bg-rose-500 px-2.5 text-[10px] font-black text-white shadow-sm shadow-rose-500/25 hover:bg-rose-600" aria-label={`فتح أول محادثة، ${totalUnread} رسائل غير مقروءة`} title="فتح أول محادثة تحتوي رسائل غير مقروءة" aria-live="polite"><Bell className="size-3" />{totalUnread > 99 ? "99+" : totalUnread}</Button>}</div><div className="hidden items-center gap-3 md:flex"><nav aria-label="الروابط القانونية" className="flex items-center gap-2 text-[10px]"><a href="/privacy" className="text-slate-400 transition hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">الخصوصية</a><span className="text-slate-600">·</span><a href="/terms" className="text-slate-400 transition hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">الشروط</a></nav><span className="h-4 w-px bg-white/10" /><Circle className="size-2 fill-emerald-400 text-emerald-400" /><span className="text-xs text-slate-300">{members.length} متصل الآن</span></div><div className="flex items-center gap-1.5"><div className="hidden text-left sm:block"><p className="text-sm"><Name name={shownName} gender={shownGender} className="text-inherit" /></p><p className="mt-0.5 text-[10px] text-slate-400">{isAdmin ? "مدير النظام" : session.isGuest ? "زائر مؤقت" : "عضو دائم"}</p></div>{session.memberToken && <Button type="button" size="icon" variant="ghost" onClick={() => setFriendsOpen(true)} className="size-9 rounded-xl text-slate-300 hover:bg-white/10 hover:text-white" aria-label="الأصدقاء" title="الأصدقاء"><UserPlus className="size-4" /></Button>}<Button type="button" size="icon" variant="ghost" onClick={() => setUnifiedSettingsOpen(true)} className="size-9 rounded-xl text-slate-300 hover:bg-white/10 hover:text-white" aria-label="الإعدادات" title="الإعدادات"><Settings2 className="size-4" /></Button><Avatar className="size-9 ring-2 ring-white/10">{shownProfile.avatarKey && <AvatarImage src={storedImageUrl(shownProfile.avatarKey)} alt={`صورة ${shownName}`} />}<AvatarFallback className={cn("text-xs font-black", genderSoftClass(shownGender).split(" ").slice(0, 2).join(" "))}>{initialFor(shownName)}</AvatarFallback></Avatar><Button size="icon" variant="ghost" onClick={handleLogout} disabled={logoutSession.isPending} className="size-9 rounded-xl text-slate-300 hover:bg-white/10 hover:text-white" aria-label="تسجيل الخروج"><LogOut className="size-4" /></Button></div></div><div className="scrollbar-none flex w-full min-w-0 gap-2 overflow-x-auto border-t border-white/10 py-2">{isAdmin && <Button type="button" size="sm" variant="ghost" onClick={() => { setView("admin"); setPrivatePeer(null); }} className={cn("h-8 shrink-0 rounded-full border border-white/10 px-3 text-xs text-slate-300 hover:bg-white/10 hover:text-white", view === "admin" && "border-amber-400 bg-amber-500 text-white hover:bg-amber-500")}><ShieldCheck className="ml-1 size-3" />الإدارة</Button>}{rooms.map((room) => <Button key={room.id} type="button" size="sm" variant="ghost" onClick={() => selectRoom(room.id)} disabled={joinRoom.isPending || room.id === currentRoom?.id} aria-pressed={room.id === currentRoom?.id} className={cn("h-8 shrink-0 rounded-full border border-white/10 px-3 text-xs text-slate-300 hover:bg-white/10 hover:text-white", room.id === currentRoom?.id && "border-blue-400 bg-blue-600 text-white hover:bg-blue-600") }><Hash className="ml-1 size-3" />{room.name}</Button>)}</div></div></header>
      <div className="mx-auto flex h-[calc(100dvh-6.75rem)] min-h-0 w-full max-w-[1600px] items-start">
        <aside id="online-members-panel" aria-label="قائمة الأعضاء المتصلين" className={getMemberPanelClass(mobileMembersOpen)}><div className="border-b border-white/60 bg-white/35 px-2.5 py-3 sm:px-4 sm:py-4 lg:px-5 lg:py-5 dark:border-white/10 dark:bg-white/5"><div className="flex items-center justify-between"><div className="min-w-0"><div className="flex items-center gap-1.5 sm:gap-2">{memberListTab === "private" ? <MessageCircle className="size-3.5 shrink-0 text-blue-600 sm:size-4" /> : <Users className="size-3.5 shrink-0 text-blue-600 sm:size-4" />}<p className="truncate text-xs font-black text-slate-800 sm:text-sm">{memberListTab === "private" ? "المحادثات الخاصة" : "الأعضاء"}</p></div><p className="mt-1 hidden text-xs text-slate-400 lg:block">{memberListTab === "private" ? "رسائلك الخاصة غير المقروءة والمحادثات الأخيرة" : "حرّك القائمة واختر عضواً للدردشة الخاصة"}</p></div><span className="grid size-6 shrink-0 place-items-center rounded-lg bg-emerald-50 text-[10px] font-black text-emerald-600 sm:size-7 sm:rounded-xl sm:text-xs lg:size-8">{memberListTab === "private" ? privateListUnreadCount : members.length}</span></div><div className="mt-3 grid grid-cols-2 gap-1 rounded-xl bg-slate-100/70 p-1 dark:bg-slate-900/50"><button type="button" data-testid="members-list-tab" onClick={() => setMemberListTab("members")} aria-pressed={memberListTab === "members"} className={cn("rounded-lg px-2 py-2 text-[11px] font-black transition", memberListTab === "members" ? "bg-white text-blue-700 shadow-sm dark:bg-slate-800 dark:text-blue-200" : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200")}>الأعضاء</button><button type="button" data-testid="private-conversations-tab" onClick={() => setMemberListTab("private")} aria-pressed={memberListTab === "private"} className={cn("rounded-lg px-2 py-2 text-[11px] font-black transition", memberListTab === "private" ? "bg-white text-blue-700 shadow-sm dark:bg-slate-800 dark:text-blue-200" : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200")}>الخاص{privateListUnreadCount > 0 && <span className="mr-1 inline-grid min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[9px] text-white">{privateListUnreadCount > 99 ? "99+" : privateListUnreadCount}</span>}</button></div><label className="mt-3 flex items-center gap-2 rounded-xl border border-white/70 bg-white/45 px-2.5 py-2 backdrop-blur dark:border-white/10 dark:bg-white/10"><Search className="size-4 shrink-0 text-slate-400" /><input value={memberSearch} onChange={(event) => setMemberSearch(event.target.value)} placeholder={memberListTab === "private" ? "ابحث في المحادثات الخاصة" : "ابحث عن عضو"} aria-label={memberListTab === "private" ? "البحث في المحادثات الخاصة" : "البحث عن عضو"} className="min-w-0 flex-1 bg-transparent text-xs outline-none placeholder:text-slate-400" /></label></div><ScrollArea data-testid="online-members-scroll" className="min-h-0 flex-1 overscroll-contain"><div data-testid={memberListTab === "private" ? "private-conversations-list" : "online-members-list"} className="space-y-1 p-2 sm:p-3">{panelMembers.map((member) => <MemberItem key={member.sessionId} member={member} self={member.sessionId === session.sessionId} active={view === "private" && privatePeer?.sessionId === member.sessionId} unreadCount={view === "private" && privatePeer?.sessionId === member.sessionId ? 0 : visibleUnreadCounts[member.sessionId]} onSelect={() => openPrivate(member)} />)}{!panelMembers.length && <p className="p-3 text-center text-xs text-slate-400 sm:p-5 sm:text-sm">{memberListTab === "private" ? "لا توجد محادثات خاصة بعد." : "لا يوجد متصلون حالياً."}</p>}</div></ScrollArea><div className="border-t border-white/60 bg-white/30 p-2 sm:p-3 dark:border-white/10 dark:bg-white/5"><p className="rounded-lg bg-slate-50 px-2 py-1.5 text-center text-[9px] leading-4 text-slate-400 sm:rounded-xl sm:px-3 sm:py-2 sm:text-[11px]"><Clock3 className="ml-1 inline size-2.5 sm:size-3" />مرّر للتنقل</p></div></aside>
        <section data-testid="chat-room-surface" className="relative flex min-w-0 w-full max-w-full flex-1 flex-col overflow-hidden bg-white/35 bg-cover bg-center" style={view === "public" && currentRoom?.backgroundKey ? { backgroundImage: `linear-gradient(rgba(248,250,252,0.82), rgba(248,250,252,0.82)), url(${storedImageUrl(currentRoom.backgroundKey)})`, backgroundSize: "cover", backgroundPosition: "center" } : undefined}>
          {view === "admin" ? <Suspense fallback={<div className="grid flex-1 place-items-center"><Loader2 className="size-7 animate-spin text-slate-400" /></div>}><AdminPanel session={session} /></Suspense> : <>{view === "private" && privatePeer && <div className="flex w-full min-w-0 flex-wrap items-center justify-between gap-2 border-b border-slate-200 bg-white px-3 py-3 sm:px-4"><div className="flex min-w-0 items-center gap-2"><Avatar className="size-8 shrink-0">{privatePeer.avatarKey && <AvatarImage src={storedImageUrl(privatePeer.avatarKey)} alt={`صورة ${privatePeer.displayName}`} />}<AvatarFallback className={cn("text-xs font-black", genderSoftClass(privatePeer.gender).split(" ").slice(0, 2).join(" "))}>{initialFor(privatePeer.displayName)}</AvatarFallback></Avatar><div><p className="text-sm font-bold"><Name name={privatePeer.displayName} gender={privatePeer.gender} /></p><p className="text-[11px] text-slate-400">محادثة خاصة</p></div></div><div className="flex max-w-full min-w-0 flex-wrap items-center gap-1"><Button type="button" size="sm" variant="ghost" onClick={() => session.memberToken && requestFriend.mutate({ memberToken: session.memberToken, targetSessionId: privatePeer.sessionId })} disabled={!session.memberToken || requestFriend.isPending || privatePeer.role === "admin"} className="gap-1 rounded-xl px-2 text-blue-600 hover:bg-blue-50 hover:text-blue-700"><UserPlus className="size-4" />صديق</Button><Button type="button" size="sm" variant="ghost" onClick={() => togglePinnedConversation(privatePeer.sessionId)} className="gap-1 rounded-xl px-2 text-slate-500" aria-label={pinnedConversations.includes(privatePeer.sessionId) ? "إلغاء تثبيت المحادثة" : "تثبيت المحادثة"} title={pinnedConversations.includes(privatePeer.sessionId) ? "إلغاء تثبيت المحادثة" : "تثبيت المحادثة"}><Pin className={cn("size-4", pinnedConversations.includes(privatePeer.sessionId) && "fill-current text-blue-600")} /><span className="hidden sm:inline">{pinnedConversations.includes(privatePeer.sessionId) ? "مثبتة" : "تثبيت"}</span></Button><Button type="button" size="sm" variant="ghost" onClick={() => setMutedConversations((current) => ({ ...current, [privatePeer.sessionId]: !current[privatePeer.sessionId] }))} className="gap-1 rounded-xl px-2 text-slate-500 hover:bg-slate-100" aria-label={mutedConversations[privatePeer.sessionId] ? "تشغيل إشعارات هذه المحادثة" : "كتم إشعارات هذه المحادثة"} title={mutedConversations[privatePeer.sessionId] ? "تشغيل إشعارات هذه المحادثة" : "كتم إشعارات هذه المحادثة"}>{mutedConversations[privatePeer.sessionId] ? <BellOff className="size-4" /> : <Bell className="size-4" />}<span className="hidden sm:inline">{mutedConversations[privatePeer.sessionId] ? "مكتومة" : "كتم"}</span></Button><Button type="button" size="sm" variant="ghost" onClick={() => reportContent.mutate({ sessionId: session.sessionId, targetSessionId: privatePeer.sessionId, channel: "private", reason: "مستخدم مخالف" })} disabled={reportContent.isPending} className="gap-1.5 rounded-xl text-amber-600 hover:bg-amber-50 hover:text-amber-700"><Flag className="size-4" />إبلاغ</Button><Button type="button" size="sm" variant="ghost" onClick={() => setBlock.mutate({ sessionId: session.sessionId, targetSessionId: privatePeer.sessionId, blocked: true })} disabled={setBlock.isPending} className="gap-1.5 rounded-xl text-rose-600 hover:bg-rose-50 hover:text-rose-700"><Ban className="size-4" />حظر</Button></div></div>}<label className="mx-auto flex w-full max-w-4xl items-center gap-2 border-b border-slate-100 bg-white/80 px-4 py-2 text-sm backdrop-blur"><Search className="size-4 text-slate-400" /><input value={chatSearch} onChange={(event) => setChatSearch(event.target.value)} placeholder="ابحث داخل هذه المحادثة" aria-label="البحث داخل المحادثة الحالية" className="min-w-0 flex-1 bg-transparent outline-none placeholder:text-slate-400" /></label><ScrollArea className="min-h-0 flex-1"><div className="mx-auto w-full max-w-4xl px-4 pb-28 pt-4 sm:px-6 sm:pb-24 sm:pt-6">{(peerTyping || publicTyping) && <div className="mx-auto flex w-full max-w-4xl items-center gap-2 px-5 pb-1 text-right text-xs text-slate-400"><span className="flex gap-1 rounded-full bg-slate-100 px-3 py-2"><i className="size-1.5 animate-bounce rounded-full bg-blue-400 [animation-delay:-0.2s]" /><i className="size-1.5 animate-bounce rounded-full bg-blue-400 [animation-delay:-0.1s]" /><i className="size-1.5 animate-bounce rounded-full bg-blue-400" /></span><span>{view === "public" ? "يكتب أحد الأعضاء الآن…" : "يكتب الآن…"}</span></div>}<MessageFeed ownMessageStyle={{ fontFamily: FONT_OPTIONS[displayPreferences.fontFamily].css, color: ownMessageTextColor }} messages={visibleConversationMessages} currentSessionId={session.sessionId} emptyText={view === "public" ? "هذه بداية الغرفة العامة" : "ابدأ محادثة خاصة مع هذا العضو"} isPrivate={view === "private"} memberBySession={membersBySession} onAvatarClick={view === "public" ? handlePublicAvatarClick : undefined} onNameClick={view === "public" ? handlePublicNameClick : undefined} canDelete={isAdmin} onDelete={(messageId) => deleteMessage.mutate({ sessionId: session.sessionId, messageId })} onReport={(messageId, targetSessionId) => reportContent.mutate({ sessionId: session.sessionId, messageId, targetSessionId, roomId: currentRoom?.id, channel: view === "public" ? "public" : "private", reason: "محتوى مخالف" })} /></div></ScrollArea><Composer placeholder={view === "public" ? "اكتب رسالة للغرفة العامة…" : `اكتب رسالة إلى ${privatePeer?.displayName ?? "العضو"}…`} pending={view === "public" ? sendPublic.isPending : sendPrivate.isPending} replyTarget={view === "public" ? replyTarget?.displayName : null} onClearReply={() => setReplyTarget(null)} onTyping={view === "private" ? handleTyping : view === "public" ? handlePublicTyping : undefined} onSend={(content) => { setReplyTarget(null); if (view === "public") sendPublic.mutate({ sessionId: session.sessionId, ...content }); else if (privatePeer) sendPrivate.mutate({ sessionId: session.sessionId, peerSessionId: privatePeer.sessionId, ...content }); }} keyboardInset={keyboardInset} textStyle={{ fontFamily: FONT_OPTIONS[displayPreferences.fontFamily].css, color: composerTextColor }} /></>}
        </section>
      </div>
      {session.memberToken && <Dialog open={friendsOpen} onOpenChange={setFriendsOpen}><DialogContent dir="rtl" className="max-w-md"><DialogTitle>الأصدقاء</DialogTitle><div className="space-y-3 py-2"><div className="rounded-xl border border-blue-100 bg-blue-50/70 px-3 py-2.5 text-xs leading-5 text-blue-800">تظهر هنا الأسماء المستعارة وحالات الصداقة فقط. البريد الإلكتروني لا يظهر لأي عضو.</div>{friends.isLoading ? <p className="py-6 text-center text-sm text-slate-400">جارٍ تحميل الأصدقاء…</p> : (friends.data?.friends?.length ?? 0) === 0 ? <p className="py-6 text-center text-sm text-slate-400">لم تضف أصدقاء بعد. افتح محادثة خاصة واضغط «صديق».</p> : <div className="space-y-2">{friends.data?.friends.map((friend) => <div key={friend.id} className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/70 p-3"><Avatar className="size-9"><AvatarFallback className={cn("text-xs font-black", genderSoftClass(friend.profile.gender).split(" ").slice(0, 2).join(" "))}>{initialFor(friend.profile.displayName)}</AvatarFallback></Avatar><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold"><Name name={friend.profile.displayName} gender={friend.profile.gender} /></p><p className="text-[11px] text-slate-400">{friend.status === "accepted" ? "صديق" : friend.direction === "incoming" ? "طلب وارد" : "طلب قيد الانتظار"}</p></div>{friend.status === "pending" && friend.direction === "incoming" && <div className="flex gap-1"><Button type="button" size="sm" onClick={() => respondFriend.mutate({ memberToken: session.memberToken!, friendshipId: friend.id, status: "accepted" })} disabled={respondFriend.isPending} className="h-8 rounded-lg bg-blue-600 px-2 text-xs">قبول</Button><Button type="button" size="sm" variant="ghost" onClick={() => respondFriend.mutate({ memberToken: session.memberToken!, friendshipId: friend.id, status: "declined" })} disabled={respondFriend.isPending} className="h-8 rounded-lg px-2 text-xs text-slate-500">رفض</Button></div>}</div>)}</div>}</div></DialogContent></Dialog>}
      <UnifiedSettingsDialog open={unifiedSettingsOpen} onOpenChange={setUnifiedSettingsOpen} onOpenProfile={() => setSettingsOpen(true)} onOpenDisplay={() => setDisplayPreferencesOpen(true)} onOpenFriends={() => setFriendsOpen(true)} theme={theme} toggleTheme={toggleTheme} soundEnabled={soundEnabled} onToggleSound={() => { preparePrivateNotificationAudio(); setSoundEnabled((enabled) => !enabled); }} memberToken={session.memberToken} />
      <DisplayPreferencesDialog open={displayPreferencesOpen} onOpenChange={setDisplayPreferencesOpen} preferences={displayPreferences} onSaved={saveDisplayPreferencesForSession} />
      <Suspense fallback={null}><ProfileSettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} profile={shownProfile} onSaved={saveProfile} /></Suspense>
    </main>
    </>
  );
}

export default function Home() {
  const [session, setSession] = useState<LocalSession | null>(() => {
    try {
      return restoreLocalSession();
    } catch {
      return null;
    }
  });
  const onLogout = useMemo(() => () => { clearLocalSession(); setSession(null); }, []);
  return session ? <ChatShell session={session} onLogout={onLogout} /> : <LoginScreen onSessionCreated={setSession} />;
}
