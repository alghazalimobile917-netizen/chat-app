// @vitest-environment jsdom

import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { AdminPasswordField, countryFlag, getHomepageSupportActionsClass, getMemberPanelClass, getMemberPanelToggleLabel, getPrivateAccessReason, getReplyComposerDraft, getVisualViewportKeyboardInset, normalizeDisplayCountryCode, sharePlatformExternally, shouldShowAdminPassword } from "./Home";
import { appendUniqueChatMessage, filterMembersWithIncomingPrivateMessages, removeOptimisticChatMessage, replaceOptimisticChatMessage } from "@/lib/chatMessages";

describe("حماية دخول الإدارة في واجهة الدخول", () => {
  it("يحوّل رموز الدول إلى أعلام صحيحة ويرفض القيم العامة", () => {
    expect(normalizeDisplayCountryCode("uk")).toBe("GB");
    expect(countryFlag("EL")).toBe("🇬🇷");
    expect(countryFlag("XX")).toBe("🌐");
  });

  it("يُظهر كلمة السر لاسم الإدارة فقط", () => {
    expect(shouldShowAdminPassword(" الإدارة ")).toBe(true);
    expect(shouldShowAdminPassword("admin")).toBe(true);
    expect(shouldShowAdminPassword("زائر عادي")).toBe(false);
  });

  it("يشارك رابط المنصة وحده دون عنوان أو نص إضافي", async () => {
    const share = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(window.navigator, "share", { configurable: true, value: share });

    await sharePlatformExternally();

    expect(share).toHaveBeenCalledWith({ url: window.location.origin });
  });

  it("يدمج الرسالة المتفائلة ثم يستبدلها بالرسالة القادمة من الخادم", () => {
    const optimistic = { id: -1, body: "رسالة فورية" };
    const confirmed = { id: 42, body: "رسالة فورية" };
    const added = appendUniqueChatMessage([], optimistic);
    expect(added).toEqual([optimistic]);
    expect(replaceOptimisticChatMessage(added, confirmed, (message) => message.id === -1)).toEqual([confirmed]);
    expect(removeOptimisticChatMessage([optimistic, confirmed], (message) => message.id === -1)).toEqual([confirmed]);
  });

  it("يعرض في قائمة الخاص أصحاب الرسائل الواردة فقط", () => {
    const members = [{ sessionId: "sender-1" }, { sessionId: "sender-2" }, { sessionId: "viewer" }];
    expect(filterMembersWithIncomingPrivateMessages(members, ["sender-2", "missing", "sender-2"])).toEqual([{ sessionId: "sender-2" }]);
  });

  it("يحافظ على لوحة الأعضاء العائمة شبه الشفافة وحالة ظهورها", () => {
    const openClasses = getMemberPanelClass(true);
    const closedClasses = getMemberPanelClass(false);

    expect(openClasses).toContain("fixed");
    expect(openClasses).toContain("bg-white/55");
    expect(openClasses).toContain("backdrop-blur-2xl");
    expect(openClasses).toContain("flex");
    expect(openClasses).not.toContain("md:flex");
    expect(closedClasses).toContain("hidden");
  });

  it("يبدّل تسمية زر لوحة الأعضاء بين الإخفاء والإظهار", () => {
    expect(getMemberPanelToggleLabel(false)).toBe("إظهار لوحة الأعضاء");
    expect(getMemberPanelToggleLabel(true)).toBe("إخفاء لوحة الأعضاء");
  });

  it("يحافظ على أزرار الدعم في صف أفقي متجاوب", () => {
    expect(getHomepageSupportActionsClass()).toContain("grid-cols-3");
    expect(getHomepageSupportActionsClass()).toContain("gap-2");
  });

  it("يحسب مساحة لوحة المفاتيح من النافذة المرئية دون قيمة سالبة", () => {
    expect(getVisualViewportKeyboardInset(500, 800)).toBe(300);
    expect(getVisualViewportKeyboardInset(800, 800)).toBe(0);
    expect(getVisualViewportKeyboardInset(520, 800, 20)).toBe(260);
  });

  it("يمنع فتح الخاص مع العضو نفسه أو المحظور أو من عطّل الخاص", () => {
    const baseMember = { sessionId: "peer-1", acceptsPrivateMessages: true, privateMessagePolicy: "everyone" as const, isBlocked: false, hasBlockedViewer: false };
    expect(getPrivateAccessReason(baseMember, "peer-1", false)).toBe("self");
    expect(getPrivateAccessReason({ ...baseMember, isBlocked: true }, "viewer-1", true)).toBe("blocked");
    expect(getPrivateAccessReason({ ...baseMember, acceptsPrivateMessages: false }, "viewer-1", true)).toBe("disabled");
    expect(getPrivateAccessReason({ ...baseMember, privateMessagePolicy: "nobody" }, "viewer-1", true)).toBe("disabled");
  });

  it("لا يسمح بسياسة الأصدقاء إلا بعد قبول الصداقة", () => {
    const member = { sessionId: "peer-1", acceptsPrivateMessages: true, privateMessagePolicy: "friends" as const, isBlocked: false, hasBlockedViewer: false };
    expect(getPrivateAccessReason(member, "viewer-1", false)).toBe("friends");
    expect(getPrivateAccessReason(member, "viewer-1", true)).toBeNull();
  });

  it("ينشئ مسودة رد باسم المرسل بصيغة قابلة للتحرير", () => {
    expect(getReplyComposerDraft("  ساره  ")).toBe("@ساره ");
  });

  it("يرندر حقل كلمة السر عند تفعيله ويخفيه عند تعطيله", () => {
    const onChange = vi.fn();
    const { rerender } = render(<AdminPasswordField visible={false} value="" onChange={onChange} />);
    expect(screen.queryByPlaceholderText("أدخل كلمة سر الإدارة")).toBeNull();

    rerender(<AdminPasswordField visible value="" onChange={onChange} />);
    const password = screen.getByPlaceholderText("أدخل كلمة سر الإدارة");
    expect(password.getAttribute("type")).toBe("password");
    fireEvent.change(password, { target: { value: "secret" } });
    expect(onChange).toHaveBeenCalledWith("secret");
  });
});
