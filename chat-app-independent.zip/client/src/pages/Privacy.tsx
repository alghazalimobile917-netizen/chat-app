import React from "react";
import { ArrowRight, Heart, ShieldCheck } from "lucide-react";

function LegalHeader({ title, eyebrow }: { title: string; eyebrow: string }) {
  return <header className="border-b border-white/10 bg-[#111b35] text-white">
    <div className="mx-auto flex w-full max-w-5xl items-center justify-between gap-4 px-4 py-5 sm:px-6">
      <a href="/" className="inline-flex min-h-10 items-center gap-2 rounded-xl px-2 text-sm font-bold text-slate-200 transition hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400" aria-label="العودة إلى مسرى"><ArrowRight className="size-4" />العودة إلى مسرى</a>
      <div className="text-right"><div className="flex items-center justify-end gap-2"><span className="grid size-8 place-items-center rounded-xl bg-blue-600"><Heart className="size-4 fill-rose-400 text-rose-400" /></span><span className="text-xl font-black tracking-tight">مسرى</span></div><p className="mt-1 text-[11px] text-slate-400">{eyebrow}</p></div>
    </div>
    <div className="mx-auto w-full max-w-5xl px-4 pb-8 pt-4 sm:px-6"><h1 className="text-3xl font-black tracking-tight sm:text-4xl">{title}</h1><p className="mt-3 max-w-2xl text-sm leading-7 text-slate-300">آخر تحديث: 28 أغسطس 2026</p></div>
  </header>;
}

function LegalFooter() {
  return <footer className="mt-12 border-t border-slate-200 pt-6 text-center text-sm text-slate-500"><div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2"><a href="/privacy" className="font-bold text-blue-700 hover:text-blue-900">سياسة الخصوصية</a><a href="/terms" className="font-bold text-blue-700 hover:text-blue-900">شروط الاستخدام</a><a href="/" className="font-bold text-slate-700 hover:text-slate-950">العودة للدردشة</a></div><p className="mt-3 text-xs">مسرى — مساحة عربية للدردشة العامة والخاصة.</p></footer>;
}

export default function Privacy() {
  return <main dir="rtl" className="min-h-screen bg-[#f8fafc] text-slate-800">
    <LegalHeader title="سياسة الخصوصية" eyebrow="الخصوصية والشفافية أولاً" />
    <article className="mx-auto w-full max-w-4xl px-4 py-8 sm:px-6 sm:py-12">
      <div className="mb-8 flex items-start gap-3 rounded-2xl border border-blue-100 bg-blue-50/80 p-4 text-sm leading-7 text-blue-900"><ShieldCheck className="mt-1 size-5 shrink-0 text-blue-700" /><p>توضح هذه الصفحة كيف تتعامل منصة مسرى مع المعلومات اللازمة لتشغيل الدردشة وحمايتها وتحسينها. نستخدم أقل قدر عملي من البيانات، ولا نعرض البريد الإلكتروني في قائمة الأعضاء أو الرسائل.</p></div>
      <div className="space-y-8 rounded-[2rem] border border-slate-200 bg-white p-5 shadow-sm sm:p-9">
        <section><h2 className="text-xl font-black text-slate-950">1. نطاق السياسة</h2><p className="mt-3 text-sm leading-8 text-slate-600">تنطبق هذه السياسة على موقع مسرى وصفحاته وخدمات الدردشة المرتبطة به. باستخدام المنصة، تقر بأنك قرأت هذه السياسة وفهمت طريقة التعامل مع البيانات الموضحة فيها.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">2. المعلومات التي قد نعالجها</h2><div className="mt-3 space-y-3 text-sm leading-8 text-slate-600"><p><strong className="text-slate-800">الزائر:</strong> الاسم الظاهر والعمر والجنس ومعرّف جلسة مؤقت، إضافة إلى الرسائل والصور التي يختار إرسالها داخل الدردشة. لا يتطلب الدخول السريع بريداً إلكترونياً.</p><p><strong className="text-slate-800">العضو الدائم:</strong> البريد الإلكتروني وبيانات الحساب اللازمة لتسجيل الدخول، والاسم المستعار والعمر والجنس والصورة الشخصية وإعدادات الخصوصية والتفضيلات التي يختارها العضو. يبقى البريد الإلكتروني خاصاً ولا يظهر للأعضاء الآخرين.</p><p><strong className="text-slate-800">التشغيل والأمان:</strong> قد تُعالج معرّفات تقنية ومعلومات عن الجهاز والاتصال وسجلات الأخطاء عند الحاجة لتشغيل الخدمة، منع إساءة الاستخدام، تطبيق الحظر، والتحقيق في البلاغات.</p></div></section>
        <section><h2 className="text-xl font-black text-slate-950">3. لماذا نستخدم المعلومات؟</h2><ul className="mt-3 list-disc space-y-2 pr-5 text-sm leading-8 text-slate-600"><li>إنشاء جلسة الدردشة وعرض الأعضاء والرسائل التي تسمح بها إعدادات الخصوصية.</li><li>حفظ الحساب الدائم والمحادثات والتفضيلات والصورة الشخصية عبر الأجهزة.</li><li>تطبيق قواعد الاستخدام ومراجعة البلاغات وحماية الأعضاء والمنصة من الإساءة والرسائل غير المرغوبة.</li><li>تحسين الأداء والاستجابة، ومعالجة الأعطال، وإظهار الإعلانات عند تفعيلها بطريقة لا تعيق المحادثة.</li></ul></section>
        <section><h2 className="text-xl font-black text-slate-950">4. الرسائل والصور</h2><p className="mt-3 text-sm leading-8 text-slate-600">تُخزن الرسائل والصور اللازمة لإتاحة الدردشة العامة والخاصة حتى يحذفها المستخدم أو الإدارة، أو حتى تنتهي الحاجة التشغيلية إليها. لا ترسل معلومات حساسة أو صوراً شخصية لا ترغب في تخزينها أو مشاركتها مع الطرف المقصود. قد تُراجع المحتويات المخالفة أو تُحذف وفق شروط الاستخدام.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">5. التخزين المحلي والخدمات الخارجية</h2><p className="mt-3 text-sm leading-8 text-slate-600">قد يحفظ المتصفح بعض الإعدادات المحلية مثل تفضيل الخط واللون والجلسة لتسهيل العودة إلى المنصة. يستخدم مسرى خدمات استضافة وتخزين ومعالجة ضرورية لتقديم الموقع. وعند تفعيل إعلانات Google أو شركاء إعلانيين، قد تستخدم هذه الجهات ملفات تعريف الارتباط أو تقنيات مشابهة لقياس الأداء وتخصيص الإعلانات وفق سياساتها وإعدادات المستخدم المتاحة.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">6. المشاركة والحماية</h2><p className="mt-3 text-sm leading-8 text-slate-600">لا نبيع البريد الإلكتروني أو بيانات الحساب الشخصية. قد نشارك الحد الأدنى اللازم مع مزودي الاستضافة والتخزين أو عند وجود التزام قانوني أو خطر أمني أو طلب رسمي صحيح. نبذل إجراءات تقنية وتنظيمية معقولة للحماية، لكن لا توجد خدمة متصلة بالإنترنت خالية تماماً من المخاطر.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">7. اختياراتك وحقوقك</h2><p className="mt-3 text-sm leading-8 text-slate-600">يمكنك تعديل بيانات ملفك وإعدادات استقبال الرسائل من داخل المنصة، وحذف ما تسمح به أدوات الحساب أو طلب المساعدة من إدارة مسرى. قد نطلب معلومات تحقق مناسبة قبل تنفيذ طلب يتعلق بحساب دائم. يمكنك أيضاً إدارة ملفات تعريف الارتباط من إعدادات متصفحك، مع احتمال تأثر بعض الوظائف.</p></section>
        <section><h2 className="text-xl font-black text-slate-950">8. تحديث السياسة والتواصل</h2><p className="mt-3 text-sm leading-8 text-slate-600">قد نحدّث هذه السياسة عند تغير وظائف المنصة أو المتطلبات القانونية. سنعرض تاريخ التحديث في أعلى الصفحة، ويُعد استمرار استخدام مسرى بعد التحديث قبولاً للنص المعدل. للاستفسارات أو طلبات الخصوصية، استخدم قنوات التواصل الرسمية مع إدارة المنصة.</p></section>
      </div>
      <LegalFooter />
    </article>
  </main>;
}
