import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { type LocalSession, persistLocalSession } from "@/lib/session";
import { ChevronRight, Loader2, LockKeyhole, Mail, UserRound } from "lucide-react";
import { BUILTIN_NAME_DECORATIONS, type NameDecorationOption } from "@/lib/displayPreferences";
import React, { FormEvent, useEffect, useState } from "react";
import { toast } from "sonner";

type Gender = "male" | "female";

type MemberAuthPanelProps = {
  onSessionCreated: (session: LocalSession) => void;
  onGuestSelected: () => void;
};

export function MemberAuthPanel({ onSessionCreated, onGuestSelected }: MemberAuthPanelProps) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [alias, setAlias] = useState("");
  const [age, setAge] = useState("20");
  const [gender, setGender] = useState<Gender>("male");
  const [nameDecoration, setNameDecoration] = useState("none");
  const decorationsQuery = trpc.chat.nameDecorations.useQuery(undefined, { staleTime: 60_000, retry: 1 });
  const decorationOptions: NameDecorationOption[] = decorationsQuery.data?.decorations?.length ? decorationsQuery.data.decorations : BUILTIN_NAME_DECORATIONS;
  const selectedDecoration = decorationOptions.find((option) => option.key === nameDecoration) ?? decorationOptions.find((option) => option.key === "none") ?? decorationOptions[0];

  useEffect(() => {
    if (selectedDecoration && selectedDecoration.key !== nameDecoration) setNameDecoration(selectedDecoration.key);
  }, [nameDecoration, selectedDecoration]);

  const complete = (result: { memberToken: string; profile: { sessionId: string; displayName: string; age: number; gender: Gender; role: "member" | "admin"; avatarKey?: string | null; avatarMimeType?: string | null; acceptsPrivateMessages?: boolean }; account: { id: number; avatarKey?: string | null; avatarMimeType?: string | null; acceptsPrivateMessages?: boolean } }) => {
    const session: LocalSession = {
      sessionId: result.profile.sessionId,
      displayName: result.profile.displayName,
      age: result.profile.age,
      gender: result.profile.gender,
      role: result.profile.role,
      avatarKey: result.account.avatarKey ?? result.profile.avatarKey,
      avatarMimeType: result.account.avatarMimeType ?? result.profile.avatarMimeType,
      acceptsPrivateMessages: result.account.acceptsPrivateMessages ?? result.profile.acceptsPrivateMessages,
      accountId: result.account.id,
      memberToken: result.memberToken,
      isGuest: false,
    };
    persistLocalSession(session);
    onSessionCreated(session);
    toast.success(mode === "register" ? "تم إنشاء حسابك وحفظ ملفك الشخصي." : "مرحباً بعودتك إلى مسرى.");
  };

  const register = trpc.chat.registerMember.useMutation({ onSuccess: complete, onError: (error) => toast.error(error.message) });
  const login = trpc.chat.loginMember.useMutation({ onSuccess: complete, onError: (error) => toast.error(error.message) });
  const pending = register.isPending || login.isPending;

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (mode === "register") {
      const numericAge = Number(age);
      if (alias.trim().length < 2) return void toast.error("أدخل اسماً مستعاراً من حرفين على الأقل.");
      if (!Number.isInteger(numericAge) || numericAge < 13 || numericAge > 120) return void toast.error("يجب أن يكون العمر بين 13 و120 عاماً.");
      register.mutate({ email: email.trim(), password, alias: alias.trim(), age: numericAge, gender, nameDecoration: selectedDecoration?.key ?? "none" });
      return;
    }
    login.mutate({ email: email.trim(), password, nameDecoration: selectedDecoration?.key ?? "none" });
  };

  return <div className="space-y-5" dir="rtl">
    <div className="grid grid-cols-2 gap-2 rounded-xl bg-slate-100 p-1" role="tablist" aria-label="نوع دخول العضو">
      <button type="button" role="tab" aria-selected={mode === "login"} onClick={() => setMode("login")} className={cn("rounded-lg px-3 py-2 text-sm font-bold transition", mode === "login" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500")}>دخول عضو</button>
      <button type="button" role="tab" aria-selected={mode === "register"} onClick={() => setMode("register")} className={cn("rounded-lg px-3 py-2 text-sm font-bold transition", mode === "register" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500")}>إنشاء حساب</button>
    </div>
    <form className="space-y-4" onSubmit={submit}>
      <label className="block space-y-2"><span className="flex items-center gap-2 text-sm font-bold text-slate-700"><Mail className="size-4 text-slate-400" />البريد الإلكتروني</span><Input type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" required maxLength={320} placeholder="name@example.com" className="h-12 rounded-xl border-slate-200 bg-slate-50/70 text-left text-black shadow-none placeholder:text-slate-500 focus-visible:ring-blue-500" /></label>
      <label className="block space-y-2"><span className="flex items-center gap-2 text-sm font-bold text-slate-700"><LockKeyhole className="size-4 text-slate-400" />كلمة السر</span><Input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete={mode === "register" ? "new-password" : "current-password"} required minLength={mode === "register" ? 8 : 1} maxLength={128} placeholder={mode === "register" ? "8 أحرف على الأقل" : "كلمة السر"} className="h-12 rounded-xl border-slate-200 bg-slate-50/70 text-left text-black shadow-none placeholder:text-slate-500 focus-visible:ring-blue-500" /></label>
      {mode === "register" && <>
        <label className="block space-y-2"><span className="flex items-center gap-2 text-sm font-bold text-slate-700"><UserRound className="size-4 text-slate-400" />الاسم المستعار</span><Input value={alias} onChange={(event) => setAlias(event.target.value)} autoComplete="nickname" required maxLength={40} placeholder="الاسم الذي سيظهر للأعضاء" className="h-12 rounded-xl border-slate-200 bg-slate-50/70 text-right text-black shadow-none placeholder:text-slate-500 focus-visible:ring-blue-500" /></label>
        <div className="grid grid-cols-2 gap-3"><label className="block space-y-2"><span className="text-sm font-bold text-slate-700">العمر</span><Input type="number" value={age} onChange={(event) => setAge(event.target.value)} min="13" max="120" required className="h-12 rounded-xl border-slate-200 bg-slate-50/70 text-right text-black" /></label><fieldset className="space-y-2"><legend className="text-sm font-bold text-slate-700">الجنس</legend><div className="grid grid-cols-2 gap-1"><button type="button" onClick={() => setGender("male")} className={cn("h-12 rounded-xl border text-xs font-bold", gender === "male" ? "border-blue-200 bg-blue-50 text-blue-700" : "border-slate-200 bg-white text-slate-500")}>ذكر</button><button type="button" onClick={() => setGender("female")} className={cn("h-12 rounded-xl border text-xs font-bold", gender === "female" ? "border-pink-200 bg-pink-50 text-pink-700" : "border-slate-200 bg-white text-slate-500")}>أنثى</button></div></fieldset></div>
      </>}
      <label className="block space-y-2"><span className="text-sm font-bold text-slate-700">{mode === "register" ? "زخرفة الاسم" : "زخرفة الاسم عند الدخول"}</span><select aria-label="زخرفة الاسم" value={selectedDecoration?.key ?? "none"} onChange={(event) => setNameDecoration(event.target.value)} disabled={decorationsQuery.isLoading && !decorationsQuery.data} className="h-12 w-full rounded-xl border border-slate-200 bg-slate-50/70 px-3 text-right text-sm font-bold text-black disabled:cursor-wait disabled:opacity-70">{decorationOptions.map((option) => <option key={option.key} value={option.key}>{option.label}</option>)}</select><span className="block text-xs text-slate-400">{decorationsQuery.isError ? "تعذر تحديث القائمة؛ ستظهر الخيارات الأساسية مؤقتاً." : "سيظهر الاسم بهذه الزخرفة للأعضاء الآخرين."}</span></label>
      <div className="rounded-xl border border-blue-100 bg-blue-50/70 px-3 py-2.5 text-xs leading-5 text-blue-800">البريد الإلكتروني خاص بالحساب ولا يظهر في قائمة الأعضاء أو الرسائل أو طلبات الصداقة.</div>
      <Button type="submit" disabled={pending} className="h-12 w-full rounded-xl bg-slate-950 text-base font-bold shadow-lg shadow-slate-900/15 hover:bg-slate-800">{pending ? <Loader2 className="size-5 animate-spin" /> : <>{mode === "register" ? "إنشاء الحساب والدخول" : "دخول العضو"}<ChevronRight className="size-5" /></>}</Button>
    </form>
    <button type="button" onClick={onGuestSelected} className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold text-slate-600 transition hover:bg-slate-50">التسجيل السريع كزائر</button>
    <p className="text-center text-[11px] leading-5 text-slate-400">الحساب الدائم يحفظ المحادثات والصورة الشخصية وقائمة الأصدقاء بعد تسجيل الدخول لاحقاً.</p>
  </div>;
}
