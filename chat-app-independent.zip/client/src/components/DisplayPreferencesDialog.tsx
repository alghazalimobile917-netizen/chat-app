import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { FONT_OPTIONS, type DisplayPreferences, saveDisplayPreferences } from "@/lib/displayPreferences";
import { useState } from "react";
import { toast } from "sonner";

type Props = { open: boolean; onOpenChange: (open: boolean) => void; preferences: DisplayPreferences; onSaved: (preferences: DisplayPreferences) => void };

export function DisplayPreferencesDialog({ open, onOpenChange, preferences, onSaved }: Props) {
  const [draft, setDraft] = useState(preferences);
  const save = () => { saveDisplayPreferences(draft); onSaved(draft); onOpenChange(false); toast.success("تم حفظ مظهر الدردشة على هذا الجهاز."); };
  return <Dialog open={open} onOpenChange={(value) => { if (value) setDraft(preferences); onOpenChange(value); }}>
    <DialogContent dir="rtl" className="max-w-md"><DialogTitle>مظهر الدردشة</DialogTitle>
      <div className="space-y-4 py-2">
        <label className="block space-y-2"><span className="text-sm font-bold text-slate-800">نوع الخط</span><select aria-label="نوع الخط" value={draft.fontFamily} onChange={(event) => setDraft((current) => ({ ...current, fontFamily: event.target.value as DisplayPreferences["fontFamily"] }))} className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-800"><option value="cairo">{FONT_OPTIONS.cairo.label}</option><option value="tajawal">{FONT_OPTIONS.tajawal.label}</option><option value="system">{FONT_OPTIONS.system.label}</option></select></label>
        <label className="block space-y-2"><span className="text-sm font-bold text-slate-800">لون خط الكتابة ورسائلك</span><div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-2"><input aria-label="لون خط الرسائل" type="color" value={draft.textColor} onChange={(event) => setDraft((current) => ({ ...current, textColor: event.target.value }))} className="size-10 cursor-pointer rounded-lg border-0 bg-transparent" /><span className="font-mono text-sm text-slate-600">{draft.textColor}</span></div></label>
        <div style={{ fontFamily: FONT_OPTIONS[draft.fontFamily].css, color: draft.textColor }} className="rounded-xl border border-blue-100 bg-blue-50/70 p-4 text-base font-bold leading-7">هذه معاينة لخط ولون الكتابة ورسائلك داخل مسرى.</div>
        <Button type="button" onClick={save} className="h-11 w-full rounded-xl bg-[#172554] font-bold hover:bg-[#1e3a8a]">حفظ المظهر</Button>
      </div>
    </DialogContent>
  </Dialog>;
}
