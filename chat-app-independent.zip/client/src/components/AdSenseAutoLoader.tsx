import { useEffect } from "react";

const ADSENSE_SCRIPT_ID = "masra-adsense-script";
const ADSENSE_PUBLISHER_ID_PATTERN = /^pub-[A-Za-z0-9]+$/;

export function isValidAdSensePublisherId(value: string | undefined): value is string {
  return Boolean(value && ADSENSE_PUBLISHER_ID_PATTERN.test(value));
}

/**
 * Google Auto Ads loader for the normal React page.
 * The <amp-auto-ads> element is only for AMP documents; this application uses
 * Google's standard async script with the same publisher id instead.
 */
export function AdSenseAutoLoader() {
  useEffect(() => {
    const publisherId = import.meta.env.VITE_ADSENSE_PUBLISHER_ID as string | undefined;
    if (!isValidAdSensePublisherId(publisherId) || document.getElementById(ADSENSE_SCRIPT_ID)) return;

    const load = () => {
      if (document.getElementById(ADSENSE_SCRIPT_ID)) return;
      const script = document.createElement("script");
      script.id = ADSENSE_SCRIPT_ID;
      script.async = true;
      script.crossOrigin = "anonymous";
      script.dataset.adClient = `ca-${publisherId}`;
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-${publisherId}`;
      document.head.appendChild(script);
    };

    const idleWindow = window as unknown as {
      requestIdleCallback?: (callback: () => void, options?: { timeout: number }) => number;
      cancelIdleCallback?: (handle: number) => void;
    };
    const canIdle = typeof idleWindow.requestIdleCallback === "function";
    const handle = canIdle
      ? idleWindow.requestIdleCallback!(load, { timeout: 2500 })
      : window.setTimeout(load, 1200);

    return () => {
      if (canIdle && typeof idleWindow.cancelIdleCallback === "function") idleWindow.cancelIdleCallback(handle as number);
      else window.clearTimeout(handle as number);
    };
  }, []);

  return null;
}
