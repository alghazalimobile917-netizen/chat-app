import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { type LocalSession, type Gender } from "@/lib/session";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { Ban, ChevronRight, Crown, Hash, ImagePlus, Loader2, MessageCircle, Pencil, Plus, ShieldCheck, Trash2, Users, X } from "lucide-react";
import { type ChangeEvent, useState } from "react";
import { toast } from "sonner";

type Room = {
  id: number;
  name: string;
  isDefault: boolean;
  createdAt?: Date;
  backgroundKey?: string | null;
  backgroundMimeType?: string | null;
};

function formatTime(value: Date) {
  return new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function genderSoftClass(gender: Gender) {
  return gender === "male" ? "bg-blue-50 text-blue-700 ring-blue-100" : "bg-pink-50 text-pink-700 ring-pink-100";
}
function initialFor(name: string) { return name.trim().slice(0, 1).toUpperCase() || "؟"; }
function storedImageUrl(key: string) { return "/manus-storage/" + key; }
function Name({ name, gender, className }: { name: string; gender: Gender; className?: string }) {
  return <span className={cn("font-bold", gender === "male" ? "text-blue-600" : "text-pink-600", className)}>{name}</span>;
}
type OutgoingImage = { dataUrl: string; mimeType: "image/png" | "image/jpeg" | "image/webp" | "image/gif" };
type DecorationDraft = { label: string; prefix: string; suffix: string; sortOrder: string; enabled: boolean };
const EMPTY_DECORATION_DRAFT: DecorationDraft = { label: "", prefix: "", suffix: "", sortOrder: "10", enabled: true };
async function compressImageFile(file: File): Promise<OutgoingImage> {
  const sourceUrl = URL.createObjectURL(file);
  try {
    const source = new Image(); source.decoding = "async"; source.src = sourceUrl;
    await new Promise<void>((resolve, reject) => { source.onload = () => resolve(); source.onerror = () => reject(new Error("image-load")); });
    const scale = Math.min(1, 1600 / Math.max(source.naturalWidth, source.naturalHeight));
    const canvas = document.createElement("canvas"); canvas.width = Math.max(1, Math.round(source.naturalWidth * scale)); canvas.height = Math.max(1, Math.round(source.naturalHeight * scale));
    const context = canvas.getContext("2d"); if (!context) throw new Error("canvas-unavailable");
    context.drawImage(source, 0, 0, canvas.width, canvas.height);
    const mimeType: OutgoingImage["mimeType"] = "image/webp";
    return { dataUrl: canvas.toDataURL(mimeType, 0.82), mimeType };
  } finally { URL.revokeObjectURL(sourceUrl); }
}

export function AdminPanel({ session }: { session: LocalSession }) {
  const [roomName, setRoomName] = useState("");
  const [editingRoomId, setEditingRoomId] = useState<number | null>(null);
  const [editingRoomName, setEditingRoomName] = useState("");
  const [roomPendingDelete, setRoomPendingDelete] = useState<Room | null>(null);
  const [backgroundPendingRoomId, setBackgroundPendingRoomId] = useState<number | null>(null);
  const [messageRoomFilter, setMessageRoomFilter] = useState<number | "all">("all");
  const [messageChannelFilter, setMessageChannelFilter] = useState<"all" | "public" | "private">("all");
  const [decorationKey, setDecorationKey] = useState("");
  const [decorationDraft, setDecorationDraft] = useState<DecorationDraft>(EMPTY_DECORATION_DRAFT);
  const [editingDecorationId, setEditingDecorationId] = useState<number | null>(null);
  const utils = trpc.useUtils();
  const overview = trpc.chat.admin.overview.useQuery({ sessionId: session.sessionId, roomId: messageRoomFilter === "all" ? undefined : messageRoomFilter, channel: messageChannelFilter === "all" ? undefined : messageChannelFilter }, { refetchInterval: 1_500, refetchOnWindowFocus: true });
  const reports = trpc.chat.admin.reports.useQuery({ sessionId: session.sessionId }, { refetchInterval: 5_000, refetchOnWindowFocus: true });
  const decorations = trpc.chat.admin.listNameDecorations.useQuery({ sessionId: session.sessionId }, { refetchOnWindowFocus: true, retry: false });
  const reviewReport = trpc.chat.admin.reviewReport.useMutation({ onSuccess: () => { reports.refetch(); toast.success("تم تحديث حالة البلاغ."); }, onError: (error) => toast.error(error.message) });
  const refresh = () => { utils.chat.admin.overview.invalidate(); reports.refetch(); };
  const createRoom = trpc.chat.admin.createRoom.useMutation({ onSuccess: () => { setRoomName(""); toast.success("أُضيفت الغرفة الجديدة."); refresh(); }, onError: (error) => toast.error(error.message) });
  const renameRoom = trpc.chat.admin.renameRoom.useMutation({ onSuccess: () => { setEditingRoomId(null); setEditingRoomName(""); toast.success("تمت إعادة تسمية الغرفة."); refresh(); utils.chat.bootstrap.invalidate(); }, onError: (error) => toast.error(error.message) });
  const deleteRoom = trpc.chat.admin.deleteRoom.useMutation({ onSuccess: () => { setRoomPendingDelete(null); toast.success("حُذفت الغرفة ورسائلها ونُقلت الجلسات إلى العامة."); refresh(); utils.chat.bootstrap.invalidate(); }, onError: (error) => toast.error(error.message) });
  const updateRoomBackground = trpc.chat.admin.updateRoomBackground.useMutation({ onSuccess: () => { setBackgroundPendingRoomId(null); toast.success("تم تحديث خلفية الغرفة."); refresh(); utils.chat.bootstrap.invalidate(); }, onError: (error) => { setBackgroundPendingRoomId(null); toast.error(error.message); } });
  const deleteMessage = trpc.chat.admin.deleteMessage.useMutation({ onSuccess: () => { toast.success("حُذفت الرسالة وأزيلت من القائمة."); refresh(); }, onError: (error) => toast.error(error.message) });
  const deleteAllMessages = trpc.chat.admin.deleteAllMessages.useMutation({ onSuccess: () => { toast.success("تم حذف جميع الرسائل."); refresh(); }, onError: (error) => toast.error(error.message) });
  const deleteFilteredMessages = trpc.chat.admin.deleteFilteredMessages.useMutation({ onSuccess: () => { toast.success("تم حذف الرسائل المطابقة للفلاتر."); refresh(); }, onError: (error) => toast.error(error.message) });
  const banMember = trpc.chat.admin.banMember.useMutation({ onSuccess: () => { toast.success("تم تعطيل المستخدم وإخفاء رسائله."); refresh(); }, onError: (error) => toast.error(error.message) });
  const deleteMember = trpc.chat.admin.deleteMember.useMutation({ onSuccess: () => { toast.success("تم حذف المستخدم وإزالته من القائمة."); refresh(); utils.chat.bootstrap.invalidate(); }, onError: (error) => toast.error(error.message) });
  const refreshDecorations = () => { decorations.refetch(); utils.chat.nameDecorations.invalidate(); };
  const createDecoration = trpc.chat.admin.createNameDecoration.useMutation({ onSuccess: () => { setDecorationKey(""); setDecorationDraft(EMPTY_DECORATION_DRAFT); toast.success("أُضيفت زخرفة الاسم."); refreshDecorations(); }, onError: (error) => toast.error(error.message) });
  const updateDecoration = trpc.chat.admin.updateNameDecoration.useMutation({ onSuccess: () => { setEditingDecorationId(null); toast.success("تم تحديث زخرفة الاسم."); refreshDecorations(); }, onError: (error) => toast.error(error.message) });
  const deleteDecoration = trpc.chat.admin.deleteNameDecoration.useMutation({ onSuccess: () => { toast.success("حُذفت زخرفة الاسم."); refreshDecorations(); }, onError: (error) => toast.error(error.message) });
  const members = overview.data?.members ?? [];
  const messages = overview.data?.messages ?? [];
  const rooms = (overview.data?.rooms ?? []) as Room[];
  const reportItems = reports.data?.reports ?? [];
  const onlineCount = members.filter((member) => !member.isBanned).length;
  const chooseRoomBackground = async (roomId: number, event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!( ["image/png", "image/jpeg", "image/webp", "image/gif"] as string[]).includes(file.type)) { toast.error("اختر صورة PNG أو JPG أو WEBP أو GIF."); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("يجب ألا يتجاوز حجم الصورة 5 ميغابايت."); return; }
    setBackgroundPendingRoomId(roomId);
    try {
      const image = await compressImageFile(file);
      updateRoomBackground.mutate({ sessionId: session.sessionId, roomId, background: image });
    } catch { setBackgroundPendingRoomId(null); toast.error("تعذر تجهيز صورة الخلفية. حاول مرة أخرى."); }
  };

  if (overview.isLoading) return <div className="grid flex-1 place-items-center"><Loader2 className="size-7 animate-spin text-slate-400" /></div>;
  if (overview.error) return <div className="grid flex-1 place-items-center px-6 text-center"><p className="text-sm font-bold text-rose-600">{overview.error.message}</p></div>;

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden bg-[#f8fafc]">
      <div className="border-b border-slate-200 bg-white px-5 py-5 sm:px-7">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div><div className="flex items-center gap-2"><ShieldCheck className="size-5 text-slate-950" /><h2 className="text-xl font-black text-slate-950">لوحة الإدارة</h2></div><p className="mt-1 text-sm text-slate-500">متابعة الأعضاء والرسائل والتحكم في البيئة الحوارية.</p></div>
          <Badge className="rounded-full bg-slate-950 px-3 py-1.5 text-xs font-bold text-white hover:bg-slate-950"><Crown className="ml-1 size-3.5" /> صلاحيات الأدمن مفعلة</Badge>
        </div>
        <div className="mt-5 grid grid-cols-3 gap-3 sm:max-w-lg">
          <div className="rounded-xl bg-blue-50 p-3"><p className="text-xs text-blue-600">إجمالي الأعضاء</p><p className="mt-1 text-xl font-black text-blue-950">{members.length}</p></div>
          <div className="rounded-xl bg-emerald-50 p-3"><p className="text-xs text-emerald-600">المتصلون</p><p className="mt-1 text-xl font-black text-emerald-950">{onlineCount}</p></div>
          <div className="rounded-xl bg-amber-50 p-3"><p className="text-xs text-amber-600">إجمالي الرسائل</p><p className="mt-1 text-xl font-black text-amber-950">{messages.filter((message) => !message.deletedAt).length}</p></div>
        </div>
        <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <div className="flex items-center gap-2"><Hash className="size-4 text-blue-600" /><h3 className="font-bold text-slate-800">إضافة غرفة جديدة</h3></div>
          <form className="mt-3 flex gap-2" onSubmit={(event) => { event.preventDefault(); if (roomName.trim()) createRoom.mutate({ sessionId: session.sessionId, name: roomName.trim() }); }}>
            <Input value={roomName} onChange={(event) => setRoomName(event.target.value)} placeholder="مثال: غرفة الأصدقاء" maxLength={80} className="h-10 bg-white" />
            <Button type="submit" disabled={!roomName.trim() || createRoom.isPending} className="h-10 shrink-0 bg-blue-600 hover:bg-blue-700"><Plus className="ml-1 size-4" />إضافة</Button>
          </form>
          <div className="mt-3 space-y-2">
            {rooms.map((room) => {
              const editing = editingRoomId === room.id;
              return (
                <div key={room.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
                  {editing ? (
                    <form className="flex min-w-0 flex-1 gap-2" onSubmit={(event) => { event.preventDefault(); if (editingRoomName.trim()) renameRoom.mutate({ sessionId: session.sessionId, roomId: room.id, name: editingRoomName.trim() }); }}>
                      <Input autoFocus value={editingRoomName} onChange={(event) => setEditingRoomName(event.target.value)} maxLength={80} className="h-9 min-w-0 flex-1" aria-label={`اسم الغرفة ${room.name}`} />
                      <Button type="submit" size="sm" disabled={!editingRoomName.trim() || renameRoom.isPending} className="h-9 bg-blue-600 hover:bg-blue-700">حفظ</Button>
                      <Button type="button" size="sm" variant="outline" onClick={() => { setEditingRoomId(null); setEditingRoomName(""); }} className="h-9">إلغاء</Button>
                    </form>
                  ) : (
                    <>
                      <Badge variant="secondary" className="min-w-0 flex-1 justify-start rounded-full bg-slate-50 px-3 py-1 text-slate-700">{room.name}{room.isDefault ? " · افتراضية" : ""}</Badge>
                      <div className="flex shrink-0 items-center gap-1">
                        <label className="inline-flex size-8 cursor-pointer items-center justify-center rounded-lg text-violet-600 hover:bg-violet-50 hover:text-violet-700" aria-label={`تغيير خلفية ${room.name}`} title={room.backgroundKey ? "تغيير الخلفية" : "إضافة خلفية"}>
                          {backgroundPendingRoomId === room.id ? <Loader2 className="size-4 animate-spin" /> : <ImagePlus className="size-4" />}
                          <input type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="sr-only" disabled={backgroundPendingRoomId !== null} onChange={(event) => chooseRoomBackground(room.id, event)} />
                        </label>
                        {room.backgroundKey && <Button type="button" size="icon" variant="ghost" onClick={() => updateRoomBackground.mutate({ sessionId: session.sessionId, roomId: room.id, background: null })} disabled={backgroundPendingRoomId !== null} className="size-8 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-700" aria-label={`إزالة خلفية ${room.name}`} title="إزالة الخلفية"><X className="size-4" /></Button>}
                        {!room.isDefault && <>
                          <Button type="button" size="icon" variant="ghost" onClick={() => { setEditingRoomId(room.id); setEditingRoomName(room.name); }} className="size-8 rounded-lg text-blue-600 hover:bg-blue-50 hover:text-blue-700" aria-label={`إعادة تسمية ${room.name}`}><Pencil className="size-4" /></Button>
                          <Button type="button" size="icon" variant="ghost" onClick={() => setRoomPendingDelete(room)} className="size-8 rounded-lg text-rose-600 hover:bg-rose-50 hover:text-rose-700" aria-label={`حذف ${room.name}`}><Trash2 className="size-4" /></Button>
                        </>}
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
          <section className="mt-5 rounded-2xl border border-amber-200 bg-amber-50/60 p-4" aria-labelledby="name-decorations-title">
            <div className="flex items-start justify-between gap-3"><div><div className="flex items-center gap-2"><Pencil className="size-4 text-amber-700" /><h3 id="name-decorations-title" className="font-bold text-slate-800">زخارف أسماء الأعضاء</h3></div><p className="mt-1 text-xs leading-5 text-slate-500">أضف نمطاً يظهر حول اسم العضو في التسجيل والدخول. لا يظهر البريد الإلكتروني هنا.</p></div><Badge variant="secondary" className="shrink-0 rounded-full bg-white text-amber-800">{decorations.data?.decorations.length ?? 0}</Badge></div>
            <form className="mt-4 grid gap-2 sm:grid-cols-[1fr_1fr_0.8fr_auto]" onSubmit={(event) => { event.preventDefault(); const sortOrder = Number(decorationDraft.sortOrder); if (!decorationKey.trim() || !decorationDraft.label.trim()) return; createDecoration.mutate({ sessionId: session.sessionId, key: decorationKey.trim().toLowerCase(), label: decorationDraft.label.trim(), prefix: decorationDraft.prefix, suffix: decorationDraft.suffix, sortOrder: Number.isInteger(sortOrder) ? sortOrder : 10 }); }}>
              <Input value={decorationKey} onChange={(event) => setDecorationKey(event.target.value.replace(/[^a-z0-9-]/g, ""))} placeholder="المفتاح: sparkle" maxLength={32} className="h-10 bg-white text-black" aria-label="مفتاح الزخرفة" />
              <Input value={decorationDraft.label} onChange={(event) => setDecorationDraft((current) => ({ ...current, label: event.target.value }))} placeholder="اسم العرض: بريق" maxLength={80} className="h-10 bg-white text-black" aria-label="اسم الزخرفة" />
              <div className="grid grid-cols-2 gap-2"><Input value={decorationDraft.prefix} onChange={(event) => setDecorationDraft((current) => ({ ...current, prefix: event.target.value }))} placeholder="قبل الاسم" maxLength={16} className="h-10 bg-white text-black" aria-label="بادئة الزخرفة" /><Input value={decorationDraft.suffix} onChange={(event) => setDecorationDraft((current) => ({ ...current, suffix: event.target.value }))} placeholder="بعد الاسم" maxLength={16} className="h-10 bg-white text-black" aria-label="لاحقة الزخرفة" /></div>
              <Button type="submit" disabled={createDecoration.isPending || !decorationKey.trim() || !decorationDraft.label.trim()} className="h-10 bg-amber-600 text-white hover:bg-amber-700"><Plus className="ml-1 size-4" />إضافة</Button>
            </form>
            <div className="mt-3 space-y-2">
              {decorations.isLoading ? <p className="rounded-xl bg-white/70 px-3 py-4 text-center text-xs text-slate-400">جارٍ تحميل الزخارف…</p> : decorations.error ? <p className="rounded-xl bg-white/70 px-3 py-4 text-center text-xs text-rose-600">تعذر تحميل زخارف الأسماء.</p> : decorations.data?.decorations.map((decoration) => editingDecorationId === decoration.id ? <form key={decoration.id} className="grid gap-2 rounded-xl border border-blue-200 bg-white p-3 sm:grid-cols-[1fr_1fr_0.8fr_auto]" onSubmit={(event) => { event.preventDefault(); const sortOrder = Number(decorationDraft.sortOrder); updateDecoration.mutate({ sessionId: session.sessionId, id: decoration.id, label: decorationDraft.label.trim(), prefix: decorationDraft.prefix, suffix: decorationDraft.suffix, enabled: decorationDraft.enabled, sortOrder: Number.isInteger(sortOrder) ? sortOrder : decoration.sortOrder }); }}>
                <Input value={decorationDraft.label} onChange={(event) => setDecorationDraft((current) => ({ ...current, label: event.target.value }))} maxLength={80} className="h-9 text-black" aria-label={`اسم الزخرفة ${decoration.key}`} />
                <div className="grid grid-cols-2 gap-2"><Input value={decorationDraft.prefix} onChange={(event) => setDecorationDraft((current) => ({ ...current, prefix: event.target.value }))} maxLength={16} className="h-9 text-black" aria-label={`بادئة ${decoration.key}`} /><Input value={decorationDraft.suffix} onChange={(event) => setDecorationDraft((current) => ({ ...current, suffix: event.target.value }))} maxLength={16} className="h-9 text-black" aria-label={`لاحقة ${decoration.key}`} /></div>
                <Input type="number" min="0" max="999" value={decorationDraft.sortOrder} onChange={(event) => setDecorationDraft((current) => ({ ...current, sortOrder: event.target.value }))} className="h-9 text-black" aria-label={`ترتيب ${decoration.key}`} />
                <div className="flex items-center gap-1"><label className="flex h-9 items-center gap-1 rounded-lg border border-slate-200 px-2 text-xs text-slate-600"><input type="checkbox" checked={decorationDraft.enabled} onChange={(event) => setDecorationDraft((current) => ({ ...current, enabled: event.target.checked }))} />مفعلة</label><Button type="submit" size="sm" disabled={updateDecoration.isPending || !decorationDraft.label.trim()} className="h-9 bg-blue-600 hover:bg-blue-700">حفظ</Button><Button type="button" size="sm" variant="outline" onClick={() => setEditingDecorationId(null)} className="h-9">إلغاء</Button></div>
              </form> : <div key={decoration.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-white bg-white/80 px-3 py-2.5"><span className="min-w-0 flex-1 text-sm font-bold text-slate-800">{decoration.prefix}<span className="text-blue-700">اسم العضو</span>{decoration.suffix}<span className="mr-2 text-xs font-normal text-slate-400">({decoration.label} · {decoration.key})</span></span><Badge variant="secondary" className={cn("rounded-full px-2 text-[10px]", decoration.enabled ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500")}>{decoration.enabled ? "مفعلة" : "متوقفة"}</Badge><Button type="button" size="icon" variant="ghost" onClick={() => { setEditingDecorationId(decoration.id); setDecorationDraft({ label: decoration.label, prefix: decoration.prefix, suffix: decoration.suffix, sortOrder: String(decoration.sortOrder), enabled: decoration.enabled }); }} className="size-8 rounded-lg text-blue-600 hover:bg-blue-50" aria-label={`تعديل ${decoration.label}`}><Pencil className="size-4" /></Button><Button type="button" size="icon" variant="ghost" disabled={decoration.key === "none" || deleteDecoration.isPending} onClick={() => { if (window.confirm(`حذف زخرفة «${decoration.label}»؟`)) deleteDecoration.mutate({ sessionId: session.sessionId, id: decoration.id }); }} className="size-8 rounded-lg text-rose-600 hover:bg-rose-50" aria-label={`حذف ${decoration.label}`}><Trash2 className="size-4" /></Button></div>)}
              {!decorations.isLoading && !decorations.error && !decorations.data?.decorations.length && <p className="rounded-xl bg-white/70 px-3 py-4 text-center text-xs text-slate-400">لا توجد زخارف مضافة.</p>}
            </div>
          </section>
          <AlertDialog open={Boolean(roomPendingDelete)} onOpenChange={(open) => { if (!open && !deleteRoom.isPending) setRoomPendingDelete(null); }}>
            <AlertDialogContent dir="rtl">
              <AlertDialogHeader>
                <AlertDialogTitle>حذف الغرفة؟</AlertDialogTitle>
                <AlertDialogDescription>سيؤدي حذف «{roomPendingDelete?.name}» إلى حذف رسائلها ونقل الأعضاء الموجودين فيها إلى الغرفة العامة. لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel disabled={deleteRoom.isPending}>إلغاء</AlertDialogCancel>
                <AlertDialogAction disabled={deleteRoom.isPending} className="bg-rose-600 hover:bg-rose-700" onClick={() => roomPendingDelete && deleteRoom.mutate({ sessionId: session.sessionId, roomId: roomPendingDelete.id })}>حذف الغرفة</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
      <ScrollArea className="flex-1"><div className="grid gap-5 p-5 lg:grid-cols-[0.9fr_1.1fr] sm:p-7">
        <details open className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"><summary className="flex cursor-pointer list-none items-center justify-between border-b border-slate-100 px-5 py-4 outline-none transition-colors hover:bg-slate-50 focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-inset"><span className="flex items-center gap-2"><Users className="size-4 text-slate-500" /><span className="font-bold text-slate-800">إدارة الأعضاء</span></span><span className="flex items-center gap-2 text-xs text-slate-400"><span>{members.length} سجل</span><ChevronRight className="size-4 rotate-90 transition-transform group-open:rotate-[270deg]" /></span></summary>
          <div className="divide-y divide-slate-100">{members.length ? members.map((member) => <div key={member.sessionId} className="flex items-center gap-3 p-4"><Avatar className={cn("size-9", genderSoftClass(member.gender).split(" ").slice(-1)[0])}><AvatarFallback className={cn("text-xs font-black", genderSoftClass(member.gender).split(" ").slice(0, 2).join(" "))}>{initialFor(member.displayName)}</AvatarFallback></Avatar><div className="min-w-0 flex-1"><p className="truncate text-sm"><Name name={member.displayName} gender={member.gender} /> {member.role === "admin" && <Crown className="mr-1 inline size-3.5 text-amber-500" />}</p><p className="mt-1 text-xs text-slate-400">{member.age} سنة · {member.isBanned ? "معطّل" : "نشط"}</p></div>{member.role !== "admin" && <div className="flex gap-1"><Button size="icon" variant="ghost" onClick={() => banMember.mutate({ sessionId: session.sessionId, targetSessionId: member.sessionId })} disabled={banMember.isPending || member.isBanned} className="size-8 rounded-lg text-amber-600 hover:bg-amber-50 hover:text-amber-700" aria-label="تعطيل المستخدم"><Ban className="size-4" /></Button><Button size="icon" variant="ghost" onClick={() => deleteMember.mutate({ sessionId: session.sessionId, targetSessionId: member.sessionId })} disabled={deleteMember.isPending} className="size-8 rounded-lg text-rose-600 hover:bg-rose-50 hover:text-rose-700" aria-label="حذف المستخدم"><Trash2 className="size-4" /></Button></div>}</div>) : <p className="p-6 text-center text-sm text-slate-400">لا يوجد أعضاء حتى الآن.</p>}</div></details>
        <details open className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"><summary className="flex cursor-pointer list-none items-center justify-between border-b border-slate-100 px-5 py-4 outline-none transition-colors hover:bg-slate-50 focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-inset"><span className="flex items-center gap-2"><MessageCircle className="size-4 text-slate-500" /><span className="font-bold text-slate-800">آخر الرسائل</span></span><span className="flex items-center gap-2 text-xs text-slate-400"><span>{messages.length} سجل</span><ChevronRight className="size-4 rotate-90 transition-transform group-open:rotate-[270deg]" /></span></summary><div className="border-b border-slate-100 px-5 pb-4 pt-0"><div className="flex flex-wrap items-center justify-between gap-2"><div className="flex items-center gap-2"><MessageCircle className="size-4 text-slate-500" /><h3 className="font-bold text-slate-800">آخر الرسائل</h3></div><span className="text-xs text-slate-400">{messages.length} سجل</span></div><div className="mt-3 flex flex-wrap items-center gap-2"><select value={messageRoomFilter} onChange={(event) => setMessageRoomFilter(event.target.value === "all" ? "all" : Number(event.target.value))} className="h-9 min-w-0 flex-1 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 outline-none focus:border-blue-400" aria-label="فلترة الرسائل حسب الغرفة"><option value="all">كل الغرف</option>{rooms.map((room) => <option key={room.id} value={room.id}>{room.name}</option>)}</select><select value={messageChannelFilter} onChange={(event) => setMessageChannelFilter(event.target.value as "all" | "public" | "private")} className="h-9 min-w-0 flex-1 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 outline-none focus:border-blue-400" aria-label="فلترة الرسائل حسب النوع"><option value="all">كل الأنواع</option><option value="public">العامة</option><option value="private">الخاصة</option></select>{messages.length > 0 && (messageRoomFilter === "all" && messageChannelFilter === "all" ? <Button type="button" size="sm" variant="ghost" onClick={() => { if (window.confirm("سيتم حذف جميع الرسائل نهائياً من جميع الغرف والمحادثات الخاصة. هل تريد المتابعة؟")) deleteAllMessages.mutate({ sessionId: session.sessionId }); }} disabled={deleteAllMessages.isPending} className="h-9 rounded-lg px-2 text-xs font-bold text-rose-600 hover:bg-rose-50 hover:text-rose-700">حذف الكل</Button> : (((messageRoomFilter === "all") || !rooms.find((room) => room.id === messageRoomFilter)?.isDefault) && <Button type="button" size="sm" variant="ghost" onClick={() => { if (window.confirm("سيتم حذف الرسائل المطابقة للفلاتر الحالية نهائياً. هل تريد المتابعة؟")) deleteFilteredMessages.mutate({ sessionId: session.sessionId, roomId: messageRoomFilter === "all" ? undefined : messageRoomFilter, channel: messageChannelFilter === "all" ? undefined : messageChannelFilter }); }} disabled={deleteFilteredMessages.isPending} className="h-9 rounded-lg px-2 text-xs font-bold text-amber-700 hover:bg-amber-50">حذف المفلتر</Button>))}</div></div>
          <div className="divide-y divide-slate-100">{messages.length ? messages.map((message) => <div key={message.id} className={cn("flex items-start gap-3 p-4", message.deletedAt && "bg-slate-50 opacity-60")}><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs"><Name name={message.sender?.displayName ?? "مستخدم محذوف"} gender={message.sender?.gender ?? "male"} /><Badge variant="secondary" className="h-5 rounded-full px-2 text-[10px]">{message.channel === "public" ? "عامة" : "خاصة"}</Badge>{message.imageKey && <Badge className="h-5 rounded-full bg-blue-50 px-2 text-[10px] text-blue-600 hover:bg-blue-50">صورة</Badge>}<span className="text-slate-400">{formatTime(message.createdAt)}</span></div>{!message.deletedAt && message.imageKey && <img src={storedImageUrl(message.imageKey)} alt="صورة ضمن رسالة" className="mt-2 h-16 w-24 rounded-lg border border-slate-100 object-cover" loading="lazy" />}<p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-600">{message.deletedAt ? "تم حذف هذه الرسالة" : message.body || (message.imageKey ? "رسالة مصورة" : "")}</p></div>{!message.deletedAt && <Button size="icon" variant="ghost" onClick={() => deleteMessage.mutate({ sessionId: session.sessionId, messageId: message.id })} disabled={deleteMessage.isPending} className="size-8 shrink-0 rounded-lg text-rose-600 hover:bg-rose-50 hover:text-rose-700" aria-label="حذف الرسالة"><Trash2 className="size-4" /></Button>}</div>) : <p className="p-6 text-center text-sm text-slate-400">لا توجد رسائل بعد.</p>}</div></details>
      </div></ScrollArea>
    </div>
  );
}
