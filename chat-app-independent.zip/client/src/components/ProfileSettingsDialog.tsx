import { Ban } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { type Gender, type LocalSession } from "@/lib/session";
import { ChangeEvent, useEffect, useState } from "react";
import { ImagePlus, Loader2 } from "lucide-react";
import { toast } from "sonner";


function genderSoftClass(gender: Gender) {
  return gender === "male" ? "bg-blue-50 text-blue-700 ring-blue-100" : "bg-pink-50 text-pink-700 ring-pink-100";
}
function initialFor(name: string) { return name.trim().slice(0, 1).toUpperCase() || "؟"; }
function storedImageUrl(key: string) { return "/manus-storage/" + key; }
function Name({ name, gender, className }: { name: string; gender: Gender; className?: string }) {
  return <span className={cn("font-bold", gender === "male" ? "text-blue-600" : "text-pink-600", className)}>{name}</span>;
}
type OutgoingImage = { dataUrl: string; mimeType: "image/png" | "image/jpeg" | "image/webp" | "image/gif" };
async function compressImageFile(file: File): Promise<OutgoingImage> {
  const sourceUrl = URL.createObjectURL(file);
  try {
    const source = new Image(); source.decoding = "async"; source.src = sourceUrl;
    await new Promise<void>((resolve, reject) => { source.onload = () => resolve(); source.onerror = () => reject(new Error("image-load")); });
    const scale = Math.min(1, 1600 / Math.max(source.naturalWidth, source.naturalHeight));
    const canvas = document.createElement("canvas"); canvas.width = Math.max(1, Math.round(source.naturalWidth * scale)); canvas.height = Math.max(1, Math.round(source.naturalHeight * scale));
    const context = canvas.getContext("2d"); if (!context) throw new Error("canvas-unavailable");
    context.drawImage(source, 0, 0, canvas.width, canvas.height);
    const mimeType: OutgoingImage["mimeType"] = "image/webp";
    return { dataUrl: canvas.toDataURL(mimeType, 0.82), mimeType };
  } finally { URL.revokeObjectURL(sourceUrl); }
}

export function ProfileSettingsDialog({
  open,
  onOpenChange,
  profile,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  profile: LocalSession & { avatarKey?: string | null; acceptsPrivateMessages?: boolean; privateMessagePolicy?: "everyone" | "friends" | "nobody"; showPresence?: boolean };
  onSaved: (profile: LocalSession & { avatarKey?: string | null; acceptsPrivateMessages?: boolean; privateMessagePolicy?: "everyone" | "friends" | "nobody"; showPresence?: boolean }) => void;
}) {
  const [privateMessagePolicy, setPrivateMessagePolicy] = useState<"everyone" | "friends" | "nobody">(profile.privateMessagePolicy ?? (profile.acceptsPrivateMessages === false ? "nobody" : "everyone"));
  const [showPresence, setShowPresence] = useState(profile.showPresence !== false);
  const [image, setImage] = useState<{ dataUrl: string; mimeType: "image/png" | "image/jpeg" | "image/webp" | "image/gif" } | undefined>();
  const blockedMembers = trpc.chat.blockedMembers.useQuery({ sessionId: profile.sessionId }, { enabled: open, retry: false });
  const setBlock = trpc.chat.setBlock.useMutation({
    onSuccess: () => { blockedMembers.refetch(); toast.success("تم إلغاء الحظر."); },
    onError: (error) => toast.error(error.message),
  });
  const updatePreferences = trpc.chat.updatePreferences.useMutation({
    onSuccess: ({ profile: updated }) => { onSaved(updated); onOpenChange(false); toast.success("تم حفظ إعداداتك."); },
    onError: (error) => toast.error(error.message),
  });
  useEffect(() => { setPrivateMessagePolicy(profile.privateMessagePolicy ?? (profile.acceptsPrivateMessages === false ? "nobody" : "everyone")); setShowPresence(profile.showPresence !== false); }, [profile.privateMessagePolicy, profile.acceptsPrivateMessages, profile.showPresence]);
  const chooseImage = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!(["image/png", "image/jpeg", "image/webp", "image/gif"] as string[]).includes(file.type)) { toast.error("اختر صورة PNG أو JPG أو WEBP أو GIF."); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("يجب ألا يتجاوز حجم الصورة 5 ميغابايت."); return; }
    compressImageFile(file).then(setImage).catch(() => toast.error("تعذر ضغط الصورة. حاول مرة أخرى."));
  };
  const preview = image?.dataUrl ?? (profile.avatarKey ? storedImageUrl(profile.avatarKey) : undefined);
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent dir="rtl" className="max-w-md"><DialogTitle>إعدادات ملفك</DialogTitle><div className="space-y-5 py-2"><div className="flex items-center gap-4"><Avatar className="size-20 ring-4 ring-slate-100">{preview && <AvatarImage src={preview} alt="صورتك الشخصية" /> }<AvatarFallback className={cn("text-xl font-black", genderSoftClass(profile.gender).split(" ").slice(0, 2).join(" "))}>{initialFor(profile.displayName)}</AvatarFallback></Avatar><label className="cursor-pointer"><span className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 px-3 text-sm font-bold text-slate-700 hover:bg-slate-50"><ImagePlus className="size-4" />اختيار صورة</span><input type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="sr-only" onChange={chooseImage} /></label></div><label className="block rounded-xl border border-slate-100 bg-slate-50 p-4"><span className="block text-sm font-bold text-slate-800">استقبال الرسائل الخاصة</span><span className="mt-1 block text-xs leading-5 text-slate-500">اختر من يستطيع بدء محادثة خاصة معك.</span><select value={privateMessagePolicy} onChange={(event) => setPrivateMessagePolicy(event.target.value as "everyone" | "friends" | "nobody")} className="mt-3 h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700"><option value="everyone">الجميع</option><option value="friends">الأصدقاء فقط</option><option value="nobody">لا أحد</option></select></label><label className="flex items-center justify-between gap-4 rounded-xl border border-slate-100 bg-slate-50 p-4"><span><span className="block text-sm font-bold text-slate-800">إظهار حالة الاتصال</span><span className="mt-1 block text-xs leading-5 text-slate-500">اسمح للأعضاء برؤية أنك متصل أو آخر ظهورك.</span></span><button type="button" role="switch" aria-checked={showPresence} onClick={() => setShowPresence((value) => !value)} className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors", showPresence ? "bg-blue-600" : "bg-slate-300")}><span className={cn("absolute top-1 size-4 rounded-full bg-white shadow transition-transform", showPresence ? "translate-x-1" : "translate-x-6")} /></button></label>{(blockedMembers.data?.members?.length ?? 0) > 0 && <div className="space-y-2 rounded-xl border border-rose-100 bg-rose-50/60 p-3"><div className="flex items-center gap-2"><Ban className="size-4 text-rose-600" /><p className="text-sm font-bold text-slate-800">الأعضاء المحظورون</p></div><div className="space-y-2">{blockedMembers.data?.members.map((member) => <div key={member.sessionId} className="flex items-center gap-2 rounded-lg bg-white px-2.5 py-2"><Avatar className="size-7">{member.avatarKey && <AvatarImage src={storedImageUrl(member.avatarKey)} alt={`صورة ${member.displayName}`} />}<AvatarFallback className={cn("text-[10px] font-black", genderSoftClass(member.gender).split(" ").slice(0, 2).join(" "))}>{initialFor(member.displayName)}</AvatarFallback></Avatar><Name name={member.displayName} gender={member.gender} className="min-w-0 flex-1 truncate text-xs" /><Button type="button" size="sm" variant="ghost" disabled={setBlock.isPending} onClick={() => setBlock.mutate({ sessionId: profile.sessionId, targetSessionId: member.sessionId, blocked: false })} className="h-7 rounded-lg px-2 text-[11px] font-bold text-blue-700 hover:bg-blue-50">إلغاء الحظر</Button></div>)}</div></div>}<Button className="h-11 w-full rounded-xl bg-slate-950 font-bold hover:bg-slate-800" disabled={updatePreferences.isPending} onClick={() => updatePreferences.mutate({ sessionId: profile.sessionId, acceptsPrivateMessages: privateMessagePolicy !== "nobody", privateMessagePolicy, showPresence, image })}>{updatePreferences.isPending ? <Loader2 className="size-4 animate-spin" /> : "حفظ الإعدادات"}</Button></div></DialogContent></Dialog>;
}
