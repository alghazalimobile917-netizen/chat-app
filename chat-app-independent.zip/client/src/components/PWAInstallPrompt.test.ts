import { describe, expect, it } from "vitest";
import { getInstallCtaLabel, MANUAL_INSTALL_MESSAGE } from "./PWAInstallPrompt";

describe("PWAInstallPrompt", () => {
  it("uses a native-install label when the browser exposes the install event", () => {
    expect(getInstallCtaLabel(true)).toBe("تثبيت التطبيق");
  });

  it("offers manual browser instructions when native installation is unavailable", () => {
    expect(getInstallCtaLabel(false)).toBe("طريقة التثبيت");
    expect(MANUAL_INSTALL_MESSAGE).toContain("إضافة إلى الشاشة الرئيسية");
    expect(MANUAL_INSTALL_MESSAGE).toContain("تثبيت مسرى كتطبيق");
  });
});
