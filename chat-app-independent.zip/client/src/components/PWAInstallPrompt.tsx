import { Download, X } from "lucide-react";
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

const DISMISSED_KEY = "bouh-pwa-install-dismissed";
export const MANUAL_INSTALL_MESSAGE = "إذا لم يظهر التثبيت التلقائي، افتح قائمة المتصفح ثم اختر «إضافة إلى الشاشة الرئيسية» أو «تثبيت مسرى كتطبيق».";
export const getInstallCtaLabel = (supportsNativeInstall: boolean) => supportsNativeInstall ? "تثبيت التطبيق" : "طريقة التثبيت";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

export function isStandaloneDisplay() {
  if (typeof window === "undefined") return false;
  return window.matchMedia?.("(display-mode: standalone)").matches === true ||
    ("standalone" in navigator && Boolean((navigator as Navigator & { standalone?: boolean }).standalone));
}

export function PWAInstallPrompt() {
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [showManualHelp, setShowManualHelp] = useState(false);

  useEffect(() => {
    setIsStandalone(isStandaloneDisplay());
    try {
      setDismissed(localStorage.getItem(DISMISSED_KEY) === "1");
    } catch {
      // Private browsing can block localStorage; the prompt still remains usable.
    }

    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as BeforeInstallPromptEvent);
    };
    const handleInstalled = () => {
      setInstallEvent(null);
      setIsStandalone(true);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleInstalled);
    };
  }, []);

  if (isStandalone || dismissed) return null;

  const dismiss = () => {
    setDismissed(true);
    try {
      localStorage.setItem(DISMISSED_KEY, "1");
    } catch {
      // Ignore storage restrictions.
    }
  };

  const install = async () => {
    if (!installEvent) {
      setShowManualHelp((value) => !value);
      return;
    }
    await installEvent.prompt();
    const choice = await installEvent.userChoice;
    if (choice.outcome === "accepted") setInstallEvent(null);
  };

  return (
    <aside className="fixed inset-x-3 bottom-3 z-50 mx-auto max-w-xl rounded-2xl border border-blue-100 bg-white/95 p-3 shadow-xl shadow-slate-900/10 backdrop-blur" dir="rtl" aria-label="تثبيت تطبيق مسرى">
      <div className="flex items-start gap-3">
        <div className="mt-0.5 rounded-xl bg-blue-50 p-2 text-blue-600"><Download className="size-5" aria-hidden="true" /></div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold text-slate-900">ثبّت مسرى كتطبيق على جهازك</p>
          <p className="mt-1 text-xs leading-5 text-slate-500">افتح مسرى بسرعة من اختصار مستقل على الشاشة الرئيسية أو سطح المكتب.</p>
          {showManualHelp && <p className="mt-2 rounded-lg bg-slate-50 px-2.5 py-2 text-xs leading-5 text-slate-600">{MANUAL_INSTALL_MESSAGE}</p>}
          <div className="mt-2 flex flex-wrap gap-2">
            <Button type="button" size="sm" onClick={install} className="h-9 rounded-lg bg-blue-600 px-3 text-xs hover:bg-blue-700">{getInstallCtaLabel(Boolean(installEvent))}</Button>
            <Button type="button" size="sm" variant="ghost" onClick={dismiss} className="h-9 rounded-lg px-3 text-xs text-slate-500">لاحقاً</Button>
          </div>
        </div>
        <button type="button" onClick={dismiss} aria-label="إغلاق دعوة التثبيت" className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"><X className="size-4" aria-hidden="true" /></button>
      </div>
    </aside>
  );
}
