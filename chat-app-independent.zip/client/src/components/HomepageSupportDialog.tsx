import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Flag, Loader2, Mail, MessageCircle } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";

type SupportTopic = "report" | "contact";

type HomepageSupportDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialTopic?: SupportTopic;
};

export function HomepageSupportDialog({ open, onOpenChange, initialTopic = "contact" }: HomepageSupportDialogProps) {
  const [topic, setTopic] = useState<SupportTopic>(initialTopic);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const support = trpc.chat.homepageSupport.useMutation({
    onSuccess: () => {
      toast.success(topic === "report" ? "تم استلام البلاغ وسيُراجعه فريق الإدارة." : "تم إرسال رسالتك إلى الإدارة.");
      setName("");
      setEmail("");
      setMessage("");
      onOpenChange(false);
    },
    onError: (error) => toast.error(error.message),
  });

  useEffect(() => {
    if (open) setTopic(initialTopic);
  }, [initialTopic, open]);

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmedMessage = message.trim();
    if (trimmedMessage.length < 10) {
      toast.error("اكتب تفاصيل لا تقل عن 10 أحرف.");
      return;
    }
    support.mutate({
      topic,
      name: name.trim() || undefined,
      email: email.trim() || undefined,
      message: trimmedMessage,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent dir="rtl" className="max-w-lg border-blue-100 bg-white text-slate-900 shadow-2xl">
        <DialogHeader className="text-right">
          <DialogTitle className="flex items-center gap-2 text-xl font-black text-slate-950">
            {topic === "report" ? <Flag className="size-5 text-amber-600" /> : <MessageCircle className="size-5 text-blue-600" />}
            {topic === "report" ? "إرسال بلاغ" : "تواصل مع الإدارة"}
          </DialogTitle>
          <DialogDescription className="text-right leading-6 text-slate-500">
            {topic === "report" ? "أرسل تفاصيل المخالفة بوضوح، وسيتم التعامل معها بسرية وفق قواعد المنصة." : "اكتب رسالتك وسيراجعها فريق الإدارة، ويمكنك ترك بيانات التواصل اختيارياً."}
          </DialogDescription>
        </DialogHeader>
        <form className="space-y-4" onSubmit={submit}>
          <div className="grid grid-cols-2 gap-2 rounded-xl bg-slate-100 p-1" role="group" aria-label="نوع الرسالة">
            <button type="button" onClick={() => setTopic("report")} className={`flex min-h-11 items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-bold transition ${topic === "report" ? "bg-white text-amber-700 shadow-sm" : "text-slate-500 hover:text-slate-700"}`} aria-pressed={topic === "report"}>
              <Flag className="size-4" /> بلاغ
            </button>
            <button type="button" onClick={() => setTopic("contact")} className={`flex min-h-11 items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-bold transition ${topic === "contact" ? "bg-white text-blue-700 shadow-sm" : "text-slate-500 hover:text-slate-700"}`} aria-pressed={topic === "contact"}>
              <Mail className="size-4" /> تواصل
            </button>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="space-y-1.5">
              <span className="text-xs font-bold text-slate-700">الاسم <span className="font-normal text-slate-400">(اختياري)</span></span>
              <Input value={name} onChange={(event) => setName(event.target.value)} maxLength={40} className="bg-slate-50 text-black placeholder:text-slate-400" placeholder="اسمك" />
            </label>
            <label className="space-y-1.5">
              <span className="text-xs font-bold text-slate-700">البريد الإلكتروني <span className="font-normal text-slate-400">(اختياري)</span></span>
              <Input type="email" value={email} onChange={(event) => setEmail(event.target.value)} maxLength={120} className="bg-slate-50 text-black placeholder:text-slate-400" placeholder="name@example.com" dir="ltr" />
            </label>
          </div>
          <label className="block space-y-1.5">
            <span className="text-xs font-bold text-slate-700">التفاصيل</span>
            <Textarea value={message} onChange={(event) => setMessage(event.target.value)} minLength={10} maxLength={500} required rows={5} className="resize-none bg-slate-50 text-black placeholder:text-slate-400" placeholder={topic === "report" ? "اذكر ما حدث ومكانه أو اسم العضو إن أمكن…" : "اكتب رسالتك إلى الإدارة…"} />
            <span className="block text-[11px] text-slate-400">{message.length}/500</span>
          </label>
          <DialogFooter className="gap-2 sm:justify-start">
            <Button type="submit" disabled={support.isPending || message.trim().length < 10} className={`min-h-11 font-bold text-white ${topic === "report" ? "bg-amber-600 hover:bg-amber-700" : "bg-blue-700 hover:bg-blue-800"}`}>
              {support.isPending ? <Loader2 className="size-4 animate-spin" /> : topic === "report" ? "إرسال البلاغ" : "إرسال الرسالة"}
            </Button>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="min-h-11 border-slate-200 bg-white text-slate-700 hover:bg-slate-50">إلغاء</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default HomepageSupportDialog;

export type { SupportTopic };
